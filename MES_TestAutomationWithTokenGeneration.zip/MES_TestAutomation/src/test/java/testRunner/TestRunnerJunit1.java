package testRunner;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import managers.FileReaderManager;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import java.io.File;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src\\test\\resources\\features\\TrackInAndTrackOut.feature",
        tags="@TestCase01",
//        glue={"stepDefinitions","ApplicationHooks"},
        glue={"stepDefinitions"},
        monochrome=true,
        dryRun = false,
        plugin={"pretty",
//                "json:target/cucumber-reports/cucumber.json",
//                "html:target/cucumber-reports/cucumber.html",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        }
)


public class TestRunnerJunit1 {

}

