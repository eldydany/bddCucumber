package stepDefinitions;

import cucumber.TestContext;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
//import cucumber.api.java.en.Then;
import pageObjects.DispatchAndTrackInPage;
import pageObjects.TrackOutAndMoveNextPage;

public class TrackOutAndMoveNextPageSteps {

    TestContext testContext;
    TrackOutAndMoveNextPage trackOutAndMoveNextPage;
    DispatchAndTrackInPage dispatchAndTrackInPage;

    public TrackOutAndMoveNextPageSteps(TestContext context){
        testContext=context;
        trackOutAndMoveNextPage=testContext.getPageObjectManager().getTrackOutAndMoveNextPage();
        dispatchAndTrackInPage=testContext.getPageObjectManager().getDispatchAndTrackInPage();
    }

    @Then("^to click on dispatch and track in wizard$")
    public void toClickOnDispatchAndTrackInWizard() throws Exception {
        dispatchAndTrackInPage.toAbortTrackIn();
        dispatchAndTrackInPage.toManageProtocols();
        dispatchAndTrackInPage.toClickOnDispatchAndTrackInWizard();
        dispatchAndTrackInPage.toChooseAvailableResource();
        dispatchAndTrackInPage.toCompleteDocumentsStep();
        dispatchAndTrackInPage.toCompleteBomInformationStep();
        dispatchAndTrackInPage.toCompleteDataCollectionStep();
        dispatchAndTrackInPage.toCompleteCheckListStep();
        dispatchAndTrackInPage.toCompleteAttachmentsStep();
//        dispatchAndTrackInPage.toDoAssembleBeforeTrackingOut();
//        dispatchAndTrackInPage.toCompletePerformSetUp();
        dispatchAndTrackInPage.toDoScanAssemble();


    }

    @Then("^to click on track out and move next wizard$")
    public void toClickOnTrackOutAndMoveNextWizard() throws Exception {
        trackOutAndMoveNextPage.toTrackOutFromTheStep();
        trackOutAndMoveNextPage.toFindTheNoOfStepsPresentInTrackOutWizard();
        trackOutAndMoveNextPage.toCompleteResourceStateStep();
        trackOutAndMoveNextPage.toCompleteRecordLossBonusStep();
        trackOutAndMoveNextPage.toCompleteDataCollectionStepInTrackOut();
        trackOutAndMoveNextPage.toCompleteCheckListStepAtTrackOut();
        trackOutAndMoveNextPage.toCompleteAttachmentsStepAtTrackOut();
        trackOutAndMoveNextPage.toClickOnMoveNextWizard();
    }

    @Then("^to iterate through all the steps of the flow$")
    public void to_iterate_through_all_the_steps_of_the_flow() throws Throwable {

        int iterationCount=trackOutAndMoveNextPage.toFindTheNumberOfStepsIntheWorkFlow();
        for (int i = 1; i <= iterationCount; i++) {
            System.out.println("The value of I is "+i+" and the value of count "+iterationCount);
            this.toClickOnDispatchAndTrackInWizard();
            this.toClickOnTrackOutAndMoveNextWizard();
            if(trackOutAndMoveNextPage.endOfTheFlow){
                break;
            }
        }
    }

    @Then("^to validate if track-in and track-out is completed for all the steps of the flow$")
    public void to_validate_if_track_in_and_track_out_is_completed_for_all_the_steps_of_the_flow() throws Throwable {
        trackOutAndMoveNextPage.toValidateAllStepsAreProcessed();
    }


    @And("to track out from the step")
    public void toTrackOutFromTheStep() throws Exception {
        trackOutAndMoveNextPage.toTrackOutFromTheStep();
        trackOutAndMoveNextPage.toFindTheNoOfStepsPresentInTrackOutWizard();
    }

    @And("to complete resource state step")
    public void toCompleteResourceStateStep() {
        trackOutAndMoveNextPage.toCompleteResourceStateStep();
    }

    @And("to complete record loss bonus step")
    public void toCompleteRecordLossBonusStep() {
        trackOutAndMoveNextPage.toCompleteRecordLossBonusStep();
    }

    @And("to complete checklist step in track out")
    public void toCompleteChecklistStepInTrackOut() throws Exception {
        trackOutAndMoveNextPage.toCompleteCheckListStepAtTrackOut();
    }

    @Then("to move to next step")
    public void toMoveToNextStep() throws Exception {
        trackOutAndMoveNextPage.toClickOnMoveNextWizard();
    }

    @And("to complete data collection step in track out with {string}")
    public void toCompleteDataCollectionStepInTrackOutWith(String arg0) throws Exception {
        trackOutAndMoveNextPage.toCompleteDataCollectionStepInTrackOut();
    }
}
