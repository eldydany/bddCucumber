package utils;


import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import pageObjects.DispatchAndTrackInPage;

import java.io.*;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.*;

public class APIUtils {

    private static WebDriver driver1;

    public APIUtils(WebDriver driver){
        this.driver1=driver;

    }

    public HashMap<String,String> productAndMaskMap=new HashMap<String, String>();
    public HashMap<String,String> productAndNewMaterial =new HashMap<String, String>();
    public ArrayList<String> arrayListOfHiddenLimitRange = new ArrayList<String>();
    public  boolean strAllowDispositionDecision;
    public  boolean strDispositionRequiresApproval;
    public  boolean isCheckListPresentInProtocol;
    public  boolean isParameterPresentInProtocol;
    public  boolean isTaskCreationRequired;
    public  int noOfParameters;
    public  int noOfStatesInProtocol;


    public static void main(String[] args) throws Exception {
        APIUtils apiUtils=new APIUtils(driver1);
//        ArrayList<String> arrayList=apiUtils.toGetTheParameterDetailsOfDataCollection("Cookie Measurement");
//        ArrayList<String> arrayList=apiUtils.toGetTheParameterDetailsOfDataCollection("DC AP Console Final Test-CYN0130-100X");
//        System.out.println(arrayList.get(0));
//        System.out.println(arrayList.get(1));
//        String dataCollectionName=apiUtils.toGetTheDataCollectionName("25");
        apiUtils.toGenerateToken();
    }

    public HashMap<String,String> toGetProductMaskThroughAPI(String arg1) throws Exception {
        //Name of the DEE - CustomGetMaskFromProduct
        String products="[\"CYN0070-0596\",\"CYN00803-61185\",\"CYN00803-61340\"]";
        String inputData="{\"$id\": \"1\",\"$type\": \"Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects.ExecuteActionInput, Cmf.Foundation.BusinessOrchestration\",\"Action\": {\"$id\": \"2\",\"$type\": \"Cmf.Foundation.Common.DynamicExecutionEngine.Action, Cmf.Foundation.Common\",\"Name\": \"CustomGetMaskFromProduct\"},\"Input\":{\"$typeCMF\":\"CMFMap\",\"CMFMapData\":[[\"Products\","+arg1+"]]}}";
        System.out.println(inputData);
        String URL="https://nextgenlab.ngl.local/api/DynamicExecutionEngine/ExecuteAction";
        String callType="POST";
        HttpURLConnection postConnection=toConnectToAPI(URL,callType);
        OutputStream os = postConnection.getOutputStream();
        os.write(inputData.getBytes());
        os.flush();
        os.close();
        int responseCode = postConnection.getResponseCode();
        System.out.println("POST Response Code :  " + responseCode);
        System.out.println("POST Response Message : " + postConnection.getResponseMessage());
        if (responseCode == HttpURLConnection.HTTP_OK) { //success
            BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in .readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            //to write the response into a text file
            FileWriter writer = new FileWriter("WriteJSON_Data/API_Output1.txt");
            BufferedWriter buffer = new BufferedWriter(writer);
            buffer.write(response.toString());
            System.out.println("Success");
            buffer.close();
            System.out.println(response.toString());
            // to read the response
            JSONObject obj1 = new JSONObject(response.toString());
            JSONArray productAndItsMask = obj1.getJSONObject("Output").getJSONArray("CMFMapData");
            Iterator<Object> iterator = productAndItsMask.iterator();


            while(iterator.hasNext()) {
                Object productWithMaskObj= iterator.next();
                String productWithMaskStr=productWithMaskObj.toString();
                String[] str=productWithMaskStr.split(",");
                String productWithoutSB=str[0].replace("[","").replaceAll("\"", "");
                String mask=str[1].substring(0, str[1].length() - 1);
                String maskWithoutSB=mask.replaceAll("\"", "");
                String maskOnly=maskWithoutSB.replaceAll("\\]", ",").replaceAll("\\[","").replaceAll(",$","");
                System.out.println("The Product name is "+productWithoutSB+" and its mask is "+maskOnly);
                productAndMaskMap.put(productWithoutSB,maskOnly);
            }

        } else {
            System.out.println("POST NOT WORKED");
        }

        return productAndMaskMap;
    }

    //arg1 - EndURL
    //arg2 - Call Type (POST/GET)
    //input -

    public HttpURLConnection toConnectToAPI(String arg1, String arg2) throws Exception {
        String bearerToken=toGenerateToken();
        SSLverification.execute();
        URL obj = new URL(arg1);
        HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
        postConnection.setRequestMethod(arg2);
        postConnection.setDoOutput(true);
        postConnection.setRequestProperty("Authorization", "Bearer "+bearerToken);
        postConnection.setRequestProperty("Content-Type", "application/json");
        postConnection.setRequestProperty("Cmf_ClientTenantName", "CriticalManufacturing");
        postConnection.setRequestProperty("Cmf_CurrentCulture","en-US");
        postConnection.setRequestProperty("Cmf_Hostname","nextgenlab.ngl.local");
        return postConnection;
    }


    public String toGenerateToken() throws Exception {
        String inputData = "{\"$id\":null,\"$type\":\"Cmf.Foundation.BusinessOrchestration.SecurityManagement.InputObjects.LoginUserInput,Cmf.Foundation.BusinessOrchestration\",\"Domain\":\"NGL\",\"Username\":\"administrator\",\"Password\":\"qaz123WSX\"}";
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("grant_type", "password");
        params.put("username", "NGL\\administrator");
        params.put("password", "qaz123WSX");
        params.put("input",inputData);
        String bearerToken="";

        StringBuilder postData = new StringBuilder();
        for (Map.Entry<String, Object> param : params.entrySet()) {
            if (postData.length() != 0) postData.append('&');
            postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
            postData.append('=');
            postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
        }
        byte[] postDataBytes = postData.toString().getBytes("UTF-8");

        System.out.println(postData);
        System.out.println(params.get("username"));
        String URL="https://nextgenlab.ngl.local/api/token";
        String callType="POST";

        SSLverification.execute();
        URL obj = new URL(URL);
        HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
        postConnection.setRequestMethod(callType);
        postConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        postConnection.setRequestProperty("Cmf_ClientTenantName", "CriticalManufacturing");
        postConnection.setRequestProperty("Cmf_CurrentCulture","en-US");
        postConnection.setRequestProperty("Cmf_Hostname","nextgenlab.ngl.local");
        postConnection.setRequestProperty("Cmf_SessionId","12454577688767");
        postConnection.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
        postConnection.setDoOutput(true);
        OutputStream os = postConnection.getOutputStream();
        os.write(postDataBytes);
        os.flush();
        os.close();
        int responseCode = postConnection.getResponseCode();
        System.out.println("POST Response Code :  " + responseCode);

        if (responseCode == HttpURLConnection.HTTP_OK) { //success
            BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in .readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            System.out.println(response.toString());
            // to read the response
            JSONObject obj1 = new JSONObject(response.toString());
            bearerToken=obj1.getString("access_token");
        } else {
            System.out.println(callType+" Request was not successful, please check");
        }

        return bearerToken;
    }


    public String toGetFlowPathOfProductThroughAPI(String arg1) throws Exception {
//        String arg2="CYN0130-2006";
        String URL="https://nextgenlab.ngl.local/api/GenericService/GetObjectByName?$type=Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects.GetObjectByNameInput,+Cmf.Foundation.BusinessOrchestration&Name="+arg1+"&Type=Product&LevelsToLoad=2";
        String callType="GET";
        String flowPath="";
        HttpURLConnection postConnection=toConnectToAPI(URL,callType);
        int responseCode = postConnection.getResponseCode();
        System.out.println("GET Response Code :  " + responseCode);
        System.out.println("GET Response Message : " + postConnection.getResponseMessage());
        if (responseCode == HttpURLConnection.HTTP_OK) { //success
            BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in .readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            System.out.println(response.toString());
            // to read the response
            JSONObject obj1 = new JSONObject(response.toString());
            flowPath=obj1.getJSONObject("Instance").getString("FlowPath");
            System.out.println("The flow path is "+flowPath);
        } else {
            System.out.println(callType+" Request was not successful, please check");
        }
        return flowPath;
    }

    public HashMap<String,String> productAndItsMaterial = new HashMap<>();

    public HashMap<String, String> toGetTheMaterialAndProductInfo() throws Exception {
        DispatchAndTrackInPage dispatchAndTrackInPage=new DispatchAndTrackInPage(driver1);
//        String mainMaterialName=dispatchAndTrackInPage.mainMaterialName;
        //Name of the API = CustomAssembleProductMaterials
        String mainMaterialName="Material for CYN0130-1000";
        String inputData = "{\n" +
                "\"$id\": \"1\",\n" +
                "\"$type\": \"Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects.ExecuteActionInput, Cmf.Foundation.BusinessOrchestration\",\n" +
                "\"Action\": {\n" +
                "\"$id\": \"2\",\n" +
                "\"$type\": \"Cmf.Foundation.Common.DynamicExecutionEngine.Action, Cmf.Foundation.Common\",\n" +
                "\"Name\": \"CustomAssembleProductMaterials\"\n" +
                "},\n" +
                "\"Input\":{\"$typeCMF\":\"CMFMap\",\"CMFMapData\":[[\"Materials\",[\""+mainMaterialName+"\"]]]}\n" +
                "}";

        System.out.println(inputData);
        String URL="https://nextgenlab.ngl.local/api/DynamicExecutionEngine/ExecuteAction";
        String callType="POST";
        HttpURLConnection postConnection=toConnectToAPI(URL,callType);
        OutputStream os = postConnection.getOutputStream();
        os.write(inputData.getBytes());
        os.flush();
        os.close();
        int responseCode = postConnection.getResponseCode();
        System.out.println("POST Response Code :  " + responseCode);
        System.out.println("POST Response Message : " + postConnection.getResponseMessage());

        if (responseCode == HttpURLConnection.HTTP_OK) { //success
            BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in .readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            System.out.println(response.toString());
            // to read the response
            JSONObject obj1 = new JSONObject(response.toString());
            JSONArray cmfMapData = obj1.getJSONObject("Output").getJSONArray("CMFMapData");
            Iterator<Object> iterator = cmfMapData.iterator();
//            System.out.println("The length of the array "+resultSet.length());

            while(iterator.hasNext()) {
                Object objDropDown= iterator.next();
                ArrayList objects1 = new ArrayList<Object>();
                objects1.add(objDropDown);
                JSONArray jray = new JSONArray();
                for(int i = 0; i < objects1.size(); i++) {
                     jray = (JSONArray) objects1.get(i);
                }

                JSONObject object = jray.getJSONObject(1);
                JSONArray resultSet =object.getJSONArray("T_Result");

                Iterator<Object> iterator1 = resultSet.iterator();
                System.out.println("The length of the array "+resultSet.length());

                while(iterator1.hasNext()) {
                    Object objDropDown1= iterator1.next();
                    String strDropDown=objDropDown1.toString();
                    String value = "{first_name = naresh,last_name = kumar,gender = male}";
                    strDropDown = strDropDown.substring(1, strDropDown.length()-1);
                    String[] keyValuePairs = strDropDown.split(",");              //split the string to create key-value pairs
                    Map<String,String> map = new HashMap<>();

                    for(String pair : keyValuePairs)                        //iterate over the pairs
                    {
                        String[] entry = pair.split(":");                //split the pairs to get key and value
                        String keyEntry=entry[0].trim().replaceAll("\"", "");
                        String valueEntry=entry[1].trim().replaceAll("\"", "");
                        map.put(keyEntry, valueEntry);          //add them to the hashmap and trim whitespaces
                    }
                    String productName= map.get("ProductName");
                    System.out.println(productName);
                    String materialName=map.get("MaterialName");
                    if(materialName.contains("_")){
                        String[] arrMaterial= materialName.split("_");
                        int lengthOfMaterial=arrMaterial[0].length();
                        String productNameWithQuotes="\""+productName+"\"";
                        String productNameWithBracket="["+productNameWithQuotes+"]";
                        HashMap<String, String> productAndMask=this.toGetProductMaskThroughAPI(productNameWithBracket);
                        String strMask=productAndMask.get(productName);
                        System.out.println(strMask);
                        String[] maskDetailsInArray = strMask.split(",");
                        int lengthOfMask=maskDetailsInArray.length;
                        if(lengthOfMaterial==lengthOfMask){
                            productAndItsMaterial.put(productName,materialName);
                        }

                    }
                }

            }
            productAndItsMaterial.entrySet().forEach(entry -> {
                System.out.println(entry.getKey() + " " + entry.getValue());
            });

        } else {
            System.out.println("POST NOT WORKED");
        }

        return productAndItsMaterial;
    }

    //Name of the API = CustomMaterialCreationWithProductForAutomation
    public HashMap<String,String> toGetMaterialsForGivenProducts(String listOfProducts) throws Exception {
        String inputData="{\n" +
                "\"$id\": \"1\",\n" +
                "\"$type\": \"Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects.ExecuteActionInput, Cmf.Foundation.BusinessOrchestration\",\n" +
                "\"Action\": {\n" +
                "\"$id\": \"2\",\n" +
                "\"$type\": \"Cmf.Foundation.Common.DynamicExecutionEngine.Action, Cmf.Foundation.Common\",\n" +
                "\"Name\": \"CustomMaterialCreationWithProductForAutomation\"\n" +
                "},\n" +
                "\"Input\":{\"$typeCMF\":\"CMFMap\",\"CMFMapData\":[[\"Products\","+listOfProducts+"]]}\n" +
                "}";
        System.out.println(inputData);
        String URL="https://nextgenlab.ngl.local/api/DynamicExecutionEngine/ExecuteAction";
        String callType="POST";
        HttpURLConnection postConnection=toConnectToAPI(URL,callType);
        OutputStream os = postConnection.getOutputStream();
        os.write(inputData.getBytes());
        os.flush();
        os.close();
        int responseCode = postConnection.getResponseCode();
        System.out.println("POST Response Code :  " + responseCode);
        System.out.println("POST Response Message : " + postConnection.getResponseMessage());
        if (responseCode == HttpURLConnection.HTTP_OK) { //success
            BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in .readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            // to read the response
            JSONObject obj1 = new JSONObject(response.toString());
            JSONArray productAndItsMask = obj1.getJSONObject("Output").getJSONArray("CMFMapData");
            Iterator<Object> iterator = productAndItsMask.iterator();


            while(iterator.hasNext()) {
                Object productWithMatObj= iterator.next();
                String productWithMatStr=productWithMatObj.toString();
                String[] str=productWithMatStr.split(",");
                String productWithoutSB=str[0].replace("[","").replaceAll("\"", "");
                String material=str[1].substring(0, str[1].length() - 1);
                String materialWithoutSB=material.replaceAll("\"", "");
                String materialName=materialWithoutSB.replaceAll("\\]", ",").replaceAll("\\[","").replaceAll(",$","");
                productAndNewMaterial.put(productWithoutSB,materialName);
            }

        } else {
            System.out.println("POST NOT WORKED");
        }

        productAndNewMaterial.entrySet().forEach(entry -> {
            System.out.println("The name of the product is "+entry.getKey() + " and its new material is this " + entry.getValue());
        });

        return productAndNewMaterial;
    }


    //protocolNameFromUI=protocol name
    //stateNameFromUI=protocol state name
    //Name of the DEE = GetProtocolInformation
    public void toGetTheStatesOfProtocol(String protocolNameFromUI,String stateNameFromUI) throws Exception {
        String inputData="{\"$id\":\"1\",\"$type\":\"Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects.ExecuteActionInput, Cmf.Foundation.BusinessOrchestration\",\"Action\":{\"$id\":\"2\",\"$type\":\"Cmf.Foundation.Common.DynamicExecutionEngine.Action, Cmf.Foundation.Common\",\"Id\":\"2010042224300000039\",\"ActionCode\":\" /** START OF USER-DEFINED CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/\\nUseReference(\\\"Cmf.Foundation.BusinessObjects.dll\\\", \\\"Cmf.Foundation.BusinessObjects\\\");\\nUseReference(\\\"Cmf.Foundation.BusinessOrchestration.dll\\\", \\\"\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Foundation.Common.Exceptions\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Foundation.Common\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Navigo.BusinessObjects\\\");\\n//Please start code here\\nvar protocolName = Input[\\\"New Input Parameter\\\"].ToString();\\nProtocol protocol = new Protocol() { Name = protocolName }; protocol.Load();\\nprotocol.LoadStateDetails();\\nvar output = new Dictionary<String, object>();\\n// var output = new Dictionary<String, Dictionary<String, object>>();\\n\\n// Input.Add(\\\"StateCount\\\", protocol.StateDetails.Count);\\nint count = 1;\\nforeach (var item in protocol.StateDetails)\\n{\\n    var response = new Dictionary<String, object>();\\n    response.Add(\\\"AllowDispositionDecision\\\",item.AllowDispositionDecision);\\n    response.Add(\\\"Parameters\\\",item.Parameters);\\n    response.Add(\\\"DispositionRequiresApproval\\\",item.DispositionRequiresApproval);\\n    response.Add(\\\"Checklist\\\",item.Checklist);\\n    response.Add(\\\"TaskCreation\\\",item.AllowTaskCreation);\\n    // Input.Add(item.Name, \\\"\\\");\\n    if (item.Checklist != null)\\n    {\\n    // Input.Add(\\\"CheckList of State\\\" + item.Name, item.Checklist.Name);\\n    }\\n    if (item.Parameters != null)\\n    {\\n    foreach (var para in item.Parameters)\\n    {\\n    // Input.Add(\\\"Parameter \\\" + count++.ToString() + \\\" of \\\" + para.SourceEntity.Name.ToString(), para.TargetEntity.Name);\\n    }\\n    }\\n    // Input.Add(\\\"DispositionDecision \\\" + item.Name, item.AllowDispositionDecision);\\n    // Input.Add(\\\"RequiresApproval \\\" + item.Name, item.DispositionRequiresApproval);\\n    // output.Add(item.Name, new \\n    Input.Add(item.Name, new \\n    {\\n    AllowDispositionDecision = item.AllowDispositionDecision,\\n    Parameters = item.Parameters,\\n    DispositionRequiresApproval = item.DispositionRequiresApproval,\\n    Checklist = item.Checklist,\\n    TaskCreation = item.AllowTaskCreation\\n    });\\n    output.Add(item.Name, response);\\n}\\nInput.Remove(Input.Keys.First());  \\n// return output;\",\"ActionGroupActions\":[],\"Classification\":\"\",\"Description\":\"\",\"IsEnabled\":true,\"IsSystemRule\":false,\"IsToHideHistory\":false,\"Name\":\"GetProtocolInformation\",\"Version\":14,\"ValidationCode\":\"return true;\",\"IsInDebugMode\":false,\"CreatedOn\":\"2022-05-19T05:28:02.423Z\",\"CreatedBy\":\"ngl\\\\administrator\",\"ModifiedOn\":\"2022-05-19T05:28:02.480Z\",\"ModifiedBy\":\"ngl\\\\administrator\",\"LastServiceHistoryId\":\"2010042224300111492\",\"LastOperationHistorySeq\":\"10\",\"UniversalState\":3,\"ObjectLocked\":false,\"LockType\":0},\"Input\":{\"$typeCMF\":\"CMFMap\",\"CMFMapData\":[[\"New Input Parameter\",\""+protocolNameFromUI+"\"]]}}";
        System.out.println(inputData);
        String URL="https://nextgenlab.ngl.local/api/DynamicExecutionEngine/ExecuteAction";
        String callType="POST";
        HttpURLConnection postConnection=toConnectToAPI(URL,callType);
        OutputStream os = postConnection.getOutputStream();
        os.write(inputData.getBytes());
        os.flush();
        os.close();
        int responseCode = postConnection.getResponseCode();
        System.out.println("POST Response Code :  " + responseCode);
        System.out.println("POST Response Message : " + postConnection.getResponseMessage());
        if (responseCode == HttpURLConnection.HTTP_OK) { //success
            BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in .readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            // to read the response
            JSONObject obj1 = new JSONObject(response.toString());
            JSONArray productAndItsMask = obj1.getJSONObject("Output").getJSONArray("CMFMapData");
            Iterator<Object> iterator = productAndItsMask.iterator();
//            noOfStatesInProtocol=productAndItsMask.length();
            while(iterator.hasNext()) {
                Object objDropDown= iterator.next();
                ArrayList objects1 = new ArrayList<Object>();
                objects1.add(objDropDown);
                JSONArray jray = new JSONArray();
                for(int i = 0; i < objects1.size(); i++) {
                    jray = (JSONArray) objects1.get(i);
                }
                String stateName=jray.getString(0);
                if(stateNameFromUI.equalsIgnoreCase(stateName)){
                    JSONObject object = jray.getJSONObject(1);
                    String fullStateDetails=object.toString();
                    if(fullStateDetails.contains("\"Parameters\":")){
                        JSONArray resultSet =object.getJSONArray("Parameters");
                        noOfParameters =resultSet.length();
//                        if(!resultSet.isEmpty()){
                            isParameterPresentInProtocol=true;
//                        }
                    }
                    if(fullStateDetails.contains("\"Checklist\":")){
                        JSONObject resultSet =object.getJSONObject("Checklist");
                        if(!resultSet.isEmpty()){
                            isCheckListPresentInProtocol=true;
                        }
                    }
                    if(fullStateDetails.contains("AllowDispositionDecision")){
                        strAllowDispositionDecision=object.getBoolean("AllowDispositionDecision");
                    }
                    if(fullStateDetails.contains("DispositionRequiresApproval")){
                        strDispositionRequiresApproval=object.getBoolean("DispositionRequiresApproval");
                    }
                    if(fullStateDetails.contains("TaskCreation")){
                        try {
                            isTaskCreationRequired =object.getBoolean("TaskCreation");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                }
            }

        } else {
            System.out.println("POST NOT WORKED");
        }
    }

    //Name of the DEE = GetProtocolInformation
    public void toGetTheStatesOfProtocol(String protocolNameFromUI) throws Exception {
        String inputData="{\"$id\":\"1\",\"$type\":\"Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects.ExecuteActionInput, Cmf.Foundation.BusinessOrchestration\",\"Action\":{\"$id\":\"2\",\"$type\":\"Cmf.Foundation.Common.DynamicExecutionEngine.Action, Cmf.Foundation.Common\",\"Id\":\"2010042224300000036\",\"ActionCode\":\" /** START OF USER-DEFINED CODE (DO NOT CHANGE OR DELETE THIS LINE!) **/\\nUseReference(\\\"Cmf.Foundation.BusinessObjects.dll\\\", \\\"Cmf.Foundation.BusinessObjects\\\");\\nUseReference(\\\"Cmf.Foundation.BusinessOrchestration.dll\\\", \\\"\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Foundation.Common.Exceptions\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Foundation.Common\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Navigo.BusinessObjects\\\");\\n//Please start code here\\nvar protocolName = Input[\\\"New Input Parameter\\\"].ToString();\\nProtocol protocol = new Protocol() { Name = protocolName }; protocol.Load();\\nprotocol.LoadStateDetails();\\nvar output = new Dictionary<String, object>();\\n// Input.Add(\\\"StateCount\\\", protocol.StateDetails.Count);\\nint count = 1;\\nforeach (var item in protocol.StateDetails)\\n{\\n    // Input.Add(item.Name, \\\"\\\");\\n    if (item.Checklist != null)\\n    {\\n    // Input.Add(\\\"CheckList of State\\\" + item.Name, item.Checklist.Name);\\n    }\\n    if (item.Parameters != null)\\n    {\\n    foreach (var para in item.Parameters)\\n    {\\n    // Input.Add(\\\"Parameter \\\" + count++.ToString() + \\\" of \\\" + para.SourceEntity.Name.ToString(), para.TargetEntity.Name);\\n    }\\n    }\\n    // Input.Add(\\\"DispositionDecision \\\" + item.Name, item.AllowDispositionDecision);\\n    // Input.Add(\\\"RequiresApproval \\\" + item.Name, item.DispositionRequiresApproval);\\n    // output.Add(item.Name, new \\n    Input.Add(item.Name, new \\n    {\\n    AllowDispositionDecision = item.AllowDispositionDecision,\\n    Parameters = item.Parameters,\\n    DispositionRequiresApproval = item.DispositionRequiresApproval,\\n    Checklist = item.Checklist,\\n    });\\n}\\nInput.Remove(Input.Keys.First());  \",\"ActionGroupActions\":[],\"Classification\":\"\",\"Description\":\"\",\"IsEnabled\":true,\"IsSystemRule\":false,\"IsToHideHistory\":false,\"Name\":\"GetProtocolInformation\",\"Version\":11,\"ValidationCode\":\"return true;\",\"IsInDebugMode\":false,\"CreatedOn\":\"2022-05-12T10:17:34.120Z\",\"CreatedBy\":\"ngl\\\\administrator\",\"ModifiedOn\":\"2022-05-12T10:17:34.273Z\",\"ModifiedBy\":\"ngl\\\\administrator\",\"LastServiceHistoryId\":\"2010042224300107631\",\"LastOperationHistorySeq\":\"10\",\"UniversalState\":3,\"ObjectLocked\":false,\"LockType\":0},\"Input\":{\"$typeCMF\":\"CMFMap\",\"CMFMapData\":[[\"New Input Parameter\",\""+protocolNameFromUI+"\"]]}}";
        System.out.println(inputData);
        String URL="https://nextgenlab.ngl.local/api/DynamicExecutionEngine/ExecuteAction";
        String callType="POST";
        HttpURLConnection postConnection=toConnectToAPI(URL,callType);
        OutputStream os = postConnection.getOutputStream();
        os.write(inputData.getBytes());
        os.flush();
        os.close();
        int responseCode = postConnection.getResponseCode();
        System.out.println("POST Response Code :  " + responseCode);
        System.out.println("POST Response Message : " + postConnection.getResponseMessage());
        if (responseCode == HttpURLConnection.HTTP_OK) { //success
            BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in .readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            // to read the response
            JSONObject obj1 = new JSONObject(response.toString());
            JSONArray productAndItsMask = obj1.getJSONObject("Output").getJSONArray("CMFMapData");
            Iterator<Object> iterator = productAndItsMask.iterator();
            noOfStatesInProtocol=productAndItsMask.length();
            while(iterator.hasNext()) {
                Object objDropDown= iterator.next();
                ArrayList objects1 = new ArrayList<Object>();
                objects1.add(objDropDown);
                JSONArray jray = new JSONArray();
                for(int i = 0; i < objects1.size(); i++) {
                    jray = (JSONArray) objects1.get(i);
                }
                String stateName=jray.getString(0);
            }

        } else {
            System.out.println("POST NOT WORKED");
        }
    }

    //Name of the DEE = LoadDataCollectionParameter
    public ArrayList<String> toGetTheParameterDetailsOfDataCollection(String arg1, String arg2) throws Exception {
        String inputData="{\"$id\":\"1\",\"$type\":\"Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects.ExecuteActionInput, Cmf.Foundation.BusinessOrchestration\",\"Action\":{\"$id\":\"2\",\"$type\":\"Cmf.Foundation.Common.DynamicExecutionEngine.Action, Cmf.Foundation.Common\",\"Id\":\"2010042224300000043\",\"ActionCode\":\"UseReference(\\\"Cmf.Foundation.BusinessObjects.dll\\\", \\\"Cmf.Foundation.BusinessObjects\\\");\\nUseReference(\\\"Cmf.Foundation.BusinessOrchestration.dll\\\", \\\"\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Foundation.Common.Exceptions\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Foundation.Common\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Navigo.BusinessObjects\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Navigo.BusinessOrchestration.EdcManagement.DataCollectionManagement.InputObjects\\\");\\n//Please start code here\\nstring dataCollectionName = Input[\\\"DataCollection\\\"] as string;\\n\\nDataCollection collection = new DataCollection();\\ncollection.Load(dataCollectionName);\\n\\nLoadDataCollectionParameterInformationInput loadDataCollectionParameter = new LoadDataCollectionParameterInformationInput();\\nloadDataCollectionParameter.DataCollection = collection;\\nloadDataCollectionParameter.LevelsToLoad = 2;\\n\\n//Loads DataCollectionParameterInformation\\nvar parameterOutput = Navigo.BusinessOrchestration.EdcManagement.DataCollectionManagement.DataCollectionManagementOrchestration.LoadDataCollectionParameterInformation(loadDataCollectionParameter);\\n\\nif (parameterOutput == null || parameterOutput?.DataCollection?.RelationCollection == null)\\n    return Input;\\n\\n//Read the collection of parameters of given DataCollection\\nvar parameterList = (from entityRlnCollection in parameterOutput?.DataCollection?.DataCollectionParameters \\n                        select entityRlnCollection).ToList();\\n\\nif (parameterList == null)\\n    return Input;\\n\\nInput.Add(\\\"Parameters\\\", parameterList);\\nreturn Input;\",\"ActionGroupActions\":[],\"Classification\":\"\",\"Description\":\"\",\"IsEnabled\":true,\"IsSystemRule\":false,\"IsToHideHistory\":false,\"Name\":\"LoadDataCollectionParameter\",\"Version\":4,\"ValidationCode\":\"if (!(Input[\\\"DataCollection\\\"] is string))\\r\\n            {\\r\\n                return false;\\r\\n            }\\r\\n            return true;\",\"IsInDebugMode\":false,\"CreatedOn\":\"2022-05-31T11:18:53.507Z\",\"CreatedBy\":\"ngl\\\\administrator\",\"ModifiedOn\":\"2022-05-31T11:18:53.577Z\",\"ModifiedBy\":\"ngl\\\\administrator\",\"LastServiceHistoryId\":\"2010042224300115842\",\"LastOperationHistorySeq\":\"10\",\"UniversalState\":3,\"ObjectLocked\":false,\"LockType\":0},\"Input\":{\"$typeCMF\":\"CMFMap\",\"CMFMapData\":[[\"DataCollection\",\""+ arg1 +"\"]]}}";
        System.out.println(inputData);
        String URL="https://nextgenlab.ngl.local/api/DynamicExecutionEngine/ExecuteAction";
        String callType="POST";
        String parameterName="";
        HttpURLConnection postConnection=toConnectToAPI(URL,callType);
        OutputStream os = postConnection.getOutputStream();
        os.write(inputData.getBytes());
        os.flush();
        os.close();
        int responseCode = postConnection.getResponseCode();
        System.out.println("POST Response Code :  " + responseCode);
        System.out.println("POST Response Message : " + postConnection.getResponseMessage());

        if (responseCode == HttpURLConnection.HTTP_OK) { //success
            BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in .readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            // to read the response
            JSONObject obj1 = new JSONObject(response.toString());
            JSONArray productAndItsMask = obj1.getJSONObject("Output").getJSONArray("CMFMapData");
            Iterator<Object> iterator = productAndItsMask.iterator();
            ArrayList objects1 = new ArrayList<Object>();

            while(iterator.hasNext()) {
                Object objDropDown= iterator.next();
                objects1.add(objDropDown);
            }
            JSONArray jray= (JSONArray) objects1.get(1);
            JSONArray jray1= (JSONArray) jray.get(1);
            for(int i=0;i< jray.length();i++){
                JSONObject obj2= (JSONObject) jray1.get(i);
                JSONObject obj3=obj2.getJSONObject("TargetEntity");
                String strObj3=obj3.toString();
                if(strObj3.contains("\"Name\":")){
                     parameterName=obj3.getString("Name");
                }
                if(parameterName.equals(arg2)){
                    if(strObj3.contains("\"DataNumValidationMax\":")){
                        BigDecimal bd= (BigDecimal) obj3.get("DataNumValidationMax");
                        String strMaxValue=bd.toString();
                        String[] strArrayMax=strMaxValue.split("[.]");
                        arrayListOfHiddenLimitRange.add(strArrayMax[0]);
                        System.out.println(strMaxValue);
                    }
                    if(strObj3.contains("\"DataNumValidationMin\":")){
                        BigDecimal bd1= (BigDecimal) obj3.get("DataNumValidationMin");
                        String strMinValue=bd1.toString();
                        String[] strArrayMin=strMinValue.split("[.]");
                        arrayListOfHiddenLimitRange.add(strArrayMin[0]);
                        System.out.println(strMinValue);
                    }
                    if(!arrayListOfHiddenLimitRange.isEmpty()){
                        System.out.println(arrayListOfHiddenLimitRange);
                        break;
                    }
                }


            }

        } else {
            System.out.println("POST NOT WORKED");
        }
        return arrayListOfHiddenLimitRange;
    }

    //Name of the DEE = CustomDEEToGetMaintenanceActivityDetails
    public String toGetTheDataCollectionName(String arg1) throws Exception {
        String inputData="{\"$id\":\"1\",\"$type\":\"Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects.ExecuteActionInput, Cmf.Foundation.BusinessOrchestration\",\"Action\":{\"$id\":\"2\",\"$type\":\"Cmf.Foundation.Common.DynamicExecutionEngine.Action, Cmf.Foundation.Common\",\"Id\":\"2010042224300000061\",\"ActionCode\":\"UseReference(\\\"Cmf.Foundation.BusinessObjects.dll\\\", \\\"Cmf.Foundation.BusinessObjects\\\");\\nUseReference(\\\"Cmf.Foundation.BusinessOrchestration.dll\\\", \\\"\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Foundation.Common.Exceptions\\\");\\nUseReference(\\\"\\\", \\\"Cmf.Foundation.Common\\\");\\nUseReference(\\\"Cmf.Foundation.BusinessObjects.dll\\\", \\\"Cmf.Foundation.BusinessObjects\\\");\\nUseReference(\\\"Cmf.Navigo.BusinessObjects.dll\\\", \\\"Cmf.Navigo.BusinessObjects\\\");\\n\\n//Please start code here\\nstring dcName=string.Empty;\\nstring maoName = Input[\\\"MaintenanceActivityOrder\\\"] as string;\\nMaintenanceActivityOrder mao = new MaintenanceActivityOrder(){Name = maoName};\\nmao.Load();\\nif(mao.DataCollectionInstance!=null){\\nDataCollection dc = mao.DataCollectionInstance.DataCollection;\\nif(dc.ObjectExists()){\\ndc.Load();\\ndcName=dc.Name;\\nmao.LoadRelations(dc);\\n}\\n}\\nInput.Add(\\\"Response\\\", mao);\\nInput.Add(\\\"DataCollectionName\\\", dcName);\\n\\n\",\"ActionGroupActions\":[],\"Classification\":\"\",\"Description\":\"\",\"IsEnabled\":true,\"IsSystemRule\":false,\"IsToHideHistory\":false,\"Name\":\"CustomDEEToGetMaintenanceActivityDetails\",\"Version\":18,\"ValidationCode\":\"return true;\",\"IsInDebugMode\":false,\"CreatedOn\":\"2022-06-09T08:20:49.800Z\",\"CreatedBy\":\"ngl\\\\administrator\",\"ModifiedOn\":\"2022-06-09T08:20:49.887Z\",\"ModifiedBy\":\"ngl\\\\administrator\",\"LastServiceHistoryId\":\"2010042224300128650\",\"LastOperationHistorySeq\":\"10\",\"UniversalState\":3,\"ObjectLocked\":false,\"LockType\":0},\"Input\":{\"$typeCMF\":\"CMFMap\",\"CMFMapData\":[[\"MaintenanceActivityOrder\",\""+arg1+"\"]]}}";
        System.out.println(inputData);
        String dataCollectionName="";
        String URL="https://nextgenlab.ngl.local/api/DynamicExecutionEngine/ExecuteAction";
        String callType="POST";
        String parameterName="";
        HttpURLConnection postConnection=toConnectToAPI(URL,callType);
        OutputStream os = postConnection.getOutputStream();
        os.write(inputData.getBytes());
        os.flush();
        os.close();
        int responseCode = postConnection.getResponseCode();
        System.out.println("POST Response Code :  " + responseCode);
        System.out.println("POST Response Message : " + postConnection.getResponseMessage());
        ArrayList arrayList = new ArrayList<String>();
        if (responseCode == HttpURLConnection.HTTP_OK) { //success
            BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in .readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            // to read the response
            JSONObject obj1 = new JSONObject(response.toString());
            JSONArray productAndItsMask = obj1.getJSONObject("Output").getJSONArray("CMFMapData");
            Iterator<Object> iterator = productAndItsMask.iterator();
            ArrayList objects1 = new ArrayList<Object>();
            ArrayList objects2 = new ArrayList<Object>();
            while(iterator.hasNext()) {
                Object objDropDown= iterator.next();
                objects1.add(objDropDown);
            }
            JSONArray jray= (JSONArray) objects1.get(2);
            dataCollectionName= (String) jray.get(1);


        } else {
            System.out.println("POST NOT WORKED");
        }
        return dataCollectionName;
    }

}
