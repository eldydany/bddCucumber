package utils;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.HashMap;
import java.util.Iterator;

public class JSONReader {

    public static void main(String[] args) {
        JSONReader jsonReader=new JSONReader();
        jsonReader.toReadJSONFile();
    }

    public void toReadJSONFile(){
        String jsonString="";
        File fileName=new File("WriteJSON_Data/API_Output1.txt");
        FileInputStream inputStream = null;
        try {
            inputStream = new FileInputStream(fileName);
            jsonString = IOUtils.toString(inputStream);
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //assign your JSON String here
        JSONObject obj = new JSONObject(jsonString);
        JSONArray productAndItsMask = obj.getJSONObject("Output").getJSONArray("CMFMapData");
        Iterator<Object> iterator = productAndItsMask.iterator();
        HashMap<String,String> productAndMaskMap=new HashMap<String, String>();

        while(iterator.hasNext()) {
           Object productWithMaskObj= iterator.next();
           String productWithMaskStr=productWithMaskObj.toString();
           String[] str=productWithMaskStr.split(",");
           String productWithoutSB=str[0].replace("[","").replaceAll("\"", "");
           String mask=str[1].substring(0, str[1].length() - 1);
           String maskWithoutSB=mask.replaceAll("\"", "");
           productAndMaskMap.put(productWithoutSB,maskWithoutSB);
        }
//        productAndItsMask.getJSONArray(Integer.parseInt("CYN0070-0596"));
//        System.out.println(maskValue1);
    }

}
