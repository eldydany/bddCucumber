package utils;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.google.common.base.Predicate;
import helper.Constants;
import managers.ExtentManager;
import managers.ExtentTestManager;
import managers.FileReaderManager;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

public class CommonUtils {

    private WebDriver driver1;
    private String timeStamp;

    public CommonUtils(WebDriver driver){
        this.driver1=driver;

    }


    /**
     * This method is used to verify wait for page load.
     *
     * @return boolean value
     */
    public boolean waitForPageLoad() {

        long startTime = System.currentTimeMillis();
        long waitTime = 120000;
        String pageLoadStatus = null;
        try {
            do {
                JavascriptExecutor js = (JavascriptExecutor) driver1;
                pageLoadStatus = (String) js.executeScript("return document.readyState");
                System.out.print((System.currentTimeMillis() - startTime));

                if ((System.currentTimeMillis() - startTime) > waitTime) {
                    System.out.println("timeout completed " + waitTime + "ms");
                    return false;
                }
                System.out.println("waiting for page load");
                Thread.sleep(3000);
            } while (!pageLoadStatus.equals("complete"));
            System.out.println("Page Loaded correctly");

        } catch (Exception e) {
            System.out.println("some Exeption happened during page load:::::" + e.toString());
        }
        return true;
    }


    /**
     * This method id used to wait for web page loading status(progress)
     *
     * @param driver
     * @param startTime
     * @param endTime
     * @return boolean
     */
    public boolean waitForPageIsLoadingProgress(WebDriver driver, long startTime, long endTime) {
        boolean flag = true;
        String spinnerAppearing = "<div class=\"spinner\" ng-show=\"isLoading\">";
        while ((driver.getPageSource().contains(spinnerAppearing))) {
            if (System.currentTimeMillis() > endTime) {
                flag = false;
                System.out.println("Spinner is appearing");
            }
            try {
                Thread.sleep(30);
            } catch (Exception e) {
            }
        }
        return flag;
    }

    /**
     * This method id used to wait for page load with dynamic web control.
     *
     * @param element
//     * @param validationstring
     * @return boolean value
     */
    public boolean waitForPageLoadwithDynamicControl(WebElement element) {
        long startTime = System.currentTimeMillis();
        long endTime = startTime + 60 * 1000;
        boolean flag = false;
        boolean isPageReadyForValidation = true;
        if (waitForPageIsLoadingProgress(driver1, startTime, endTime) == false) {
            System.out.println("spinner is appearing");
            isPageReadyForValidation = false;
        }
        if (waitForPageLoad() == false) {
            System.out.println("not loaded in given time");
            isPageReadyForValidation = false;
        }

        if (isPageReadyForValidation == true) {
            if (isElementPresent(element)) {

//                if (ee.getText().trim().contains(validationstring))
                    flag = true;

            }else
                flag = false;
        }
        return flag;
    }

    /**
     * isElementPresent(WebElement e) Method to validate a particular webelement
     * is available on webpage or not
     */
    public boolean isElementPresent(WebElement e) {
        try {
            if (e == null) {
                System.out.println("Control does not exist on page");
                return false;
            }

            if (e.isEnabled() == false) {
                System.out.println("Element not displayed");
                return false;
            }
        } catch (NoSuchElementException nsee) {

            System.out.println(e.toString() + " is not available");
            return false;
        }
        System.out.println("Information ::::Element "+e.getText()+" is available for further actions");
        return true;
    }

    public void toGetAPIResponse() throws IOException {
        URL obj = new URL("https://nextgenlab.ngl.local/Home");
        HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
        postConnection.setRequestMethod("GET");
        postConnection.connect();
        int code=postConnection.getResponseCode();
//        postConnection.setRequestProperty("Username", Username);
//        postConnection.setRequestProperty("UserId", UserId);
//        postConnection.setRequestProperty("Content-Type", "application/json");
//        postConnection.setDoOutput(true);
//        OutputStream os = postConnection.getOutputStream();
//        os.write(postInputData.getBytes());
//        os.flush();
//        os.close();
//        int responseCode = postConnection.getResponseCode();
        System.out.println("GET Response Code : " + code);
        System.out.println("GET Response Message : " + postConnection.getResponseMessage());

    }

    public String getTime() {

        Date d = new Date();
        String date = d.toString().replaceAll(" ", "_");
        date = date.replaceAll(":", "_");
        date = date.replaceAll("\\+", "_");
        //System.out.println(date.toString());

        return date.toString();

    }

    //This method returns date in the below format
    public String getCurrentDate(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        System.out.println(dtf.format(now));
        return dtf.format(now);
    }

    //This method returns a date in future from current date
    public String getFutureDate(long arg1){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        System.out.println(dtf.format(now));
        LocalDateTime now1 =now.plusDays(arg1);
        System.out.println(dtf.format(now1));
        return dtf.format(now1);
    }

    public static String getProperty(String propPath,String propName)  {
        FileInputStream fis=null;

        try {
            fis = new FileInputStream(propPath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Properties prop=new Properties();

        try {
            prop.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  prop.getProperty(propName);
    }

    /**
     * This method id used to clicking on object
     *
     * @param e
     * @param objectname
     * @return
     */
    public boolean clickOnObject(WebElement e, String objectname) {

        try {

            if (e == null) {
                System.out.println(objectname + "does not exist on webpage");
                ExtentTestManager.getTest().fail(objectname + " does not exist on webpage",MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
                return false;
            }

        } catch (Exception exception) {

        }

        try {
//            e = waitForElementToBeDisplayed(e, 40);
            e = waitForElementToBeDisplayed(e, 7);
            if (isElementPresent(e)) {
                if (e != null) {
                    e.click();
                    System.out.println("Clicked on this object "+objectname);
                }
            }
        } catch (Exception exception3) {
            e.click();

        }
        System.out.println("Clicked the " + objectname);
        return true;

    }

    /**
     * This method id used to clicking on object
     *
     * @param e
     * @param objectname
     * @return
     */
    public boolean clickOnObject(WebElement e, String objectname, boolean bool) {
        String object= e.getText();
        try {
            //String s;
            if (e == null) {
                System.out.println(objectname + "does not exist on webpage");
//                ExtentTestManager.getTest().fail(objectname + " does not exist on webpage",MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
                return false;
            }

        } catch (Exception exception) {

        }
        boolean isClickDone = false;
        try {
            e = waitForElementToBeDisplayed(e, 40);
            if (isElementPresent(e)) {
                if (e != null) {
                    e.click();
                    System.out.println("Clicked on this object "+objectname);
                    if(bool){
                        ExtentTestManager.getTest().pass("Clicked on this object "+objectname,MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
                    }
//                    else{
//                        ExtentTestManager.getTest().pass("Clicked on this object "+objectname);
//                    }
                }
            }
        } catch (Exception exception3) {
            e.click();
            System.out.println("clicked on " + e.getText());
            System.out.println("Some Exception has Occured ");
        }
		/*if (isClickDone == false) {
			return false;
		}*/
        System.out.println("Clicked the " + objectname);
        return true;
    }

    /**
     * This method is used to wait for web element to be displayed in given time
     *
     * @param element
     * @param timeInSeconds
     * @return WebElement
     */
    public WebElement waitForElementToBeDisplayed(WebElement element, int timeInSeconds) {
        try {
            WebDriverWait wait = new WebDriverWait(driver1, timeInSeconds);
            element = wait.until(ExpectedConditions.elementToBeClickable(element));
            if (element != null && element.isDisplayed()) {

                return element;
            } else {
                return null;
            }
        } catch (NoSuchElementException e) {
            System.out.println("FAIL" + "--No Such Element Exception--");
            e.printStackTrace();
            return null;

        } catch (StaleElementReferenceException e) {
            System.out.println("FAIL" + "--Stale Element Exception--");
            e.printStackTrace();
            return null;
        } catch (TimeoutException toe) {
            System.out.println("FAIL" + "--Time Out Exception--");
            toe.printStackTrace();
            return null;
        }

    }

    /**
     * This method is used to wait for web element to disappear in given time
     *
     * @param by
     * @param time
     * @return WebElement
     */
    public void waitTillElementDisappears(By by, int time){
        WebDriverWait wait = new WebDriverWait(driver1, 150);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
        Predicate<WebDriver> pageLoaded = new Predicate<WebDriver>() {
            @Override
            public boolean apply(WebDriver input) {
                return ((JavascriptExecutor) input).executeScript("return document.readyState").equals("complete");
            }

        };
        // wait.until(pageLoaded);
		/*wait.until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				System.out.println("Current Window State :"+ String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")));
				return String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")).equals("complete");
			}
		});*/
    }

    /**
     * This method is used to set the object value
     *
     * @param e
     * @param objectname
     * @param objValue
     * @return
     */
    public boolean setObjectValue(WebElement e, String objectname, String objValue) {
        boolean isSetDone = false;
        try {
            e = waitForElementToBeDisplayed(e, 40);
            if (e != null) {
                e.clear();
                e.sendKeys(objValue);
                System.out.println("Entered this value "+objValue+" in this object "+objectname);
//                ExtentTestManager.getTest().log(Status.PASS,"Entered this value "+objValue+" in this object "+objectname, MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
                isSetDone = true;
            }
        } catch (Exception exception3) {
            System.out.println("Some Exception happened ");
        }
        if (isSetDone == false) {
            return false;
        }
        System.out.println(objectname + " Value is set to :-" + objValue);
        return true;
    }

    /**
     * This method is used to set the object value
     *
     * @param e
     * @param objectname
     * @param objValue
     * @return
     */
    public boolean setObjectValue(WebElement e, String objectname, String objValue, boolean bool) {
        boolean isSetDone = false;
        try {
            e = waitForElementToBeDisplayed(e, 40);
            if (e != null) {
                e.clear();
                e.sendKeys(objValue);
                System.out.println("Entered this value "+objValue+" in this object "+objectname);
                if(true){
                    ExtentTestManager.getTest().log(Status.PASS,"Entered this value "+objValue+" in this object "+objectname, MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
                }
//                else{
//                    ExtentTestManager.getTest().log(Status.PASS,"Entered this value "+objValue+" in this object "+objectname);
//                }

                isSetDone = true;
            }
        } catch (Exception exception3) {
            System.out.println("Some Exception happened ");
        }
        if (isSetDone == false) {
            return false;
        }
        System.out.println(objectname + " Value is set to :-" + objValue);
        return true;
    }

    public File addScreenshot( )  {

        return ((TakesScreenshot) driver1).getScreenshotAs(OutputType.FILE);

    }

    public String getScreenshotPath(){
        String val=null;

            Date d = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
            String pathWithDate = dateFormat.format(d).replace(" ", "_");
            String screenShotName = pathWithDate + ".png";
            String fileSeperator = System.getProperty("file.separator");
            File source = ((TakesScreenshot) driver1).getScreenshotAs(OutputType.FILE);
            String reportFileName = ExtentManager.reportFilepath;
            String path = reportFileName + screenShotName;

            System.out.println("The dest path is " + path);
            try {
                FileUtils.copyFile(source, new File(path));
            } catch (IOException e) {
                e.printStackTrace();
            }

            StringBuilder href = new StringBuilder();
            val = href.append(screenShotName).toString();

        return val;
    }
    
    public String getScreenshotAsBase64() throws IOException {

        File source= ((TakesScreenshot) driver1).getScreenshotAs(OutputType.FILE);
        Date d =new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss") ;
        String fileName=dateFormat.format(d).replace(" ","_")+".png";
        String path="/TestReport/../Screenshots/"+fileName;
        FileUtils.copyFile(source,new File(path));
        byte[] imageBytes=IOUtils.toByteArray(new FileInputStream(path));
        
        return Base64.getEncoder().encodeToString(imageBytes);

    }

    public String getBase64(){
        return ((TakesScreenshot) driver1).getScreenshotAs(OutputType.BASE64);
    }

    public String getScreenshotPathTest(String screenshotFlag){
        String val=null;
        if(screenshotFlag.contains("true")) {
            Date d = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
            String pathWithDate = dateFormat.format(d).replace(" ", "_");
            String screenShotName = pathWithDate + ".png";
            String fileSeperator = System.getProperty("file.separator");
            File source = ((TakesScreenshot) driver1).getScreenshotAs(OutputType.FILE);
            String reportFileName = ExtentManager.reportFilepath;
            String path = reportFileName + screenShotName;

            System.out.println("The dest path is " + path);
            try {
                FileUtils.copyFile(source, new File(path));
            } catch (IOException e) {
                e.printStackTrace();
            }

            StringBuilder href = new StringBuilder();
            val = href.append(screenShotName).toString();
        }else{
            StringBuilder href = new StringBuilder();
//            val="<img data-featherlight='.' src='.'>";
            val = href
                    .append("<div></div>")
                    .toString();
        }
        return val;
    }

    public void toLogIntoExtentReport(Status status,String str,boolean takeScreenshotFlag, String exception){

        if(takeScreenshotFlag){
            ExtentTestManager.getTest().log(status,str+ " Exception --> "+exception, MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
        }
        else{
            ExtentTestManager.getTest().log(status,str);
        }
    }

    public void toLogIntoExtentReport(Status status,String str,boolean bool){

        if(bool){
            ExtentTestManager.getTest().log(status,str, MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
        }
        else{
            ExtentTestManager.getTest().log(status,str);
        }
    }

    public void toLogIntoExtentReport(Status status,String str){
        boolean bool=FileReaderManager.getInstance().getConfigReader().getScreenShotAccess();
        if(bool){
            ExtentTestManager.getTest().log(status,str, MediaEntityBuilder.createScreenCaptureFromPath(getScreenshotPath()).build());
        }
        else{
            ExtentTestManager.getTest().log(status,str);
        }
    }

    public void toHandleLoaderSpinner(WebElement element) {

        try{
            for(int i=0;i<=30;i++){
                boolean bool=element.getAttribute("innerHTML").contains("cmf-loading-cmf-logo");
                if(bool){
                    System.out.println("The spinner loader has disappeared");
                    break;
                }else{
                    Thread.sleep(Constants.HIGH_WAIT_TIME);
                }
            }
        }catch(Exception e){

        }
    }

    /**
     * method to handle scrolling to a particular webelement
     *
     * @param e
     *Webelement e
     *
     */
    public void scrollIntoViewPage(WebElement e) {

        ((JavascriptExecutor) driver1).executeScript("arguments[0].scrollIntoView();", e);
    }

    public char toGenerateRandomCharacterFromAtoZ(){
        Random r = new Random();
        char c = (char)(r.nextInt(26) + 'A');
        return c;
    }

    /**
     * The below method is to generate random number in given range
     * @return int.
     * @author Vijay Y
     * @args min,max
     */
    public int toGenerateRandomNumberInGivenRange(int min, int max){
        int a = (int)(Math.random()*(max-min+1)+min);
        System.out.println("The generated random number is "+a);
        return a;
    }

    /**
     * The below method is to generate random number in given range
     * @return int.
     * @author Vijay Y
     * @args min,max
     */
    public void toRightClickOnTheWebElement(WebElement element){
        Actions actions=new Actions(driver1);
        actions.contextClick(element).build().perform();
    }

    /**
     * The below method is to find if the given date is in future date or not
     * @return int.
     * @author Vijay Y
     * @args DateFormat (MM-dd-yyyy),Date
     */

    public static boolean isDateFuture(final String date, final String dateFormat) {
        LocalDate localDate = LocalDate.now(ZoneId.systemDefault());

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(dateFormat);
        LocalDate inputDate = LocalDate.parse(date, dtf);

        return inputDate.isAfter(localDate);
    }

    /**
     * The below method is to find if the given date is a past date or not
     * @return int.
     * @author Vijay Y
     * @args DateFormat (MM-dd-yyyy),Date
     */

    public static boolean isDatePast(final String date, final String dateFormat) {
        LocalDate localDate = LocalDate.now(ZoneId.systemDefault());

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(dateFormat);
        LocalDate inputDate = LocalDate.parse(date, dtf);

        return inputDate.isBefore(localDate);
    }

    /**
     * The below method is to find if the given date is today's date or not
     * @return int.
     * @author Vijay Y
     * @args DateFormat (MM-dd-yyyy),Date
     */

    public static boolean isDateToday(final String date, final String dateFormat) {
        LocalDate localDate = LocalDate.now(ZoneId.systemDefault());

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(dateFormat);
        LocalDate inputDate = LocalDate.parse(date, dtf);

        return inputDate.isEqual(localDate);
    }








}
