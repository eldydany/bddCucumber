package pageObjects;

import managers.FileReaderManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import utils.APIUtils;
import utils.CommonUtils;
import utils.ExcelReader;
import utils.ExcelUtils;

import java.util.*;

public class DataCreationPage {

    private WebDriver driver1;
    CommonUtils commonUtils;
    APIUtils apiUtils;


    public DataCreationPage(WebDriver driver){
        this.driver1=driver;
        PageFactory.initElements(driver,this);
        commonUtils=new CommonUtils(driver);
        apiUtils=new APIUtils(driver);
    }

    public HashSet<String> listOfProducts=new HashSet<String>();
    public String strListOfProducts;
    public String filePath;
    public HashMap<String,String> productAndNewMaterial;

    public void toReadTheDataFromTheInputSheet(String sheetName) throws Exception {
        ExcelReader reader=new ExcelReader();
        filePath = FileReaderManager.getInstance().getConfigReader().getInputFilePath();
        List<Map<String, String>> testData= reader.getData(filePath,sheetName);
        for(int i=0;i<testData.size()-1;i++){
            String product=testData.get(i).get("Product");
            if(!product.equalsIgnoreCase("")){
                listOfProducts.add("\""+product+"\"");
            }
        }
        System.out.println(listOfProducts);
        strListOfProducts=listOfProducts.toString();
        System.out.println(strListOfProducts);
    }

    public void toCreateMaterialsThroughAPI() throws Exception {
        APIUtils apiUtils=new APIUtils(driver1);
        productAndNewMaterial= apiUtils.toGetMaterialsForGivenProducts(strListOfProducts);
    }


    public void toWriteTheMaterialNamesIntoTheInputSheet(String sheetName) throws Exception {
        ExcelUtils excel = new ExcelUtils();
        excel.setExcelFile(filePath, sheetName);
        for(int i=1;i< excel.getRows();i++){
            String productName=excel.getCellData("Product", i);
            String materialName=productAndNewMaterial.get(productName);
            excel.setCellData(materialName,i,2);
        }
    }
}
