package pageObjects;


import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import helper.Constants;
import managers.ExtentTestManager;
import managers.FileReaderManager;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.APIUtils;
import utils.CommonUtils;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.*;

/**
 * To store all the web elements involved in Dispatch and TrackIn
 * To dispatch and track-in into a step
 * @author  Vijay Y
 * @version 1.0
 * @since   2021-11-01
 */

public class DispatchAndTrackInPage {

    private WebDriver driver1;
    CommonUtils commonUtils;
    public String isLastStep="";
    APIUtils apiUtils;


    public DispatchAndTrackInPage(WebDriver driver){
        this.driver1=driver;
        PageFactory.initElements(driver,this);
        commonUtils=new CommonUtils(driver);
        apiUtils=new APIUtils(driver);
    }

    @FindBy(xpath = "//./cmf-core-controls-actionbutton/div[@title='Dispatch and Track-In']")
    WebElement dispatchAndTrackInWizardButton;

    @FindBy(xpath = "//cmf-core-controls-actionbar/div[@class='cmf-core-controls-actionBar-main-container']")
    WebElement parentTagOfActionBar;

    @FindBy(xpath = "//cmf-core-controls-actionbar//div[@title='Abort' and not(contains(@disabled,'true'))]")
    WebElement abortButton;

    @FindBy(xpath = "//button[@data-action='finish']")
    WebElement abortCompletionButton;

    @FindBy(xpath = "//./cmf-core-controls-actionbutton/div[@title='Dispatch']")
    WebElement dispatchAloneButton;

    @FindBy(xpath = "//./cmf-core-controls-actionbutton/div[@title='Track-In']")
    WebElement trackInAloneButton;

    @FindBy(xpath = "//./cmf-core-controls-actionbuttongroup//div[@title='Assemble']")
    WebElement assembleWizardInHeader;

    @FindBy(xpath = "//./cmf-core-controls-actionbuttongroupbutton//div[@title='Assemble']")
    WebElement assembleOptionInDropDown;

    @FindBy(xpath = "//div[text()='Assembly Details']")
    WebElement assemblyDetailsLabel;

    @FindBy(xpath = "//div[@class='spinner-input']/input[@type='text']")
    WebElement quantityToAssemble;

    @FindBy(xpath = "//cmf-core-business-controls-propertyviewer[@data-propertyname='RemainingQuantity']//div[@class='text symbolAvailable']")
    WebElement remainingQuantityLabel;

    @FindBy(xpath = "//div[@data-action='add']")
    WebElement addMaterialButton;

    @FindBy(xpath = ".//cmf-core-business-controls-findentity[@entity-type='Material']//div[@title='Search']")
    WebElement searchMaterialButton;

    @FindBy(xpath = "//div[@style='height: auto;']/ul[@role='listbox']/li[@data-offset-index='0']")
    WebElement firstOptionInSearchMaterialDropdown;

    @FindBy(xpath="(//./cmf-core-business-controls-propertyviewer[@data-label='Name'])[1]")
    WebElement resourceNameLabel;

    @FindBys(@FindBy(xpath="//cmf-core-controls-columnviewcolumn[@class='selected']//cmf-core-controls-columnviewrow"))
    List<WebElement> emptyProduct;

    @FindBy(xpath="//cmf-core-controls-columnviewcolumn[@class='selected']//cmf-core-controls-columnviewrow[@hasvalue='false']//div[@data-action='remove']")
    WebElement deleteButtonOfEmptyProduct;

    @FindBy(xpath = "//button[text()='Dispatch']")
    WebElement dispatchButton;

    @FindBy(xpath = "(//./cmf-core-controls-list-view//div[@class='entity-row'])[1]")
    WebElement firstAvailableResourceButton;

    @FindBy(xpath = "//cmf-mes-material-wizard-dispatch-step-dispatch")
    WebElement resourceAvailability;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Flow']/div/div[2]//child::a/div[2]/div[@title]")
    WebElement flowLink;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Step']/div/div[2]//child::a/div[2]/div[@title]")
    WebElement stepLink;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Required Service']/div/div[2]//child::a/div[2]/div[@title]")
    WebElement serviceLink;

//    @FindBy(xpath="//div[@class=\"k-animation-container\"]//div[@data-id=\"cmf-core-controls-context-menu-open-in-new-page\"]")
    @FindBy(xpath="//div[@class=\"k-animation-container\"]//li[text()='Open in New Page']")
    WebElement openInNewPageButton;

    @FindBy(xpath="//div[@class=\"pane-body-content\"]//div[@title='Resources']")
    WebElement resourcesButtonInStepViewPage;

    @FindBy(xpath="//td[@data-field=\"Id\"]//cmf-core-controls-datagrid-navigation[@entitytype=\"Resource\"]//cmf-core-business-controls-navigation[@title]")
    WebElement mainResourceLinkInStepViewPage;

    @FindBy(xpath="//div[@title=\"Dispatch List\"]")
    WebElement dispatchListInResourcePage;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label=\"Name\"]//div[@class=\"text\"]")
    WebElement materialNameLabel;

    @FindBys(@FindBy(xpath="//td[@data-field=\"Name\"]/cmf-core-controls-datagrid-navigation[@entitytype=\"Material\"]//cmf-core-business-controls-navigation[@title]"))
    List<WebElement> listOfMaterialsInDispatchList;

    @FindBys(@FindBy(xpath="//td[@data-field=\"Name\"]/cmf-core-controls-datagrid-navigation[@entitytype=\"Material\"]//cmf-core-business-controls-navigation[@title]//ancestor::td/preceding-sibling::td/div//label[@class=\"checkbox-inline\"]"))
    List<WebElement> checkBoxesOfMaterialsInDispatchList;

    @FindBy(xpath="//cmf-core-dashboards-actionbutton[@data-id=\"Material.Perform.Group\"]")
    WebElement performButton;

    @FindBy(xpath="//cmf-core-controls-actionbuttongroupbutton//div[@title='Setup']")
    WebElement performSetUpButton;

//    @FindBy(xpath="//div[@title='Views']")
    @FindBy(xpath="//div[@title='Views']/parent::div[@class=\"dropdown\"]")
    WebElement viewsDropDown;

    @FindBy(xpath="//div[@title=\"Upcoming Maintenance\"]")
    WebElement upcomingMaintenanceTab;

    @FindBys(@FindBy(xpath="//td[@data-field=\"MaintenanceActivity.Name\"]/parent::tr//label[@class=\"checkbox-inline\"]/div"))
    List<WebElement> listOfMaintenanceActivities;

    @FindBys(@FindBy(xpath="//td[@data-field=\"ExecutionState\"]"))
    List<WebElement> executionStateMaintenanceActivities;

    @FindBys(@FindBy(xpath="//td[@data-field=\"ScheduledDate\"]"))
    List<WebElement> scheduledDateMaintenanceActivities;

    @FindBys(@FindBy(xpath="//div[@class=\"tabs-slider\"]//li//div[@title]"))
    List<WebElement> noOfStepsInActivityPerformWizard;

    @FindBy(xpath="//div[@tag-id=\"Maintenance.Order.Begin\"]")
    WebElement activityBeginWizard;

    @FindBy(xpath="//div[@class=\"instance-navigation\"]//a[@alt]")
    WebElement maintenanceInstanceName;

    @FindBy(xpath="//button[text()='Begin']")
    WebElement activityBeginButton;

    @FindBy(xpath="//div[@tag-id=\"Maintenance.Order.Perform\"]")
    WebElement activityPerformWizard;

    @FindBy(xpath="//div[@data-label=\"AddNoteButton\"]")
    WebElement addNoteButtonInNotesSection;

//    @FindBy(xpath="//button[@data-action=\"perform\" and text()='Save and Close']")
    @FindBy(xpath="//button[text()='Save and Close']")
    WebElement saveAndCloseButtonOfPerformActivity;

    @FindBy(xpath="//div[@tag-id=\"Maintenance.Order.Complete\"]")
    WebElement completeActivityWizard;

    @FindBy(xpath="//button[@data-action=\"finish\" and text()='Complete']")
    WebElement completeActivityButton;

    @FindBy(xpath="//div[@title='INT Integration Assy_Resource']/following-sibling::div/a[@class='cmf-core-shell-page-switcher-close-button icon-core-st-sm-close']")
    WebElement closeTabButton;

    @FindBy(xpath="//li[@data-id=\"serviceResourcesSection\"]")
    WebElement resourcesLinkInServicePage;

//    @FindBy(xpath="//td[@data-field=\"SourceEntity\"]/cmf-core-controls-datagrid-navigation[@entitytype=\"Resource\"]//a/div")
    @FindBy(xpath="//td[@data-field=\"SourceEntity\"]/cmf-core-controls-datagrid-navigation[@entitytype=\"Resource\"]//a/div[text()]")
    WebElement mainResourceLinkInServicePage;

    @FindBy(xpath="//div[@title='Contexts']")
    WebElement contextsOptionInViewsDropdown;

    @FindBy(xpath="//div[@title='Step View']")
    WebElement stepViewOptionInViewsDropdown;

//    @FindBy(xpath="//div[@title='Resource View']")
//    WebElement resourceViewOptionInViewsDropdown;

    @FindBys(@FindBy(xpath="//div[@title='Resource View']"))
    List<WebElement> resourceViewOptionInViewsDropdown;

    @FindBy(xpath="//cmf-core-controls-actionbuttongroupbutton[@data-tag=\"Maintenance\"]/div[@title='Maintenance']")
    WebElement maintenanceOptionInViewsDropdown;

    @FindBy(xpath="//li[@title='BOM Context']")
    WebElement bomContextLinkInContextsPage;

    @FindBy(xpath="//td[@data-field='BOM']//cmf-core-business-controls-navigation")
    WebElement bomNameInContextTable;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[@class='first-visible']//cmf-core-controls-columnviewrow[@hasvalue='true']"))
    List<WebElement> noOfProductsToBeAssembled;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn//cmf-core-controls-columnviewrow[@hasvalue='true']//div[@title='0']"))
    List<WebElement> noOfProductsAssembled;

    @FindBy(xpath = "//button[@data-action='finish' and text()='Assemble']")
    WebElement assembleButton;

    @FindBys(@FindBy(xpath="//div[@style='height: auto;']/ul[@role='listbox']/li"))
    List<WebElement> noOfMaterialsInSearchMaterialDropdown;

    @FindBy(xpath = "//button[@data-action='next']")
    WebElement nextButton;

    @FindBys(@FindBy(xpath="//*/cmf-core-controls-horizontal-step-list/ul/li/div[2]/div/div[text()]"))
    List<WebElement> noOfStepsInTheWizard;

    @FindBy(xpath="//div[@title='Transaction']/parent::div/child::div[1]//cmf-core-controls-actionbutton[not(contains(@style,'display: none'))]")
    WebElement typeOfWizard;

    @FindBy(xpath="//cmf-core-controls-wizard-step[@maintitle=\"Results\"]//div[@class=\"p-relative alert alert-danger\"]")
    WebElement alertMessageInResultsStep;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn//div[@class='name']"))
    List<WebElement> noOfDocuments;

    @FindBy(xpath = "//div[@class='dataGridContainer full-size']//span[text()='BOM']")
    WebElement bomInformationLabel;

    @FindBy(xpath = "//div[@class='bom-header']/div[@class='property-wraper']//a")
    WebElement bomNameLink;

    @FindBy(xpath = "//cmf-core-controls-label[@class='label-right']")
    WebElement bomType;

    @FindBys(@FindBy(xpath="//tbody[@role='rowgroup']/tr"))
    List<WebElement> noOfRowsInBomInfoSection;

    @FindBys(@FindBy(xpath="//tbody[@role='rowgroup']/tr//td[@data-field='TargetEntity.Name']/cmf-core-controls-datagrid-navigation"))
    List<WebElement> bomProductNames;

    @FindBys(@FindBy(xpath="//tbody[@role='rowgroup']/tr//td[@data-field='RequiredQuanity']/span"))
    List<WebElement> requiredQuantityOfTheBOMProducts;

//    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[1]//cmf-core-controls-columnviewrow//span[@class='name-text']"))
    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[1]//cmf-core-controls-columnviewrow//span[@class='name-text']/div[@title][1]"))
    List<WebElement> parametersInColumnOneOfDC;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[2]//cmf-core-controls-columnviewrow//span[@class='name-text']"))
    List<WebElement> parametersInColumnTwoOfDC;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[3]//cmf-core-controls-columnviewrow//span[@class='name-text']"))
    List<WebElement> parametersInColumnThreeOfDC;

    @FindBys(@FindBy(xpath="//input[@type='text']"))
//    @FindBys(@FindBy(xpath="(//input[@type='text'])[7]"))
    List<WebElement> inputTextBoxesInDC;

    @FindBy(xpath = "(//input[@type='text'])[2]")
    WebElement inputTextBoxInDC;

    @FindBy(xpath = "//div[@class='group-content']//div[@title='Has parameters']")
    WebElement checkListWithParameter;

    @FindBy(xpath = "//div[@class='icon-core-st-sm-error']")
    WebElement errorNotificationForParameters;

    @FindBys(@FindBy(xpath="//div[@class='execution-state-button icon-core-st-sm-accept not-started']"))
    List<WebElement> checkListButtons;

    @FindBys(@FindBy(xpath="//./leaf-content//div[@class='cmf-core-controls-baseWidget']/child::div[2][@class='body']//child::div[@class='limit-value']//div"))
    List<WebElement> typesOfDC;

//    @FindBy(xpath = "//div[@class='leaf-div leaf-container leaf']")
    @FindBy(xpath = "//div[@class='data-collection-header']//following::div[@class='leaf-div leaf-container leaf']")
    WebElement parentTagOfDataCollection;

    @FindBy(xpath = "//div[@type=\"error\"]")
    WebElement errorButtonInDCTextBox;

    @FindBy(xpath = "//*[@class=\"cmf-core-controls-popOverResultMessage-list\"]//li")
    WebElement errorMessageInDCTextBox;

    @FindBy(xpath = "//div[@class='cmf-core-controls-select-expanded']//child::li[@data-name='Pass']")
    WebElement optionTrueInTrueOrFalseSelection;

    @FindBy(xpath = "//button[@data-action='ok']")
    WebElement okButtonInTrueOrFalseSelection;

    @FindBys(@FindBy(xpath="//div[@class='execution-state-button icon-core-st-sm-accept not-started']/following-sibling::div/div[2]/div[1]"))
    List<WebElement> typeOfActionInCheckList;

    @FindBys(@FindBy(xpath="//div[@class=\"tab-content\"]//cmf-core-checklist-performitemparameters/cmf-core-business-controls-propertyeditor/div/div[2]/div"))
    List<WebElement> noOfEditorsInChecklistParameter;

    @FindBys(@FindBy(xpath="//div[@class=\"tab-content\"]//cmf-core-checklist-performitemparameters/cmf-core-business-controls-propertyeditor/div/div[2]/div[@class=\"edit lookupComboBox\"]//span[@class=\"k-select\"]"))
    List<WebElement> selectFromDropDownButtonInCheckList;

    @FindBys(@FindBy(xpath="//div[@class=\"tab-content\"]//cmf-core-checklist-performitemparameters/cmf-core-business-controls-propertyeditor/div/div[2]/div//input[@data-tag-name=\"input\"]"))
    List<WebElement> plainTextBoxInCheckList;

    @FindBys(@FindBy(xpath="//li[@role=\"option\" and @class=\"k-item\"]/span"))
    List<WebElement> optionsInCheckListDropDown;

    @FindBy(xpath = "//li[@role=\"option\" and @class=\"k-item\"]/span")
    WebElement firstOptionInCheckListDropDown;

    @FindBy(xpath = "//li[@data-custom='PARAMETERS']")
    WebElement parametersTabInChecklist;

    @FindBy(xpath = "(//./cmf-core-controls-combobox//input[contains(@class,'k-input')])[2]")
    WebElement parameterTextBox;

    @FindBy(xpath = "//cmf-mes-datacollection-parameterlimitviewer//div[@class='dc-box-text-left-align']")
    WebElement valueRangeInLeftOfDC;

    @FindBy(xpath = "//cmf-mes-datacollection-parameterlimitviewer//div[@class='dc-box-text-right-align']")
    WebElement valueRangeInRightOfDC;

    @FindBy(xpath = "//./cmf-core-controls-auth//input[@formcontrolname='username']")
    WebElement authUserName;

    @FindBy(xpath = "//./cmf-core-controls-auth//input[@formcontrolname='password']")
    WebElement authPassword;

    @FindBy(xpath = "//./cmf-core-controls-auth//button[@id='sign']")
    WebElement authSignInButton;

    @FindBy(xpath = "//button[text()='Track-In']")
    WebElement trackInButton;

    @FindBy(xpath = "//div[@class='cmf-loading-center']")
    public WebElement loaderSpinner;

    @FindBy(xpath = "//div[@class='cmf-loading-cmf-logo']")
    WebElement logoAfterSpinner;

    @FindBy(xpath = "//button[text()='Track-Out']")
    WebElement trackOutButton;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Resource']/div/div[2]/div/cmf-core-business-controls-navigation")
    WebElement resourceLink;

    @FindBy(xpath="//cmf-core-controls-wizard-step[@maintitle='Results']//div[@class='p-relative alert alert-danger']")
    WebElement dangerAlertDuringTrackIn;

    @FindBy(xpath="//div[@title='More']")
    WebElement moreButton;

    @FindBy(xpath="//li[@role=\"menuitem\"]//div[text()='Scan Assemble']")
    WebElement scanAssembleButton;

    @FindBy(xpath="//input[@placeholder='Material' and @type='text']")
    WebElement materialTextBoxOfScanAssemble;

    @FindBys(@FindBy(xpath="//table//tr//p//cmf-core-controls-datagrid-navigation[@entitytype=\"Product\"]"))
    List<WebElement> productsInScanAssemblePage;

    @FindBy(xpath="//table//tr//p//cmf-core-controls-datagrid-navigation[@entitytype=\"Product\"]//following-sibling::span[2]")
    WebElement requiredQuantityOfProducts;

    @FindBy(xpath="//button[@data-action=\"finish\"]")
    WebElement finishButtonInScanAssemblePage;

    @FindBy(xpath="//button[@data-action=\"close\" and text()='Close']")
    WebElement closeButton;

    @FindBy(xpath="//div[@class=\"info-box-content\"]/span[@id=\"infoScan\"]")
    WebElement allTheProductsReadyLabel;

    @FindBy(xpath="//cmf-core-shell-shell[@data-isauthenticated='true']")
    WebElement dangerAlertParentNodeInScanAssemble;

    @FindBy(xpath="//cmf-core-shell-shell[@data-isauthenticated='true']//div[@class=\"alert clear-all toast-error\"]")
    WebElement clearAllDangerAlertsButton;

    @FindBy(xpath="//cmf-core-shell-shell//div[@class='alert toast-error']/button[@class='toast-close-button']")
    WebElement dangerAlertInScanAssemble;

    @FindBy(xpath="//li[@data-id=\"protocolSection\"]/a[text()='Protocols']")
    WebElement protocolSectionButton;

    @FindBy(xpath="//span[@role=\"listbox\"]")
    WebElement rowCountDropDown;

    @FindBy(xpath="//li[@role='option' and text()=\"100\"]")
    WebElement rowCountPerPage;

    @FindBys(@FindBy(xpath="//td[@data-field='Name']//a[@href]/div[text()]"))
    List<WebElement> protocolInstanceLink;

    @FindBys(@FindBy(xpath="//td[@data-field='SystemStateName']"))
    List<WebElement> protocolStateLabel;

    @FindBys(@FindBy(xpath="//cmf-core-controls-list-view[@class='depth-levels-list-view']//li"))
    List<WebElement> noOfProtocolsStates;

    @FindBys(@FindBy(xpath="//td[@data-field=\"ModifiedOn\"]"))
    List<WebElement> protocolCreatedDate;

    @FindBys(@FindBy(xpath="//td[@data-field=\"SystemStateName\"]/preceding-sibling::td[@data-field=\"ParentEntity\"]"))
    List<WebElement> versionOfProtocolLabel;

    @FindBys(@FindBy(xpath="//cmf-core-business-controls-propertyeditor[@data-required=\"true\"]//input[@type='text']"))
    List<WebElement> noOfMandatoryTextBoxesInParameterSection;

    @FindBy(xpath="//div[@title='Perform']")
    WebElement performProtocolInstance;

    @FindBy(xpath="//div[@class=\"protocol-instance-state-details\"]//span[not(@class)]")
    WebElement protocolStateNameLabel;

    @FindBy(xpath="//cmf-core-controls-page-title//div[@class='separator'][2]/following-sibling::span[text()]")
    WebElement protocolStateNameLabelInLowerCase;

    @FindBy(xpath="//cmf-core-controls-page-title//div[@class='separator'][2]/preceding-sibling::span[text()]")
    WebElement protocolStatusLabelInHeader;

    @FindBy(xpath="//cmf-core-controls-actionbuttongroup[@button-id=\"ProtocolInstance.Manage.Group\"]/div[@class=\"dropdown\"]")
    WebElement manageProtocolButton;

    @FindBy(xpath="//div[@class=\"name\"]/span[@data-value=\"name\"]")
    WebElement materialLinkInManageDispositionScreen;

    @FindBys(@FindBy(xpath="//div[@title=\"Dispositions\"]"))
    List<WebElement> manageDispositionButton;

    @FindBy(xpath="//div[@class=\"cmf-core-controls-comboBox\"]//input[@type='text']")
    WebElement dispositionDropdownTextbox;

    @FindBy(xpath="//button[@data-action=\"finish\" and text()='Update']")
    WebElement updateButton;

    @FindBy(xpath="//div[@title=\"Execute Dispositions\"]")
    WebElement executeDispositionWizard;

//    @FindBy(xpath="//div[@class=\"selection\"]//input[@type=\"checkbox\"]")
    @FindBy(xpath="//div[@class='name']//preceding-sibling::div[@class='selection']//input[@type='checkbox']/parent::div")
    WebElement materialCheckBoxInExecuteDispositionScreen;

    @FindBy(xpath="//button[@data-action='finish' and text()='Execute']")
    WebElement executeButtonInExecuteDispositionScreen;

    @FindBy(xpath="//div[@title='Approve']")
    WebElement approveDispositionWizard;

    @FindBy(xpath="//div[@title=\"Take Ownership\"]")
    WebElement takeOwnershipWizard;

    @FindBy(xpath="//button[@data-action='finish' and text()=\"Take Ownership\"]")
    WebElement takeOwnershipButton;

    @FindBy(xpath="//div[@class=\"selection\"]//input[@type=\"checkbox\"]")
    WebElement materialCheckBoxInApproveDispositionScreen;

    @FindBy(xpath="//button[@data-action='finish' and text()='Approve']")
    WebElement approveButtonInApproveDispostionScreen;

    @FindBys(@FindBy(xpath="//div[@title='Approve Dispositions']"))
    List<WebElement> approveDispositionButtonInDropdown;

    @FindBy(xpath="//div[@title=\"Create Task\"]")
    WebElement createTaskWizard;

    @FindBy(xpath="//cmf-core-business-controls-propertyeditor[@class='Title']//input[@type='text']")
    WebElement titleTextBoxInTaskCreationScreen;

    @FindBy(xpath="//cmf-core-business-controls-propertyeditor[@class='Owner']//input[@type='text']")
    WebElement ownerTextBoxInTaskCreationScreen;

    @FindBy(xpath="//cmf-core-business-controls-propertyeditor[@class='DueDate']//input[@type='text']")
    WebElement dueDateTextBoxInTaskCreationScreen;

    @FindBy(xpath="//button[@data-action=\"finish\" and text()='Create']")
    WebElement createButtonInTaskCreationScreen;

    @FindBy(xpath="//div[@class=\"cmf-core-controls-panelBar-header\"]//div[contains(text(),'Tasks')]")
    WebElement tasksHeaderInPanelBar;

    @FindBy(xpath="//div[@title='Perform' and @class='cmf-action-button']")
    WebElement performTaskWizard;

    @FindBy(xpath="//div[@class=\"progress-container\"]//input[@type='text' and @inputmode=\"numeric\"]")
    WebElement progressContainer;

    @FindBy(xpath = "//button[@data-action='finish']")
    WebElement performTaskButton;

    @FindBy(xpath="//cmf-core-business-controls-entitypropertyviewer[@data-propertyname=\"UniversalState\"]//div[@data-tag=\"display-value\"]")
    WebElement universalStateOfTask;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label=\"System State\"]//div[@data-tag=\"display-value\"]")
    WebElement systemStateOfTask;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label=\"Name\"]//div[@data-tag=\"display-value\"]")
    WebElement displayedTaskNameLabel;


    public boolean isDispatchAndTrackInWizardButtonPresent;
    public boolean isDispatchButtonPresent;
    public boolean isThisTrackIn;
    public boolean isResourceStepPresent;
    public boolean isDocumentStepPresent;
    public boolean isDataCollectionStepPresent;
    public boolean isBomInformationStepPresent;
    public boolean isCheckListStepPresent;
    public boolean isRecordLossBonusStepPresent;
    public boolean isAttachmentsStepPresent;
    public boolean isResultsStepPresent;
    public boolean isResourceAvailable;
    public String flowName;
    public String currentStepName;
    public String strBOMName;
    public boolean resourceBool;
    public boolean isAssembleRequired;
    public boolean isScanAssembleRequired;
    public String runEnvironmentType;
    public String mainMaterialName;
    public boolean isPerformSetUpRequired=false;
    public boolean isMaintenanceActivityOnGoing;
    public boolean isProtocolBeingHandled;
    public String parameterNameInDC;

    public ArrayList<Character> charsList = new ArrayList<Character>();


    /**
     * The below method is to click on dispatch and track-in button in top menu
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnDispatchTrackIn(){
        try {
            commonUtils.waitForElementToBeDisplayed(dispatchAndTrackInWizardButton,Constants.MEDIUM_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(dispatchAndTrackInWizardButton,"dispatchAndTrackInWizardButton");
            //added below line on 05/05/22
            toHandleLoaderSpinner();
            commonUtils.waitForPageLoad();
            isDispatchAndTrackInWizardButtonPresent=true;
            isThisTrackIn=true;
            commonUtils.toLogIntoExtentReport(Status.INFO,"Tracking-In into this step now  "+currentStepName+"");
        } catch (Exception e) {
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Dispatch and TrackIn Button was not available, Please check for the same",true);
            Assert.assertTrue("Dispatch and TrackIn Button was not available, Please check for the same",false);
        }
    }

    /**
     * The below method will find if dispatch and track-in
     * are merged together or not and makes call respectively.
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnDispatchAndTrackInWizard()  {
        try{
            if (flowLink.isDisplayed()) {
                commonUtils.scrollIntoViewPage(flowLink);
                flowName = flowLink.getAttribute("title");
                System.out.println("The name of the flow is "+flowName);
                commonUtils.toLogIntoExtentReport(Status.INFO,"The name of the flow is "+flowName+"");
                currentStepName = stepLink.getAttribute("title");
                System.out.println("The name of the current step is "+currentStepName);
                commonUtils.toLogIntoExtentReport(Status.INFO,"The name of the current step is "+currentStepName+"");
            }
        }catch(Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"The flow link or step link was not displayed, Please check the same",true);
            Assert.assertTrue("The flow link or step link was not displayed, Please check the same",false);
        }

        String strButtonID="";
        try{
            if(typeOfWizard.isDisplayed()){
//                commonUtils.waitForElementToBeDisplayed(typeOfWizard, Constants.HIGH_LOADING_WAIT_TIME);
                toHandleLoaderSpinner();
                String strTypeOfWizard=typeOfWizard.getAttribute("button-id");
                String[] buttonID=strTypeOfWizard.split("[.]");
                 strButtonID=buttonID[1];
            }
        }catch (Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Please do move-next and then try to track in",true);
            Assert.assertTrue("Please do move-next and then try to track in into the step",false);
        }

        switch (strButtonID){
            case "Dispatch":
                toClickOnDispatchAloneButton();
                break;
            case "DispatchTrackIn":
                toClickOnDispatchTrackIn();
                break;
            default:
                commonUtils.toLogIntoExtentReport(Status.FAIL,"Please do move-next and then try to track in");
                Assert.assertTrue("Please do move-next and then try to track in",false);
                break;
        }
        //added on 03/05/2022
        runEnvironmentType= FileReaderManager.getInstance().getConfigReader().getRunEnvironmentType();
        if(runEnvironmentType.equalsIgnoreCase("Dev")) {
            toFindTheNoOfStepsPresentInThisWizard();
            toReadResultsSection();
        }
    }

    public void toReadResultsSection(){
        if(isResultsStepPresent){
            try {
                String strAlertMessage=alertMessageInResultsStep.getText();
                if(strAlertMessage.equalsIgnoreCase("Cannot perform dispatch because no Resources with the required service are available.")){
                    commonUtils.clickOnObject(closeButton,"closeButton");
                    toCompleteMaintenancePlan();
                    toClickOnDispatchAndTrackInWizard();
                }
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Alert message not displayed");
            }
        }
    }

    public void toAbortTrackIn(){
        String strParentTagOfActionBar=parentTagOfActionBar.getAttribute("innerHTML");
        if(strParentTagOfActionBar.contains("title=\"Abort\" disabled=\"true\"")){
            System.out.println("Abort not Required");
        }else{
            if(strParentTagOfActionBar.contains("Material.Abort")){
                try {
                    if (abortButton.isDisplayed())
                        commonUtils.clickOnObject(abortButton, "Abort Button in action bar");
                    Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                    commonUtils.clickOnObject(abortCompletionButton,"Abort Completion Button");
                    toHandleLoaderSpinner();
                }catch(Exception e){
                    System.out.println("Abort not required");
                }
            }
        }

    }

    /**
     * The below method is to click on dispatch first and then to click on track-in
     * in the next step.
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnDispatchAloneButton()  {
        try {
            commonUtils.waitForElementToBeDisplayed(dispatchAloneButton,Constants.LOW_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(dispatchAloneButton,"dispatchAloneButton");
            commonUtils.waitForElementToBeDisplayed(resourceAvailability,Constants.LOW_LOADING_WAIT_TIME);
            String strResourceDetails="";
            strResourceDetails=resourceAvailability.getAttribute("innerHTML");
            resourceBool=strResourceDetails.contains("cmf-mes-material-resource-details");
            if (resourceBool) {
                commonUtils.clickOnObject(dispatchButton,"dispatchButton");
                toHandleLoaderSpinner();
                isResourceAvailable=true;
                System.out.println("Is the resource available "+isResourceAvailable);
                isDispatchButtonPresent=true;
            }else{
                commonUtils.waitForElementToBeDisplayed(firstAvailableResourceButton, Constants.LOW_LOADING_WAIT_TIME);
                commonUtils.clickOnObject(firstAvailableResourceButton, "firstAvailableResourceButton");
                commonUtils.waitForPageLoad();
                commonUtils.toLogIntoExtentReport(Status.PASS,"Chosen the first available resource in the list of resources");
               //added on 12/22/2021
                commonUtils.clickOnObject(dispatchButton,"dispatchButton");
                toHandleLoaderSpinner();
                isResourceAvailable=true;

            }
            if(resourceBool||isResourceAvailable){
                commonUtils.clickOnObject(trackInAloneButton,"trackInAloneButton");
                commonUtils.waitForPageLoad();
                isThisTrackIn=true;
                commonUtils.toLogIntoExtentReport(Status.INFO,"Tracked In into this step now  "+currentStepName+"");
            }

        }catch(Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Track-In into this step "+currentStepName+" was not successful");
            Assert.assertTrue("Track-In into this step "+currentStepName+" was not successful",false);
        }
    }

    /**
     * The below method is to choose available resource
     * and if the resource is already present, it will click on next
     * in the next step.
     * @return Nothing.
     * @author Vijay Y
     */
    public void toChooseAvailableResource() {
        if(isThisTrackIn) {
            try{
                String strResourceDetails=resourceAvailability.getAttribute("innerHTML");
                resourceBool=strResourceDetails.contains("cmf-mes-material-resource-details");
                if(!resourceBool) {
                    try {
                        commonUtils.waitForElementToBeDisplayed(firstAvailableResourceButton, Constants.LOW_LOADING_WAIT_TIME);
                        commonUtils.clickOnObject(firstAvailableResourceButton, "firstAvailableResourceButton");
                        toHandleLoaderSpinner();
                        commonUtils.waitForPageLoad();
                        commonUtils.toLogIntoExtentReport(Status.PASS,"Chose the first available resource at this step "+currentStepName);
                    } catch (Exception e) {
                        System.out.println("Resource dropdown is not available");
                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Unable to choose the first available resource at this step "+currentStepName);
                        Assert.assertTrue("Unable to choose the first available resource at this step "+currentStepName,false);
                    }
                }else{
                    toHandleLoaderSpinner();
                    commonUtils.toLogIntoExtentReport(Status.PASS,"Resource has been chosen already and is available for further actions at this step "+currentStepName);
                }
                commonUtils.waitForElementToBeDisplayed(noOfStepsInTheWizard.get(0),Constants.MEDIUM_LOADING_WAIT_TIME);
                toFindTheNoOfStepsPresentInThisWizard();
                if (isResourceStepPresent) {
                    if(isLastStep.equalsIgnoreCase("Resource")){
                        toClickOnTrackInButton();
                    }else{
                        toClickOnNextButton();
                    }
                    isResourceStepPresent = false;
                } else if (toCheckIfResourceNameIsPresent()) {
                    if(isLastStep.equalsIgnoreCase("Resource")){
                        toClickOnTrackInButton();
                    }else{
                        toClickOnNextButton();
                    }
                    isResourceStepPresent = false;
                }
            }catch(Exception e){
                commonUtils.toLogIntoExtentReport(Status.FAIL,"There has been a problem while choosing the available resource at this step "+currentStepName);
                Assert.assertTrue("There has been a problem while choosing the available resource at this step "+currentStepName,false);
            }
        }
    }

    /**
     * This method will check if the resource is already present,
     * and if resource is already present, it will return true
     * @return boolean.
     * @author Vijay Y
     */
    public boolean toCheckIfResourceNameIsPresent(){
        boolean bool=false;
        try {
            Thread.sleep(2000);
            bool=resourceNameLabel.isDisplayed();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Resource name label is not displayed");
        }
        return bool;
    }

    /**
     * The below method is to find the number of sections present in a step of the Flow
     * @return Nothing.
     * @author Vijay Y
     */
    public void toFindTheNoOfStepsPresentInThisWizard(){
        String str="";
//        if(resourceNameLabel.isDisplayed()){
            if(!noOfStepsInTheWizard.isEmpty()) {

                int size = noOfStepsInTheWizard.size();
                isLastStep = noOfStepsInTheWizard.get(size - 1).getText();
                for (WebElement element : noOfStepsInTheWizard) {
                    str = element.getText();
                    System.out.println("No of steps present in this wizard is " + noOfStepsInTheWizard.size());
                    if (str.equalsIgnoreCase("Resource")) {
                        isResourceStepPresent = true;
                        System.out.println("Resource step is part of this wizard");
                    } else if (str.equalsIgnoreCase("Documents")) {
                        isDocumentStepPresent = true;
                        System.out.println("Documents step is part of this wizard");
                    } else if (str.equalsIgnoreCase("Data Collection")) {
                        isDataCollectionStepPresent = true;
                        System.out.println("Data Collection step is part of this wizard");
                    } else if (str.equalsIgnoreCase("BOM")) {
                        isBomInformationStepPresent = true;
                        System.out.println("BOM info step is part of this wizard");
                    } else if (str.equalsIgnoreCase("Checklist")) {
                        isCheckListStepPresent = true;
                        System.out.println("Checklist step is part of this wizard");
                    } else if (str.equalsIgnoreCase("Record Loss/Bonus")) {
                        isRecordLossBonusStepPresent = true;
                        System.out.println("Record Loss Bonus Step is part of this wizard");
                    } else if (str.equalsIgnoreCase("Attachments")) {
                        isAttachmentsStepPresent = true;
                        System.out.println("Attachments Step is part of this wizard");
                    }else if(str.equalsIgnoreCase("Results")){
                        isResultsStepPresent=true;
                        System.out.println("Results Step is part of this wizard");
                    }
                }
            }else{
                System.out.println("There has been a issue in clicking the Dispatch and Track-In Wizard");
                commonUtils.toLogIntoExtentReport(Status.FAIL,"There has been a issue in clicking the Dispatch and Track-In Wizard");
//                Assert.assertTrue("There has been a issue in clicking the Dispatch and Track-In Wizard",false);
                Assert.fail("There has been a issue in clicking the Dispatch and Track-In Wizard");
            }

//        }
    }

    /**
     * The below method is to click on next button in the current sections(step)
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnNextButton(){
        try {
            nextButton.click();
            Thread.sleep(Constants.SYS_WAIT_TIME);
        } catch (Exception e) {
           System.out.println("Next Button was not displayed, hence clicking on Track-In Button");
           toClickOnTrackInButton();
        }

    }

    /**
     * The below method is to complete document section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteDocumentsStep() throws Exception {
        if(isDocumentStepPresent && isThisTrackIn) {
            for (WebElement element : noOfDocuments) {
                commonUtils.clickOnObject(element,"element");
            }
            commonUtils.toLogIntoExtentReport(Status.PASS,"Viewing the documents and moving to next step");
            if(isLastStep.equalsIgnoreCase("Documents")){
                toClickOnTrackInButton();
            }else{
                toClickOnNextButton();
            }
        }
        isDocumentStepPresent=false;

    }

    /**
     * The below method is to complete attachments section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteAttachmentsStep() throws Exception {
        if(isAttachmentsStepPresent && isThisTrackIn) {

            commonUtils.toLogIntoExtentReport(Status.PASS,"In the attachments section now");
            if(isLastStep.equalsIgnoreCase("Attachments")){
                toClickOnTrackInButton();
            }else{
                toClickOnNextButton();
            }
        }
        isAttachmentsStepPresent=false;

    }

    /**
     * The below method is to complete BOM Information section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */

    public HashSet<String> productsAlone=new HashSet<String>();
    public HashMap<String, String> productWithQuantity=new HashMap<String, String>();

    public void toCompleteBomInformationStep(){

        if(isBomInformationStepPresent && isThisTrackIn) {
            try{
                if (bomInformationLabel.isDisplayed()) {
                    commonUtils.toLogIntoExtentReport(Status.PASS,"Now in BOM Info section and moving to next step");
                    try{
                        int noOfProductsInBOM=noOfRowsInBomInfoSection.size();
                        strBOMName=bomNameLink.getAttribute("alt");
                        String strBomType="";
                        try{
                            strBomType=bomType.getAttribute("innerHTML");
                        }catch(Exception e){
                            e.printStackTrace();
                        }

                        if(noOfProductsInBOM>0 && strBomType.contains("Explicit") ){
                             isAssembleRequired = true;
                            for(int i=0;i<=bomProductNames.size()-1;i++){
                                String strBomProductName=bomProductNames.get(i).getAttribute("name");
                                String requiredQuantity=requiredQuantityOfTheBOMProducts.get(i).getText();
                                String[] requiredQuantityArray=requiredQuantity.split(" ");
                                String strRequiredQuantity=requiredQuantityArray[0];
                                productsAlone.add("\""+strBomProductName+"\"");
                                productWithQuantity.put(strBomProductName,strRequiredQuantity);
                                System.out.println("The hash map for product with quantity is "+productWithQuantity);
                                System.out.println("The hash set for products alone is "+productsAlone);
                            }
                        }
                    }catch(Exception e){
                        System.out.println("There are no product requirement in BOM");
                    }


                    if(isLastStep.equalsIgnoreCase("BOM")||isLastStep.contains("BOM")){
                        toClickOnTrackInButton();
                    }else{
                        toClickOnNextButton();
                    }
                }
            }catch(Exception e){
                Assert.fail("BOM Information step is not displayed");
            }

        }
        isBomInformationStepPresent=false;
    }

    public void toCompleteBomInScanAssemble(){

        if(isBomInformationStepPresent ) {
            try{
                if (bomInformationLabel.isDisplayed()) {
                    commonUtils.toLogIntoExtentReport(Status.PASS,"Now in BOM Info section of scan assemble screen and moving to next step");

                    if(isLastStep.equalsIgnoreCase("BOM")||isLastStep.contains("BOM")){
                        toClickOnTrackInButton();
                    }else{
                        toClickOnNextButton();
                    }
                }
            }catch(Exception e){
                Assert.fail("BOM Information step is not displayed");
            }

        }
        isBomInformationStepPresent=false;
    }

    /**
     * The below method is to complete data collection section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteDataCollectionStep() throws Exception {
        if(isDataCollectionStepPresent && isThisTrackIn){
            commonUtils.toLogIntoExtentReport(Status.INFO,"Now in data collection section");
            for (WebElement element : parametersInColumnOneOfDC) {
                commonUtils.clickOnObject(element,"ParameterInColumnOneOfDC");
                parameterNameInDC =element.getText();
                for(WebElement element1:parametersInColumnTwoOfDC){
                    commonUtils.clickOnObject(element1,"parametersInColumnTwoOfDC");
                    for(WebElement element2:parametersInColumnThreeOfDC){
                        commonUtils.clickOnObject(element2,"parametersInColumnThreeOfDC");
                        toEnterValueInInputTextBoxOfDC();
                    }
                }
            }
            commonUtils.toLogIntoExtentReport(Status.PASS,"Data Collection has been completed for this step "+currentStepName+"");
            if(!isMaintenanceActivityOnGoing) {
                if (isLastStep.equalsIgnoreCase("Data Collection")) {
                    toClickOnTrackInButton();
                } else {
                    toClickOnNextButton();
                }
            }
            isDataCollectionStepPresent=false;
        }

    }

    /**
     * The below method is to complete data collection section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteDataCollectionStep(String arg1) throws Exception {
        if(isDataCollectionStepPresent && isThisTrackIn){
            commonUtils.toLogIntoExtentReport(Status.INFO,"Now in data collection section");
            for (WebElement element : parametersInColumnOneOfDC) {
                commonUtils.clickOnObject(element,"ParameterInColumnOneOfDC");
                parameterNameInDC =element.getText();
                apiUtils.toGetTheParameterDetailsOfDataCollection(arg1,parameterNameInDC);
                for(WebElement element1:parametersInColumnTwoOfDC){
                    commonUtils.clickOnObject(element1,"parametersInColumnTwoOfDC");
                    for(WebElement element2:parametersInColumnThreeOfDC){
                        commonUtils.clickOnObject(element2,"parametersInColumnThreeOfDC");
                        toEnterValueInInputTextBoxOfDC();
                    }
                }
            }
            commonUtils.toLogIntoExtentReport(Status.PASS,"Data Collection has been completed for this step "+currentStepName+"");
            if(!isMaintenanceActivityOnGoing) {
                if (isLastStep.equalsIgnoreCase("Data Collection")) {
                    toClickOnTrackInButton();
                } else {
                    toClickOnNextButton();
                }
            }
            isDataCollectionStepPresent=false;
        }

    }


    /**
     * The below method is to enter a value in input text box in Data Collection
     * @return Nothing.
     * @author Vijay Y
     */
    public String strPassFail = "cmf-core-business-controls-lookupselectexpanded";
    public boolean passFailDC;
    public String strTextBoxAlone = "cmf-core-controls-input";
    public boolean textBoxAloneDC;
    public String strLimitRange = "cmf-mes-datacollection-parameterlimitviewer";
    public boolean limitRangeDC;
    public String strCalendarPicker="cmf-core-controls-datetimepicker";
    public boolean calendarPickerDC;
    public String strSpinnerKeyboard="cmf-core-controls-spinnerkeypad";
    public boolean spinnerKeyboardDC;

    public void toEnterValueInInputTextBoxOfDC() {
            int temp = 0;
//            String strPassFail = "cmf-core-business-controls-lookupselectexpanded";
//            String strTextBoxAlone = "cmf-core-controls-input";
//            String strLimitRange = "cmf-mes-datacollection-parameterlimitviewer";
//            String strCalendarPicker="cmf-core-controls-datetimepicker";
//            String strSpinnerKeyboard="cmf-core-controls-spinnerkeypad";
            String strInnerHTMLofDC = parentTagOfDataCollection.getAttribute("innerHTML");
            boolean isHiddenLimitsArrayEmpty=apiUtils.arrayListOfHiddenLimitRange.isEmpty();
            if (strInnerHTMLofDC.contains(strLimitRange)) {
                limitRangeDC=true;
                toCompleteDCofTypeLimitRange();
                limitRangeDC=false;
            } else if (strInnerHTMLofDC.contains(strCalendarPicker)) {
                calendarPickerDC=true;
                toCompleteDCofTypeInputTextBox(12);
                calendarPickerDC=false;
            } else if (strInnerHTMLofDC.contains(strPassFail)) {
                passFailDC=true;
                toCompleteDCofTypeTrueOrFalse();
                passFailDC=false;
            } else if (strInnerHTMLofDC.contains(strSpinnerKeyboard)) {
                spinnerKeyboardDC=true;
                if(!isHiddenLimitsArrayEmpty){
                    String strMinValue=apiUtils.arrayListOfHiddenLimitRange.get(1);
                    int minValue=Integer.parseInt(strMinValue);
                    String strMaxValue=apiUtils.arrayListOfHiddenLimitRange.get(0);
                    int maxValue=Integer.parseInt(strMaxValue);
                    toCompleteDCofTypeInputTextBox(minValue,maxValue);
                }else
                toCompleteDCofTypeInputTextBox(20);
                spinnerKeyboardDC=false;
            } else if (strInnerHTMLofDC.contains(strTextBoxAlone)) {
                textBoxAloneDC=true;
                toCompleteDCofTypeInputTextBox(20);
                textBoxAloneDC=false;
            } else {
                toCompleteDCofTypeInputTextBox(10);
            }

    }


    /**
     * The below method is to enter a value in input text box in Data Collection with Limit
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteDCofTypeLimitRange(){
        int temp=0;
        boolean boolValueForLeft=false;
        boolean boolValueForRight=false;

        try{
            boolValueForLeft  =valueRangeInLeftOfDC.isDisplayed();
        }catch(Exception e){
            System.out.println("Limit Range value in left is not displayed");
        }

        try{
            boolValueForRight  =valueRangeInRightOfDC.isDisplayed();
        }catch(Exception e){
            System.out.println("Limit Range value in right is not displayed");

        }


        if(temp==0) {
            try{
                if (boolValueForLeft && boolValueForRight) {
                    int intValueInLeft;
                    int intValueInRight;
                    double doubleValueInLeft;
                    double doubleValueInRight;
                    String strValueInTextBox="";
                    String strValueInLeft=valueRangeInLeftOfDC.getText();
                    String strValueInRight=valueRangeInRightOfDC.getText();

                    if(strValueInLeft.contains(".")&&strValueInRight.contains(".")){
                       doubleValueInLeft= Double.parseDouble(strValueInLeft);
                       doubleValueInRight= Double.parseDouble(strValueInRight);
                        strValueInTextBox=toGenerateRandomDecimalNumberInGivenRange(doubleValueInLeft,doubleValueInRight);
                    }else{
                        intValueInLeft=Integer.parseInt(strValueInLeft);
                        intValueInRight=Integer.parseInt(strValueInRight);
                        strValueInTextBox=toGenerateRandomNumberInGivenRange(intValueInLeft,intValueInRight);
                    }

                    for (WebElement e:inputTextBoxesInDC) {
                        if (e.isDisplayed()) {
                            e.clear();
                            e.sendKeys(strValueInTextBox);
                            temp=1;
                            break;
                        }
                    }
                }else if(valueRangeInLeftOfDC.isDisplayed()){
                    int intValueInLeft;
                    String strValueInLeft=valueRangeInLeftOfDC.getText();
                    if(strValueInLeft.contains(".")){
                        String[] arrValInLeft=strValueInLeft.split("[.]");
                        String valueInLeft=arrValInLeft[0];
                        intValueInLeft=Integer.parseInt(valueInLeft);
                    }else{
                        intValueInLeft=Integer.parseInt(strValueInLeft);
                    }
                    String strValueInTextBox=toGenerateRandomNumberAboveThisNumber(intValueInLeft);
                    for (WebElement e:inputTextBoxesInDC) {
                        if (e.isDisplayed()) {
                            e.clear();
                            e.sendKeys(strValueInTextBox);
                            temp=1;
                            break;
                        }
                    }
                }else{
                    String str=toGenerateRandomNumberUptoThisRange(30);
                    for (WebElement e:inputTextBoxesInDC) {
                        if (e.isDisplayed()) {
                            e.clear();
                            e.sendKeys(str);
                            temp=1;
                            break;
                        }
                    }
                }

            } catch(Exception e){

            }
        }
    }

    /**
     * The below method is to enter a value in input text box in Data Collection
     * @return Nothing.
     * @author Vijay Y
     * @param arg1
     */
    public void toCompleteDCofTypeInputTextBox(int arg1,int arg2){
        int temp=0;
        String str = null;
        if(temp==0) {
            try {
                if(spinnerKeyboardDC){
                    List<WebElement> elementList=driver1.findElements(By.xpath("//"+strSpinnerKeyboard+"//input[@type='text']"));
                    for (WebElement e:elementList) {
                        if (e.isDisplayed()) {
                            str=toGenerateRandomNumberInGivenRange(arg1,arg2);
                            commonUtils.waitForElementToBeDisplayed(e,10);
                            commonUtils.setObjectValue(e,"TextBox",str);
                            temp=1;
                            break;
                        }
                    }
                }else{
                    List<WebElement> elementList=driver1.findElements(By.xpath("//input[@type='text']"));
                    for (WebElement e:elementList) {
                        if (e.isDisplayed()) {
                            str=toGenerateRandomNumberInGivenRange(arg1,arg2);
                            commonUtils.waitForElementToBeDisplayed(e,10);
                            commonUtils.setObjectValue(e,"TextBox",str);
                            temp=1;
                            break;
                        }
                    }
                }


            } catch (Exception e) {
                List<WebElement> elementList=driver1.findElements(By.xpath("//input[@type='text']"));
                for (WebElement element :elementList) {
                    if (element.isDisplayed()) {
                        element.clear();
                        JavascriptExecutor jse= (JavascriptExecutor) driver1;
//                        jse.executeScript("document.getElementByXpath('//input[@type='text']').value='"+str+"'");
                        jse.executeScript("arguments[0].value='"+str+"';", element);
                        temp=1;
                        break;
                    }
                }
            }
            //added on 03/05/2022
            toHandleErrorOccuringInDCTextBox(str);
        }
    }

    /**
     * The below method is to enter a value in input text box in Data Collection
     * @return Nothing.
     * @author Vijay Y
     * @param arg1
     */
    public void toCompleteDCofTypeInputTextBox(int arg1){
        int temp=0;
        String str = null;
        if(temp==0) {
            try {

                for (WebElement e:inputTextBoxesInDC) {
                    if (e.isDisplayed()) {
                        str = toGenerateRandomNumberUptoThisRange(arg1);
                        e.clear();
                        e.sendKeys(str);
                        temp=1;
                        break;
                    }
                }

            } catch (Exception e) {
                System.out.println("DC model is not a normal text box");
                //added on 24/05/
                List<WebElement> elementList=driver1.findElements(By.xpath("//input[@type='text']"));
                for (WebElement e1 :elementList) {
                    if (e1.isDisplayed()) {
                        str = toGenerateRandomNumberUptoThisRange(arg1);
                        e1.clear();
                        try {
                            Thread.sleep(Constants.NORMAL_WAIT_TIME);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        JavascriptExecutor jse= (JavascriptExecutor) driver1;
                        jse.executeScript("arguments[0].value='"+ str +"';", e1);
                        temp=1;
                        break;
                    }
                }
            }
            //added on 03/05/2022
            toHandleErrorOccuringInDCTextBox(str);
        }
    }

    public void toHandleErrorOccuringInDCTextBox(String str){
        String randomNumber="";
        try {
            String str1="cmf-core-controls-popoverresultmessage-button-error";
            String parentTagOfDC=parentTagOfDataCollection.getAttribute("innerHTML");
            if(parentTagOfDC.contains("type=\"error\"") || parentTagOfDC.contains(str1)){
                commonUtils.clickOnObject(errorButtonInDCTextBox,"errorButtonInDCTextBox");
                String strErrorMsg=errorMessageInDCTextBox.getText();
                if (!(strErrorMsg.isEmpty() && strErrorMsg==null)){
                    commonUtils.clickOnObject(errorButtonInDCTextBox,"errorButtonInDCTextBox");
                }
                //below while loop is to remove all trailing dots
                while(strErrorMsg.charAt(strErrorMsg.length()-1) == '.')
                {
                    strErrorMsg = strErrorMsg.substring(0, strErrorMsg.length()-1);
                }
                String onlyTheNumbers;
                String actualLimit = null;
                String[] strArray= strErrorMsg.split("[.]");
                // Replacing every non-digit number
                // with a space(" ")
                strArray[1] = strArray[1].replaceAll("[^\\d]", " ");
                // Remove extra spaces from the beginning
                // and the ending of the string
                strArray[1] = strArray[1].trim();
                // Replace all the consecutive white
                // spaces with a single space
                strArray[1] = strArray[1].replaceAll(" +", " ");
                onlyTheNumbers=strArray[1];
                String[] strArr=onlyTheNumbers.split(" ");
                for (String s1 : strArr) {
                    if(!s1.equals(str)){
                        actualLimit=s1;
                    }
                }
                if(strArray[1].contains("greater")||strErrorMsg.contains("greater")){
                    int max=Integer.parseInt(actualLimit)+5;
                    int min=Integer.parseInt(actualLimit);
                    randomNumber=toGenerateRandomNumberInGivenRange(min,max);
                    //adding on 01/06/2022
                    WebElement inputTextBox=driver1.findElement(By.xpath("//div[@class=\"spinner-input errors\"]/input[@type='text']"));
                    try {
//                        for (WebElement e:inputTextBoxesInDC) {
                            if (inputTextBox.isDisplayed()) {
                                JavascriptExecutor jse= (JavascriptExecutor) driver1;
//                                jse.executeScript("arguments[0].value='';", e);
                                inputTextBox.clear();
                                Thread.sleep(Constants.NORMAL_WAIT_TIME);
                                inputTextBox.sendKeys(randomNumber);
//                                jse.executeScript("arguments[0].value='"+ randomNumber +"';", e);
//                                temp=1;
//                                break;
                            }
//                        }

                    } catch (Exception e) {
                        System.out.println("DC model is not a normal text box");
                        //added on 24/05/
                        List<WebElement> elementList=driver1.findElements(By.xpath("//input[@type='text']"));
                        for (WebElement e1 :elementList) {
                            if (e1.isDisplayed()) {
//                                str = toGenerateRandomNumberInGivenRange(min,max);
                                e1.clear();
                                Thread.sleep(Constants.NORMAL_WAIT_TIME);
                                JavascriptExecutor jse= (JavascriptExecutor) driver1;
                                jse.executeScript("arguments[0].value='"+ randomNumber +"';", e1);
//                                temp=1;
                                break;
                            }
                        }
                    }
                }else if(strArray[1].contains("less")||strErrorMsg.contains("less")){
                    int max=Integer.parseInt(actualLimit)-5;
                    int min=Integer.parseInt(actualLimit);
                    randomNumber=toGenerateRandomNumberInGivenRange(max,min);
                    try {

                        for (WebElement e:inputTextBoxesInDC) {
                            if (e.isDisplayed()) {
                                e.clear();
                                e.sendKeys(randomNumber);
    //                            temp=1;
                                break;
                            }
                        }

                    } catch (Exception e) {
                        System.out.println("DC model is not a normal text box");
                        //added on 26/05/22
                        List<WebElement> elementList=driver1.findElements(By.xpath("//input[@type='text']"));
                        for (WebElement e1 :elementList) {
                            if (e1.isDisplayed()) {
//                                str = toGenerateRandomNumberInGivenRange(min,max);
                                e1.clear();
                                Thread.sleep(Constants.NORMAL_WAIT_TIME);
                                JavascriptExecutor jse= (JavascriptExecutor) driver1;
                                jse.executeScript("arguments[0].value='"+ randomNumber +"';", e1);
//                                temp=1;
                                break;
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Unable to Handle the error occured in DC Text Box");
        }
    }

    /**
     * The below method is to enter a value in input text box in Data Collection with True or False
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteDCofTypeTrueOrFalse(){
        int temp=0;
        JavascriptExecutor js= (JavascriptExecutor) driver1;
        if(temp==0) {
            try{
                if (optionTrueInTrueOrFalseSelection.isDisplayed()) {
                    js.executeScript("arguments[0].click();", optionTrueInTrueOrFalseSelection);
                    js.executeScript("arguments[0].click();", okButtonInTrueOrFalseSelection);
                    temp=1;
                }
            }
            catch(Exception e){
                System.out.println("DC model is not a true or false option");
            }
        }
    }

    /**
     * The below method is to generate random number in given range
     * @return String.
     * @author Vijay Y
     * @args min,max
     */
    public String toGenerateRandomNumberInGivenRange(int min, int max){
        int a = (int)(Math.random()*(max-min+1)+min);
        System.out.println("The generated random number is "+a);
        String str=Integer.toString(a);
        return str;
    }

    /**
     * The below method is to generate random decimal number in given range
     * @return String.
     * @author Vijay Y
     * @args min,max
     */
    public String toGenerateRandomDecimalNumberInGivenRange(double min, double max){
        DecimalFormat formatter = new DecimalFormat("##.##"); //
        formatter.setRoundingMode(RoundingMode.DOWN); // Towards zero
        String result = formatter.format((Math.random()*(max-min+1)+min));
//        int a = (int)(Math.random()*(max-min+1)+min);
//        System.out.println("The generated random number is "+a);
//        String str=Double.toString(result);
        return result;
    }

    /**
     * The below method is to generate a random number within this number
     * @return String.
     * @author Vijay Y
     * @args max
     */
    public String toGenerateRandomNumberUptoThisRange(int max){
        int min=1;
        int a = (int)(Math.random()*(max-min+1)+min);
        System.out.println("The generated random number is "+a);
        String str=Integer.toString(a);
        return str;
    }

    /**
     * The below method is to generate a random number above this number
     * @return String.
     * @author Vijay Y
     * @args max
     */
    public String toGenerateRandomNumberAboveThisNumber(int min){
        int max=1000;
        int a = (int)(Math.random()*(max-min+1)+min);
        System.out.println("The generated random number is "+a);
        String str=Integer.toString(a);
        return str;
    }

    /**
     * The below method is to generate a random number from 0 to 1000
     * @return String.
     * @author Vijay Y
     */
    public String toGenerateRandomNumber(){
        int min=1;
        int max=1000;
        int a = (int)(Math.random()*(max-min+1)+min);
        System.out.println("The generated random number is "+a);
        String str=Integer.toString(a);
        return str;
    }

    /**
     * The below method is to complete checklist section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteCheckListStep() throws Exception {
        int temp=0;
        int temp1=0;
        String userName= FileReaderManager.getInstance().getConfigReader().getCheckListUserName();
        String passWord=FileReaderManager.getInstance().getConfigReader().getCheckListPassword();
        runEnvironmentType= FileReaderManager.getInstance().getConfigReader().getRunEnvironmentType();
        if(isCheckListStepPresent && isThisTrackIn) {
            for (int i = 0; i <= checkListButtons.size() - 1; i++) {
                checkListButtons.get(i).click();
                String str = typeOfActionInCheckList.get(i).getAttribute("title");
                if (str.contains("parameters")) {
                    parametersTabInChecklist.click();
                    for (int j=0;j<noOfEditorsInChecklistParameter.size();j++) {
                       String typeOfEditor= noOfEditorsInChecklistParameter.get(j).getAttribute("class");
                       if(typeOfEditor.contains("lookupComboBox")){
                           if(temp==0){
                               for(int k=0;k<selectFromDropDownButtonInCheckList.size();k++){
                                   selectFromDropDownButtonInCheckList.get(k).click();
                                   for(int m=0;m<optionsInCheckListDropDown.size();m++){
                                       if(optionsInCheckListDropDown.get(m).isDisplayed()){
                                           try {
                                               optionsInCheckListDropDown.get(m).click();
                                           } catch (Exception e) {
                                               e.printStackTrace();
                                           }
                                       }
                                   }
                               }
                           }
                       }else if(typeOfEditor.contains("input")){
                           if(temp1==0){
                               for(int l=0;l<plainTextBoxInCheckList.size();l++){
                                   plainTextBoxInCheckList.get(l).click();
                                   plainTextBoxInCheckList.get(l).clear();
                                   plainTextBoxInCheckList.get(l).sendKeys("Test");
//                                   temp1=1;
                               }
                           }
                       }
                    }
                    checkListButtons.get(i).click();
                } else if (str.contains("Signature")) {
                    authUserName.clear();
                    if(runEnvironmentType.equalsIgnoreCase("Dev")){
                        authUserName.sendKeys(userName);
                        authPassword.sendKeys(passWord);
                    }else{
                        authUserName.sendKeys("NGL\\administrator");
                        authPassword.sendKeys("1234");
                    }
                    authSignInButton.click();
                    Thread.sleep(Constants.NORMAL_WAIT_TIME);
                }
            }
            Thread.sleep(Constants.SYS_WAIT_TIME);
            commonUtils.toLogIntoExtentReport(Status.PASS,"Check List has been completed for this step "+currentStepName+"");
            if(!(isMaintenanceActivityOnGoing || isProtocolBeingHandled)) {
                if (isLastStep.equalsIgnoreCase("Checklist")) {
                    if (isPerformSetUpRequired) {
                        toClickOnPerformButton();
                    } else {
                        toClickOnTrackInButton();
                    }
                } else {
                    toClickOnNextButton();
                }
            }
            isCheckListStepPresent = false;
        }
    }



    /**
     * The below method is to click on track-in button inside the section
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnTrackInButton(){
        try {
            commonUtils.clickOnObject(trackInButton,"trackInButton");
            toHandleLoaderSpinner();

            try{
                if(dangerAlertDuringTrackIn.isDisplayed()){
                    ExtentTestManager.getTest().fail("One of the Data Collections was not completed.", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
                    Assert.assertTrue("One of the Data Collections was not completed.",false);

                }}catch(Exception e){

            }
            commonUtils.toLogIntoExtentReport(Status.PASS,"Tracked in into the following step "+currentStepName+"");
            isThisTrackIn=false;
        } catch (Exception e) {
            System.out.println("TrackIn Button is not displayed. Hence, looking for trackout button");
        }
    }

    public void toClickOnPerformButton(){
        try{
            commonUtils.clickOnObject(performButton,"performButton");
            toHandleLoaderSpinner();
        }catch(Exception e){
            Assert.fail("Perform was not successful, please check");
        }
    }

    /**
     * The below method is to handle the loader in UI and also manage the wait
     * @return Nothing.
     * @author Vijay Y
     */

    public void toHandleLoaderSpinner() {

        try{
            for(int i=0;i<=30;i++){
                boolean bool=loaderSpinner.getAttribute("innerHTML").contains("cmf-loading-cmf-logo");
                if(bool){
                    System.out.println("The spinner loader has disappeared");
                    break;
                }else{
                    Thread.sleep(Constants.HIGH_WAIT_TIME);
                }
            }
            Thread.sleep(Constants.NORMAL_WAIT_TIME);
        }catch(Exception e){

        }
    }

    /**
     * The below method is to do normal assemble
     * @return Nothing.
     * @author Vijay Y
     */

    public void toDoAssembleBeforeTrackingOut() throws Exception {
        if(isAssembleRequired){
            int intQuantityToAssemble=1;

            if(stepLink.isDisplayed()){
                commonUtils.clickOnObject(stepLink,"stepLink");
                toHandleLoaderSpinner();
                Thread.sleep(Constants.NORMAL_WAIT_TIME);
                WebElement pageNavigation=driver1.findElement(By.xpath("//div[@class='cmf-tab-item']/child::div[@title='"+currentStepName+"']/preceding::div[@class='tab-navigation']"));
                if(pageNavigation.isDisplayed()) {
                    commonUtils.clickOnObject(viewsDropDown,"viewsDropDown");
                    commonUtils.clickOnObject(contextsOptionInViewsDropdown,"contextsOptionInViewsDropdwon");
                    Thread.sleep(Constants.NORMAL_WAIT_TIME);
                    commonUtils.clickOnObject(bomContextLinkInContextsPage,"bomContextLinkInContextsPage");
                    Thread.sleep(Constants.NORMAL_WAIT_TIME);
                    commonUtils.toLogIntoExtentReport(Status.INFO,"Bom Information Section in Contexts View");
                    String strBomNameInContextsTable=bomNameInContextTable.getAttribute("title");
                    if(strBOMName.equalsIgnoreCase(strBomNameInContextsTable)){
                        commonUtils.toLogIntoExtentReport(Status.PASS,"Bom Name in Bom Info step and the Bom Name in Contexts table are matching");
                    }else{
                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Bom Name in Bom Info step and the Bom Name in Contexts table are matching",true);
                    }
                    Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                    commonUtils.clickOnObject(pageNavigation,"pageNavigation");
                    commonUtils.toLogIntoExtentReport(Status.PASS,"Navigating from contexts view");
                    commonUtils.clickOnObject(pageNavigation,"pageNavigation");
                    toHandleLoaderSpinner();
                    Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                }
            }
//        if(isAssembleRequired){
            commonUtils.clickOnObject(assembleWizardInHeader,"assembleWizardInHeader");
            commonUtils.clickOnObject(assembleOptionInDropDown,"assembleOptionInDropDown");
            commonUtils.waitForPageLoad();
            try{
                if(assemblyDetailsLabel.isDisplayed()){
                    String strRemainingQuantity=remainingQuantityLabel.getText();
                    int intRemainingQuantity=Integer.parseInt(strRemainingQuantity);
                    if(intRemainingQuantity>=intQuantityToAssemble){
                        commonUtils.setObjectValue(quantityToAssemble,"quantityToAssemble","1");
                        commonUtils.toLogIntoExtentReport(Status.PASS,"Quantity of the product has been passed");
                    }else{
                        System.out.println("Cannot do assemble, Remaining Quantity is equal to or less than zero");
                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Cannot do assemble, Remaining Quantity is equal to or less than zero",true);
                    }
                    commonUtils.clickOnObject(nextButton,"nextButton");
                    Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                    try{
                        if(addMaterialButton.isDisplayed()){
                            for(int i=0;i<=noOfProductsToBeAssembled.size()-1;i++){
                                WebElement productInLeftPane=noOfProductsToBeAssembled.get(i);
                                commonUtils.clickOnObject(productInLeftPane,"productsInLeftPane");
                                while(productInLeftPane.getAttribute("innerHTML").contains("negativeRemainingQuantities")){
                                    commonUtils.clickOnObject(addMaterialButton,"addMaterialButton");
                                    commonUtils.scrollIntoViewPage(searchMaterialButton);
                                    commonUtils.clickOnObject(searchMaterialButton,"searchMaterialButton");
                                    Thread.sleep(Constants.NORMAL_WAIT_TIME);
                                    try {
                                        if(firstOptionInSearchMaterialDropdown.isDisplayed()){
                                            Thread.sleep(Constants.NORMAL_WAIT_TIME);
                                            commonUtils.clickOnObject(firstOptionInSearchMaterialDropdown,"firstOptionInSearchMaterialDropdown");
                                        }
                                    } catch (Exception e) {
                                        commonUtils.toLogIntoExtentReport(Status.FAIL,"First Option was not available",true);
                                        Assert.fail("First Option was not available");
                                        System.out.println("First Option was not available");
                                    }
                                    try {
                                        String strEmptyProduct1=emptyProduct.get(0).getAttribute("innerHTML");
                                        if(strEmptyProduct1.contains("data-error")){
                                            for(int j=0;j<=emptyProduct.size()-1;j++){
                                                String strEmptyProduct=emptyProduct.get(j).getAttribute("innerHTML");
                                                emptyProduct.get(j).click();
                                                if(strEmptyProduct.contains("data-error")){
                                                    commonUtils.clickOnObject(deleteButtonOfEmptyProduct,"deleteButtonOfEmptyProduct");
                                                }
                                            }
                                        }
                                    } catch (Exception e) {
                                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Empty product was not available to be removed",true);
                                        Assert.fail("Empty product was not available to be removed");
                                        System.out.println("Empty product was not available to be removed");
                                    }
                                }
                            }
                            commonUtils.toLogIntoExtentReport(Status.PASS,"Material search was successful for each of the products");
                            for (WebElement element: noOfProductsAssembled) {
                                String str=element.getAttribute("title");
                                if(str.equalsIgnoreCase("0")){
                                    continue;
                                }else
                                {
                                    commonUtils.toLogIntoExtentReport(Status.FAIL,"Material procurement was not successful, please check",true);
                                }
                            }
                            if(assembleButton.isDisplayed()){
                                commonUtils.clickOnObject(assembleButton,"assembleButton");
                                toHandleLoaderSpinner();
                                commonUtils.toLogIntoExtentReport(Status.PASS,"Assemble was successfull");
                                isAssembleRequired=false;
                            }
                        }
                    }catch(Exception e){
                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Navigation to BOM step in Assemble was not successful",true);
                        Assert.fail("Navigation to BOM step in Assemble was not successful");
                    }

                }
            }catch(Exception e){
                System.out.println("Assemble Material Page is not Loaded properly");
                commonUtils.toLogIntoExtentReport(Status.FAIL,"Assemble Material Page is not Loaded properly",true);
                Assert.fail("Assemble Material Page is not Loaded properly");
            }

        }
    }

    public String toGenerateARandomNumberBasedOnMaskPattern(String maskOfTheProduct){

        String[] maskDetailsInArray = maskOfTheProduct.split(",");
        for (int j = 0; j < maskDetailsInArray.length; j++) {
            System.out.println(maskDetailsInArray[j]);
            String maskInSplits = maskDetailsInArray[j];
            if (maskInSplits.equals("A-Z")) {
                //generate random character from A-Z
                Character randomChar = commonUtils.toGenerateRandomCharacterFromAtoZ();
                charsList.add(randomChar);
            } else if (maskInSplits.equals("0-9")||maskInSplits.equals("1-9")) {
                //generate random number 0-9
                int randomNumber = commonUtils.toGenerateRandomNumberInGivenRange(1, 9);
                char numberToChar = (char) (randomNumber+'0');
                charsList.add(numberToChar);
            } else {
                System.out.println("unable to read the mask details of the product");
            }
        }
        StringBuilder builder = new StringBuilder(charsList.size());
        for (Character ch : charsList) {
            builder.append(ch);
        }
        String randomNumberBasedOnMask = builder.toString();
        System.out.println("The random number based on mask is " + randomNumberBasedOnMask);
        return randomNumberBasedOnMask;
    }



    public void toDoScanAssemble() throws Exception {
        APIUtils apiUtils=new APIUtils(driver1);
        HashMap<String,String> mapProductAndMaterial=apiUtils.toGetTheMaterialAndProductInfo();
        if(isAssembleRequired){
            commonUtils.clickOnObject(moreButton,"More button in the Top Menu");
            commonUtils.clickOnObject(scanAssembleButton,"Scan Assemble button");
            commonUtils.waitForPageLoad();
            System.out.println(productsAlone);
            String products=productsAlone.toString();

            HashMap<String, String> productAndMask=apiUtils.toGetProductMaskThroughAPI(products);
            commonUtils.toLogIntoExtentReport(Status.PASS,"Sub-Materials for the Bom Products are going to be scanned in this page");
            for(int i=0;i<=productsInScanAssemblePage.size()-1;i++) {
                String productName = productsInScanAssemblePage.get(i).getAttribute("name");
                String flowPathOfProduct = apiUtils.toGetFlowPathOfProductThroughAPI(productName);
                if (flowPathOfProduct.contains("Consumable Storage")) {

                String maskOfTheProduct = productAndMask.get(productName);
                String strRequiredQuantity = productWithQuantity.get(productName);
                int intRequiredQuantity = Integer.parseInt(strRequiredQuantity);
                for (int k = 1; k <= intRequiredQuantity; k++) {
                    String randomNumberBasedOnMask = toGenerateARandomNumberBasedOnMaskPattern(maskOfTheProduct);
                    commonUtils.setObjectValue(materialTextBoxOfScanAssemble, "Material Text Box of Scan AssemblePage", randomNumberBasedOnMask);
                    materialTextBoxOfScanAssemble.sendKeys(Keys.ENTER);
//                    toHandleLoaderSpinner();
                    commonUtils.waitForPageLoad();
                    Thread.sleep(Constants.HIGH_LOADING_WAIT_TIME);
                    charsList.clear();
                    if (dangerAlertParentNodeInScanAssemble.getAttribute("innerHTML").contains("alert toast-error")) {
                        commonUtils.clickOnObject(dangerAlertInScanAssemble, "danger alert in scan assemble page");
                        Thread.sleep(Constants.NORMAL_WAIT_TIME);
                        String randomNumberBasedOnMask1 = toGenerateARandomNumberBasedOnMaskPattern(maskOfTheProduct);
                        commonUtils.setObjectValue(materialTextBoxOfScanAssemble, "Material Text Box of Scan AssemblePage", randomNumberBasedOnMask1);
                        materialTextBoxOfScanAssemble.sendKeys(Keys.ENTER);
                        commonUtils.waitForPageLoad();
                        Thread.sleep(Constants.HIGH_LOADING_WAIT_TIME);
                        charsList.clear();
                    }
                }

                }else{
                    String materialName=mapProductAndMaterial.get(productName);
                    commonUtils.setObjectValue(materialTextBoxOfScanAssemble, "Material Text Box of Scan AssemblePage", materialName);
//                    materialTextBoxOfScanAssemble.sendKeys(Keys.ENTER);
                    commonUtils.waitForPageLoad();
                    Thread.sleep(Constants.HIGH_LOADING_WAIT_TIME);
                    if (dangerAlertParentNodeInScanAssemble.getAttribute("innerHTML").contains("alert toast-error")) {
                        commonUtils.clickOnObject(dangerAlertInScanAssemble, "danger alert in scan assemble page");
                        Thread.sleep(Constants.NORMAL_WAIT_TIME);
                    }
                }
            }

            if(dangerAlertParentNodeInScanAssemble.getAttribute("innerHTML").contains("alert clear-all toast-error")){
                commonUtils.clickOnObject(clearAllDangerAlertsButton, "Clear all danger alert button in scan assemble page");
            }

            if(allTheProductsReadyLabel.isDisplayed()){
                String strAllProductsReadyLabel= allTheProductsReadyLabel.getText();
                commonUtils.toLogIntoExtentReport(Status.PASS,"All products were scanned successfully");
                if(strAllProductsReadyLabel.equalsIgnoreCase("All Products ready")){
                    commonUtils.clickOnObject(finishButtonInScanAssemblePage,"Finish Button in scan assemble page");
                    toHandleLoaderSpinner();
                    commonUtils.waitForPageLoad();
                    Thread.sleep(Constants.HIGH_LOADING_WAIT_TIME);
                }
                isAssembleRequired=false;
            }else{
                Assert.fail("Not all the products were scanned, please check");
            }

        }
    }


    public void toCompletePerformSetUp() throws Exception {

        runEnvironmentType= FileReaderManager.getInstance().getConfigReader().getRunEnvironmentType();
        if(runEnvironmentType.equalsIgnoreCase("Dev")){
            mainMaterialName=materialNameLabel.getText();
            commonUtils.toRightClickOnTheWebElement(stepLink);
            Thread.sleep(Constants.NORMAL_WAIT_TIME);
            commonUtils.clickOnObject(openInNewPageButton,"openInNewPageButton");
            toHandleLoaderSpinner();
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(viewsDropDown,"viewsDropDown");
            commonUtils.clickOnObject(stepViewOptionInViewsDropdown,"stepViewOptionInViewsDropdown");
            toHandleLoaderSpinner();
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            if(dangerAlertParentNodeInScanAssemble.getAttribute("innerHTML").contains("alert clear-all toast-error")){
                commonUtils.clickOnObject(clearAllDangerAlertsButton, "Clear all danger alert button in scan assemble page");
            }
            commonUtils.clickOnObject(resourcesButtonInStepViewPage,"resourcesButtonInStepViewPage");
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(mainResourceLinkInStepViewPage,"mainResourceLinkInStepViewPage");
            toHandleLoaderSpinner();
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            if(dangerAlertParentNodeInScanAssemble.getAttribute("innerHTML").contains("alert clear-all toast-error")){
                commonUtils.clickOnObject(clearAllDangerAlertsButton, "Clear all danger alert button in scan assemble page");
            }else if(dangerAlertParentNodeInScanAssemble.getAttribute("innerHTML").contains("alert toast-error")){
                commonUtils.clickOnObject(dangerAlertInScanAssemble, "danger alert in scan assemble page");
            }

            commonUtils.clickOnObject(dispatchListInResourcePage,"dispatchListInResourcePage");
            for(int i=0;i<listOfMaterialsInDispatchList.size();i++){
                String materialNameInList=listOfMaterialsInDispatchList.get(i).getAttribute("title");
                if(materialNameInList.equalsIgnoreCase(mainMaterialName)){
                    checkBoxesOfMaterialsInDispatchList.get(i).click();
                    break;
                }
            }
            Thread.sleep(Constants.MEDIUM_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(performButton,"performButton");
            isPerformSetUpRequired=true;
            commonUtils.clickOnObject(performSetUpButton,"performSetUpButton");

            toFindTheNoOfStepsPresentInThisWizard();
            if (isResourceStepPresent) {
                if(isLastStep.equalsIgnoreCase("Resource")){
                    toClickOnTrackInButton();
                }else{
                    toClickOnNextButton();
                }
                isResourceStepPresent = false;
            }

            toCompleteBomInScanAssemble();
            toCompleteCheckListStep();

        }
        isPerformSetUpRequired=false;
    }

    public void toCompleteMaintenancePlan() throws Exception {

        runEnvironmentType= FileReaderManager.getInstance().getConfigReader().getRunEnvironmentType();
        if(runEnvironmentType.equalsIgnoreCase("Dev")) {
            commonUtils.scrollIntoViewPage(serviceLink);
            commonUtils.toRightClickOnTheWebElement(serviceLink);
            Thread.sleep(Constants.NORMAL_WAIT_TIME);
            commonUtils.clickOnObject(openInNewPageButton, "openInNewPageButton");
            toHandleLoaderSpinner();
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            commonUtils.toLogIntoExtentReport(Status.PASS, "Service page");
            commonUtils.clickOnObject(resourcesLinkInServicePage, "resourcesLinkInServicePage");
            toHandleLoaderSpinner();
            commonUtils.toLogIntoExtentReport(Status.PASS, "Resources section of Service Page");
            String mainResourceNameLabel=mainResourceLinkInServicePage.getText().trim();
            commonUtils.clickOnObject(mainResourceLinkInServicePage, "mainResourceLinkInServicePage");
            toHandleLoaderSpinner();
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            commonUtils.toLogIntoExtentReport(Status.PASS, "Resource Page");
            commonUtils.clickOnObject(viewsDropDown, "viewsDropDown");
            for (WebElement element : resourceViewOptionInViewsDropdown) {
                if (element.isDisplayed()) {
                    commonUtils.clickOnObject(element, "resourceViewOptionInViewsDropdown");
                    break;
                }
            }
            toHandleLoaderSpinner();
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            toCloseAlertMessages();
            commonUtils.toLogIntoExtentReport(Status.PASS, "Resource View Page");
            commonUtils.clickOnObject(upcomingMaintenanceTab, "upcomingMaintenanceTab");
            toHandleLoaderSpinner();
            toCloseAlertMessages();
            commonUtils.toLogIntoExtentReport(Status.PASS, "Upcoming Maintenances");
            int numberOfActivities=listOfMaintenanceActivities.size();
            System.out.println(numberOfActivities);
            for (int i = 0; i < numberOfActivities;i++ ) {
                toHandleLoaderSpinner();
                Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                String strScheduledDate=scheduledDateMaintenanceActivities.get(0).getText();
                String[] strDate=strScheduledDate.split(" ");
                boolean isDateFuture=CommonUtils.isDateFuture(strDate[0],"MM/dd/yyyy");
                if(!isDateFuture) {
                    String strExecutionState = executionStateMaintenanceActivities.get(0).getText();
                    isMaintenanceActivityOnGoing = true;
                    if (strExecutionState.equalsIgnoreCase("Released")||strExecutionState.equalsIgnoreCase("InProgress")) {
//                    if (strExecutionState.equalsIgnoreCase("Released")) {
                        if(!strExecutionState.equalsIgnoreCase("InProgress")){
                            commonUtils.clickOnObject(listOfMaintenanceActivities.get(0), "Maintenance Activity CheckBox");
                            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                            try {
                                toCloseAlertMessages();
                                commonUtils.clickOnObject(moreButton, "moreButton");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }


                        String strExecutionState1 = "";
                        boolean isBeginActivityNotRequired=false;
                        if(!strExecutionState.equalsIgnoreCase("InProgress")){
                            try {
                                commonUtils.clickOnObject(activityBeginWizard, "activityBeginWizard");
                                Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                                commonUtils.clickOnObject(activityBeginButton, "activityBeginButton");
                                Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                                strExecutionState1 = executionStateMaintenanceActivities.get(0).getText();
                                Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                                commonUtils.toLogIntoExtentReport(Status.PASS, "Maintenance activity is in progress");
                            } catch (Exception e) {
                                e.printStackTrace();
                                isBeginActivityNotRequired=true;
                            }
                            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                        }

                        if (strExecutionState1.equalsIgnoreCase("InProgress")||(isBeginActivityNotRequired)||strExecutionState.equalsIgnoreCase("InProgress")) {
                            commonUtils.clickOnObject(listOfMaintenanceActivities.get(0), "Maintenance Activity CheckBox");
                            try {
                                toCloseAlertMessages();
                                commonUtils.clickOnObject(moreButton, "moreButton");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            commonUtils.clickOnObject(activityPerformWizard, "activityPerformWizard");
                            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                            toHandleLoaderSpinner();
                            toCompletePerformFunctionality();
                            Thread.sleep(Constants.MEDIUM_LOADING_WAIT_TIME);
                        }
                        commonUtils.clickOnObject(listOfMaintenanceActivities.get(0), "Maintenance Activity CheckBox");
                        Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                        try {
                            toCloseAlertMessages();
                            commonUtils.clickOnObject(moreButton, "moreButton");
                        } catch (Exception e) {
                            e.printStackTrace();
                            toCloseAlertMessages();
                            commonUtils.clickOnObject(moreButton, "moreButton");
                        }
                        commonUtils.clickOnObject(completeActivityWizard, "completeActivityWizard");
                        toHandleLoaderSpinner();
                        commonUtils.clickOnObject(completeActivityButton, "completeActivityButton");
                        try {
                            if (alertMessageInResultsStep.isDisplayed()) {
                                commonUtils.toLogIntoExtentReport(Status.FAIL, "Checklist or Data Collection of Perform was not completed successfully");
                                Assert.fail("Checklist or Data Collection of Perform Maintenance Activity was not completed successfully");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }else {
                    commonUtils.toLogIntoExtentReport(Status.INFO, "There is not a maintenance activity in past of current date");
                    System.out.println("There is not a maintenance activity in past of current date");
                    break;
                }
                Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            }

            //close that tab
            WebElement closeTabButton1=driver1.findElement(By.xpath("//div[@title='"+mainResourceNameLabel+"']/following-sibling::div/a[@class='cmf-core-shell-page-switcher-close-button icon-core-st-sm-close']"));
            try {
                commonUtils.clickOnObject(closeTabButton1,"closeTabButton");
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Unable to close the tab opened to do the maintenance activity");
                commonUtils.toLogIntoExtentReport(Status.FAIL, "Unable to close the tab opened to do the maintenance activity");
                Assert.fail("Unable to close the tab opened to do the maintenance activity");
            }

            isMaintenanceActivityOnGoing = false;
        }
    }

    public void toCloseAlertMessages(){
        try {
            if (dangerAlertParentNodeInScanAssemble.getAttribute("innerHTML").contains("alert clear-all toast-error")) {
                commonUtils.clickOnObject(clearAllDangerAlertsButton, "Clear all danger alert button in scan assemble page");
            } else if (dangerAlertParentNodeInScanAssemble.getAttribute("innerHTML").contains("alert toast-error")) {
                commonUtils.clickOnObject(dangerAlertInScanAssemble, "danger alert in scan assemble page");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("There were no alert messages present");
        }
    }

    public void toCompletePerformFunctionality() throws Exception {
        String strStepName="";
//        for (WebElement element : noOfStepsInActivityPerformWizard) {
        for(int i=0;i<noOfStepsInActivityPerformWizard.size();i++){
             strStepName = noOfStepsInActivityPerformWizard.get(i).getText();
            if (strStepName.equalsIgnoreCase("Parameters")){
                commonUtils.clickOnObject(noOfStepsInActivityPerformWizard.get(i), "ParametersStep");
                commonUtils.toLogIntoExtentReport(Status.PASS, "Parameters Step");
                try {
                    for (WebElement textBox : noOfMandatoryTextBoxesInParameterSection) {
                        textBox.sendKeys("Test");
                    }
                    commonUtils.toLogIntoExtentReport(Status.PASS, "Parameters Step");
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("There's no mandatory text box in parameter text box");
                }
            } else if (strStepName.equalsIgnoreCase("Checklist")) {
                commonUtils.clickOnObject(noOfStepsInActivityPerformWizard.get(i), "CheckListStepOfMaintenanceActivity");
                isCheckListStepPresent = true;
                isThisTrackIn = true;
                toCompleteCheckListStep();
                isCheckListStepPresent = false;
                isThisTrackIn = false;
            } else if (strStepName.equalsIgnoreCase("Data Collection")) {
                commonUtils.clickOnObject(noOfStepsInActivityPerformWizard.get(i), "DataCollectionStepOfMaintenanceActivity");
                isDataCollectionStepPresent = true;
                isThisTrackIn = true;
                //to get the data collection name through api
                //added on 09/06/2022
                String strMaintenanceInstanceName=maintenanceInstanceName.getAttribute("alt");
                String dataCollectionName=apiUtils.toGetTheDataCollectionName(strMaintenanceInstanceName);
                if(!dataCollectionName.isEmpty()){
                    toCompleteDataCollectionStep(dataCollectionName);
                }
                isDataCollectionStepPresent = false;
                isThisTrackIn = false;
            } else if (strStepName.equalsIgnoreCase("Parts")) {
                commonUtils.clickOnObject(noOfStepsInActivityPerformWizard.get(i), "PartsStepOfMaintenanceActivity");
                commonUtils.toLogIntoExtentReport(Status.PASS, "Parts Step");
            } else if (strStepName.equalsIgnoreCase("Notes")){
                commonUtils.clickOnObject(noOfStepsInActivityPerformWizard.get(i), "NotesStep");
                Thread.sleep(Constants.NORMAL_WAIT_TIME);
                commonUtils.clickOnObject(addNoteButtonInNotesSection,"addNoteButtonInNotesSection");
                commonUtils.toLogIntoExtentReport(Status.PASS, "Notes Step");
            } else if (strStepName.equalsIgnoreCase("Documents")){
                commonUtils.clickOnObject(noOfStepsInActivityPerformWizard.get(i), "DocumentsStep");
                commonUtils.toLogIntoExtentReport(Status.PASS, "Documents Step");
            }

        }
        commonUtils.clickOnObject(saveAndCloseButtonOfPerformActivity, "saveAndCloseButtonOfPerformActivity");
        toHandleLoaderSpinner();
        Thread.sleep(Constants.HIGH_LOADING_WAIT_TIME);
        toHandleLoaderSpinner();
    }

    public void toManageProtocols() throws Exception {
        commonUtils.scrollIntoViewPage(protocolSectionButton);
        commonUtils.clickOnObject(protocolSectionButton,"ProtocolSection");
        commonUtils.clickOnObject(rowCountDropDown,"rowCountDropDown");
        commonUtils.clickOnObject(rowCountPerPage,"rowCountPerPage");
        commonUtils.toLogIntoExtentReport(Status.INFO,"In protocols section, to handle protocols",true);
        toHandleLoaderSpinner();
        for(int i=0;i<protocolStateLabel.size();i++){
            String strProtocolState=protocolStateLabel.get(i).getText();
            String strProtocolCreatedDate=protocolCreatedDate.get(i).getText();
            String[] strDateArray=strProtocolCreatedDate.split(" ");
            boolean wasProtocolCreatedToday=CommonUtils.isDateToday(strDateArray[0],"MM/dd/yyyy");
            if(strProtocolState.equalsIgnoreCase("Open/Active") && wasProtocolCreatedToday){
                String protocolNameFromUI=protocolInstanceLink.get(i).getText();
                String strProtocolVersion=versionOfProtocolLabel.get(i).getText();
                String[] arrProtocolName=strProtocolVersion.split("[.]");
                String actualProtocolName=arrProtocolName[0];
                commonUtils.scrollIntoViewPage(protocolInstanceLink.get(i));
                commonUtils.toRightClickOnTheWebElement(protocolInstanceLink.get(i));
                Thread.sleep(Constants.NORMAL_WAIT_TIME);
                commonUtils.clickOnObject(openInNewPageButton, "openInNewPageButton");
                toHandleLoaderSpinner();
                Thread.sleep(Constants.MEDIUM_LOADING_WAIT_TIME);
                toHandleLoaderSpinner();
                Thread.sleep(Constants.HIGH_LOADING_WAIT_TIME);
                toHandleLoaderSpinner();
                String strProtocolStateNameLabel="";
                //hit the api and get the total number of states present in the protocol
                try {
                    apiUtils.toGetTheStatesOfProtocol(actualProtocolName);
                } catch (Exception e) {
                    e.printStackTrace();
                    Assert.fail("Unable to reach the api to get the protocol states info");
                    commonUtils.toLogIntoExtentReport(Status.FAIL,"Unable to reach the api to get the protocol states info",true);
                }
                int noOfStatesInProtocol = apiUtils.noOfStatesInProtocol;
                for(int j=0;j<noOfStatesInProtocol;j++){

                    toHandleLoaderSpinner();
                    try {
                        strProtocolStateNameLabel=protocolStateNameLabel.getText().trim();
                    } catch (Exception e) {
                        toHandleLoaderSpinner();
                        Thread.sleep(Constants.MEDIUM_LOADING_WAIT_TIME);
                        toHandleLoaderSpinner();
                        strProtocolStateNameLabel=protocolStateNameLabel.getText().trim();
                    }
                    try {
                        apiUtils.toGetTheStatesOfProtocol(actualProtocolName,strProtocolStateNameLabel);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Assert.fail("Unable to reach the api to get the protocol states info");
                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Unable to reach the api to get the protocol states info",true);
                    }
                    String protocolStateNameInLowerCase=protocolStateNameLabelInLowerCase.getText();

                    isProtocolBeingHandled=true;
                    boolean isParameterPresentInProtocol = apiUtils.isParameterPresentInProtocol;
                    boolean isCheckListPresentInProtocol = apiUtils.isCheckListPresentInProtocol;
                    boolean strAllowDispositionDecision = apiUtils.strAllowDispositionDecision;
                    boolean strDispositionRequiresApproval = apiUtils.strDispositionRequiresApproval;
                    boolean isTaskCreationRequired = apiUtils.isTaskCreationRequired;
                    if(isParameterPresentInProtocol||isCheckListPresentInProtocol){
                        commonUtils.clickOnObject(performProtocolInstance,"Perform Protocol Button");
                        toHandleLoaderSpinner();
                        Thread.sleep(Constants.MEDIUM_LOADING_WAIT_TIME);
                        toHandleLoaderSpinner();
                        toCompletePerformFunctionality();
                        toHandleLoaderSpinner();
                        isParameterPresentInProtocol=false;
                        isCheckListPresentInProtocol=false;
                    }
                    if(strAllowDispositionDecision){
                        toManageDisposition();
                        if(strDispositionRequiresApproval){
                            toApproveDisposition();
                            strDispositionRequiresApproval=false;
                        }
                        toExecuteDisposition();
                        strAllowDispositionDecision=false;
                    }
                    if(isTaskCreationRequired){
                        toCreateTaskAndPerformTask();
                        isTaskCreationRequired=false;
                    }
                    toHandleLoaderSpinner();
                    //verify if the state is performed
                    try {
                        WebElement element=driver1.findElement(By.xpath("//div[text()='"+protocolStateNameInLowerCase+"']/preceding-sibling::div[@class='model-of-states-icon']"));
                        if(element.isDisplayed()){
                            toHandleLoaderSpinner();
                            commonUtils.toLogIntoExtentReport(Status.PASS, "This state "+protocolStateNameInLowerCase+" of the protocol has been performed or completed");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Assert.fail("This state "+protocolStateNameInLowerCase+" of the protocol was not completed. Please check");
                        commonUtils.toLogIntoExtentReport(Status.FAIL, "This state "+protocolStateNameInLowerCase+" of the protocol was not completed. Please check");
                    }

                    //verify if the protocol is closed
                    String strProtocolStatusLabelInHeader=protocolStatusLabelInHeader.getText();
                    if(strProtocolStatusLabelInHeader.equalsIgnoreCase("Closed")){
                        commonUtils.toLogIntoExtentReport(Status.PASS, "This protocol "+actualProtocolName+" has been completed or closed");
                        break;
                    }
                }
                //close the tab
                WebElement closeTabButton1=driver1.findElement(By.xpath("//div[contains(@title,'"+protocolNameFromUI+"')]/following-sibling::div/a[@class='cmf-core-shell-page-switcher-close-button icon-core-st-sm-close']"));
                try {
                    commonUtils.clickOnObject(closeTabButton1,"closeTabButton");
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("Unable to close the tab opened to do the maintenance activity");
                    commonUtils.toLogIntoExtentReport(Status.FAIL, "Unable to close the tab opened to do the maintenance activity");
                    Assert.fail("Unable to close the tab opened to do the maintenance activity");
                }
            }
        }
        isProtocolBeingHandled=false;
    }

    public void toCreateTaskAndPerformTask() {
        commonUtils.clickOnObject(createTaskWizard,"createTaskWizard");
        toHandleLoaderSpinner();
        String todayDate=commonUtils.getCurrentDate();
        long randomNumber=commonUtils.toGenerateRandomNumberInGivenRange(1,9);
        String futureDate=commonUtils.getFutureDate(randomNumber);
//        String[] todayDateArr=todayDate.replace(" ","_").split("_");
        todayDate=todayDate.replace(" ","_").replace(":","_");
        String[] futureDateArr=futureDate.replace(" ","_").split("_");
        String taskName="Task_"+todayDate;
        String dueDate=futureDateArr[0];
        commonUtils.setObjectValue(titleTextBoxInTaskCreationScreen,"titleTextBoxInTaskCreationScreen",taskName);
        commonUtils.setObjectValue(ownerTextBoxInTaskCreationScreen,"ownerTextBoxInTaskCreationScreen","Administrator");
//        ownerTextBoxInTaskCreationScreen.sendKeys(Keys.ENTER);
        try {
            Thread.sleep(Constants.NORMAL_WAIT_TIME);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        commonUtils.setObjectValue(dueDateTextBoxInTaskCreationScreen,"",dueDate);
        try {
            Thread.sleep(Constants.NORMAL_WAIT_TIME);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        commonUtils.clickOnObject(createButtonInTaskCreationScreen,"createButtonInTaskCreationScreen");
        toHandleLoaderSpinner();
        try {
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        toHandleLoaderSpinner();
        try {
            WebElement tasksBodyInPanelBar=driver1.findElement(By.xpath("//div[@class=\"cmf-core-controls-panelBar-body\"]//div[text()='"+taskName+"']"));
            if(tasksBodyInPanelBar.isDisplayed()){
                commonUtils.clickOnObject(tasksBodyInPanelBar,"tasksBodyInPanelBar");
                toHandleLoaderSpinner();
            }else{
                commonUtils.clickOnObject(tasksHeaderInPanelBar,"tasksHeaderInPanelBar");
            }

        } catch (Exception e) {
            e.printStackTrace();
            commonUtils.clickOnObject(tasksHeaderInPanelBar,"tasksHeaderInPanelBar");
            WebElement tasksBodyInPanelBar=driver1.findElement(By.xpath("//div[@class=\"cmf-core-controls-panelBar-body\"]//div[text()='"+taskName+"']"));
            if(tasksBodyInPanelBar.isDisplayed()){
                commonUtils.clickOnObject(tasksBodyInPanelBar,"tasksBodyInPanelBar");
                toHandleLoaderSpinner();
            }
        }
        toHandleLoaderSpinner();
        try {
            Thread.sleep(Constants.NORMAL_WAIT_TIME);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        WebElement taskNameLabel=driver1.findElement(By.xpath("//div[@data-tag='display-value' and text()='"+taskName+"']"));
        if(taskNameLabel.isDisplayed()){
            commonUtils.clickOnObject(performTaskWizard,"performTaskButton");
            toHandleLoaderSpinner();
            if(progressContainer.isDisplayed()){
                commonUtils.clickOnObject(progressContainer,"progressContainer");
                progressContainer.clear();
                commonUtils.setObjectValue(progressContainer,"progressContainer","100");
                commonUtils.clickOnObject(performTaskButton,"performTaskButton");
                toHandleLoaderSpinner();
                try {
                    Thread.sleep(Constants.HIGH_LOADING_WAIT_TIME);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                toHandleLoaderSpinner();
                String strSystemState=systemStateOfTask.getText();
                String strUniversalState =universalStateOfTask.getText();
                String strDisplayedTaskNameLabel=displayedTaskNameLabel.getText();
                WebElement pageNavigation=driver1.findElement(By.xpath("//div[@class='cmf-tab-item']/child::div[@title='"+strDisplayedTaskNameLabel+"']/preceding-sibling::div[@class='tab-navigation']"));
                if(strSystemState.equalsIgnoreCase("Completed")){
                    if(strUniversalState.equalsIgnoreCase("Terminated")){
                        commonUtils.clickOnObject(pageNavigation,"pageNavigation");
                        toHandleLoaderSpinner();
                    }
                }
            }
        }

    }

    public void toManageDisposition(){
        commonUtils.clickOnObject(manageProtocolButton,"manageProtocolButton");
        for (WebElement element : manageDispositionButton) {
            if (element.isDisplayed()){
                commonUtils.clickOnObject(element,"manageDispositionButton");
                break;
            }
        }
        toHandleLoaderSpinner();
        commonUtils.clickOnObject(materialLinkInManageDispositionScreen,"materialLinkInManageDispositionScreen");
        toHandleLoaderSpinner();
        dispositionDropdownTextbox.clear();
        commonUtils.setObjectValue(dispositionDropdownTextbox,"dispositionDropdownTextbox","UseAsIs");
        dispositionDropdownTextbox.sendKeys(Keys.ENTER);
        commonUtils.toLogIntoExtentReport(Status.INFO,"Manage Disposition Screen");
        commonUtils.clickOnObject(updateButton,"updateButton");
        toHandleLoaderSpinner();
    }

    public void toExecuteDisposition(){
        commonUtils.clickOnObject(executeDispositionWizard,"executeDispositionWizard");
        toHandleLoaderSpinner();
        try {
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        commonUtils.clickOnObject(materialCheckBoxInExecuteDispositionScreen,"materialCheckBoxInExecuteDispositionScreen");
        toHandleLoaderSpinner();
        commonUtils.clickOnObject(executeButtonInExecuteDispositionScreen,"executeButtonInExecuteDispositionScreen");
        toHandleLoaderSpinner();
    }

    public void toApproveDisposition(){
        commonUtils.clickOnObject(approveDispositionWizard,"approveDispositionWizard");
        toHandleLoaderSpinner();
        for (WebElement element : approveDispositionButtonInDropdown) {
            if (element.isDisplayed()){
                commonUtils.clickOnObject(element,"approveDispositionButtonInDropdown");
                break;
            }
        }
        toHandleLoaderSpinner();
        commonUtils.clickOnObject(materialCheckBoxInApproveDispositionScreen,"materialCheckBoxInApproveDispositionScreen");
        toHandleLoaderSpinner();
        commonUtils.clickOnObject(approveButtonInApproveDispostionScreen,"approveButtonInApproveDispostionScreen");
        toHandleLoaderSpinner();
    }




}
