package pageObjects;


import com.aventstack.extentreports.Status;
import helper.Constants;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.CommonUtils;

/**
 * To store the web elements of Home Page
 * To navigate to home page
 * @author  Vijay Y
 * @version 1.0
 * @since   2021-11-02
 */

public class HomePage {

    WebDriver driver1;
    CommonUtils commonUtils;

    public HomePage(WebDriver driver){
        this.driver1=driver;
        PageFactory.initElements(driver,this);
        commonUtils=new CommonUtils(driver);
    }


    @FindBy(xpath="//./cmf-core-controls-panelbar//div[text()='Business Data']")
    WebElement businessDataMenu;

    @FindBy(xpath="//./cmf-core-controls-searchbox//input[@class='searchTextBox']")
    WebElement searchTextBoxOfBusinessData;

    @FindBy(xpath="//div[@title='Material']")
    WebElement materialIcon;

    @FindBy(xpath="//./cmf-core-business-controls-querylist//following::div[1]//input[@class='searchTextBox']")
    WebElement materialSearchTextBox;

    @FindBy(xpath = "//./cmf-core-business-controls-navigation[@title]/a/div[text()]")
    WebElement materialFirstLink;

    @FindBy(xpath = "//div[@class='cmf-loading-center']")
    public WebElement loaderSpinner;

    /**
     * The below method is to click on business data menu in homepage of CM
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnBusinessData(){
        try {
//            commonUtils.waitForElementToBeDisplayed(businessDataMenu, Constants.MEDIUM_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(businessDataMenu,"BusinessDataMenu");
            commonUtils.waitForPageLoad();
            toHandleLoaderSpinner();
            commonUtils.toLogIntoExtentReport(Status.INFO,"Clicked On Business Data Menu");
        } catch (Exception e) {
            System.out.println("Unable to click on business data menu in home page");
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Unable to click on business data menu in home page",true,e.getMessage());
//            Assert.assertTrue("Unable to click on business data menu in home page",false);
            Assert.fail("Unable to click on business data menu in home page");
        }
    }

    /**
     * The below method is to search for the material menu and click on it
     * @param str
     * @return Nothing.
     * @author Vijay Y
     */
    public void toSearchForMaterialMenu(String str){
        try {
//            commonUtils.waitForElementToBeDisplayed(searchTextBoxOfBusinessData, Constants.MEDIUM_LOADING_WAIT_TIME);
            commonUtils.setObjectValue(searchTextBoxOfBusinessData,"searchTextBoxOfBusinessData",str);
//            commonUtils.waitForElementToBeDisplayed(materialIcon, Constants.MEDIUM_LOADING_WAIT_TIME);
//            commonUtils.waitForPageLoad();
            toHandleLoaderSpinner();
            commonUtils.clickOnObject(materialIcon,"materialIcon");
            toHandleLoaderSpinner();
            commonUtils.toLogIntoExtentReport(Status.PASS,"Clicked On Material Menu");
        } catch (Exception e) {
            System.out.println("Search text box of business data menu is not displayed");
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Search text box of business data menu is not displayed",true);
            Assert.assertTrue("Search text box of business data menu is not displayed",false);
        }
    }

    /**
     * The below method is to search for a material and click on it
     * @param str
     * @return Nothing.
     * @author Vijay Y
     */
    public void toSearchForMaterialAndClickOnIt(String str){

        try {
            toHandleLoaderSpinner();
//            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
//            commonUtils.waitForPageLoad();
//            commonUtils.waitForElementToBeDisplayed(materialSearchTextBox, Constants.MEDIUM_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(materialSearchTextBox,"materialSearchTextBox");
//            commonUtils.waitForElementToBeDisplayed(materialSearchTextBox, Constants.MEDIUM_LOADING_WAIT_TIME);
            commonUtils.setObjectValue(materialSearchTextBox,"materialSearchTextBox",str);
            toHandleLoaderSpinner();
            Thread.sleep(Constants.NORMAL_WAIT_TIME);
//            commonUtils.waitForPageLoad();
//            commonUtils.waitForElementToBeDisplayed(materialFirstLink, Constants.MEDIUM_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(materialFirstLink,"materialFirstLink");
            toHandleLoaderSpinner();
            Thread.sleep(Constants.NORMAL_WAIT_TIME);
//            commonUtils.waitForPageLoad();
            commonUtils.toLogIntoExtentReport(Status.PASS,"This Material "+str+" search was Successful");
        } catch (Exception e) {
            System.out.println("Material Search text box of material menu is not displayed");
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Material Search text box of material menu is not displayed");
            Assert.assertTrue("Material Search text box of material menu is not displayed",false);
        }
    }

    public void toHandleLoaderSpinner() {
        try{
            for(int i=0;i<=30;i++){
                boolean bool=loaderSpinner.getAttribute("innerHTML").contains("cmf-loading-cmf-logo");
                if(bool){
                    System.out.println("The spinner loader has disappeared");
                    break;
                }else{
                    Thread.sleep(Constants.HIGH_WAIT_TIME);
                }
            }
        }catch(Exception e){

        }
    }


}
