package pageObjects;


import com.aventstack.extentreports.Status;
import helper.Constants;
import managers.FileReaderManager;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.CommonUtils;

import java.io.IOException;


/**
 * To store the web elements of Login Page
 * To Login into the application
 * @author  Vijay Y
 * @version 1.0
 * @since   2021-11-01
 */

public class LoginPage {

    WebDriver driver1;
    CommonUtils commonUtils;


    public LoginPage(WebDriver driver){
        this.driver1=driver;
        commonUtils=new CommonUtils(driver);
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath="//input[@name='username']")
    WebElement userNameTextBox;

    @FindBy(xpath="//button[text()='Next']")
    WebElement nextButton;

    @FindBy(xpath="//input[@name='password']")
    WebElement passWordTextBox;

    @FindBy(xpath="//button[text()='Login']")
    WebElement loginButton;

    @FindBy(xpath = "//div[@class='cmf-loading-center']")
    public WebElement loaderSpinner;

    public void launchURL(){
        String url=FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
        driver1.get(url);
        commonUtils.toLogIntoExtentReport(Status.PASS,"This URL has been launched successfully "+url);
    }
    /**
     * The below method is to type username in login page
     * @return Nothing.
     * @author Vijay Y
     * @DateCreated 25/11/2021
     */
    public void typeUserName() throws IOException {
        try{
            String str=CommonUtils.getProperty("src/test/resources/jabil.properties","userName");
            commonUtils.setObjectValue(userNameTextBox,"UserName",str);
            commonUtils.toLogIntoExtentReport(Status.PASS,"The UserName has been Entered");
        }catch(Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"UserName TextBox in login page was not displayed",true);
            Assert.assertTrue("UserName TextBox in login page was not displayed",false);
        }

    }

    /**
     * The below method is to click on next button in login page
     * @return Nothing.
     * @author Vijay Y
     */
    public void clickOnNextButton(){
        try{
            commonUtils.clickOnObject(nextButton,"NextButtonInLoginPage");
            commonUtils.waitForPageLoad();
        }catch(Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Next Button in login page was not displayed",true);
            Assert.assertTrue("Next Button in login page was not displayed",false);
        }

    }

    /**
     * The below method is to type password in login page
     * @return Nothing.
     * @author Vijay Y
     */
    public void typePassWord(){
        try{
            String str=CommonUtils.getProperty("src/test/resources/jabil.properties","password");
            commonUtils.setObjectValue(passWordTextBox,"Password",str);
            commonUtils.toLogIntoExtentReport(Status.PASS,"The Password has been Entered");
        }catch(Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Password text box was not displayed",true);
            Assert.assertTrue("Password text box was not displayed",false);
        }

    }

    /**
     * The below method is to click on login button in login page
     * @return Nothing.
     * @author Vijay Y
     */
    public void clickOnLoginButton(){
        try{
            commonUtils.clickOnObject(loginButton,"LoginButtonInLoginPage");
            commonUtils.waitForPageLoad();
            commonUtils.toHandleLoaderSpinner(loaderSpinner);
            commonUtils.waitForPageLoad();
            commonUtils.toLogIntoExtentReport(Status.PASS,"Logged-in into the application");
        }catch(Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Login Button is not clickable or not displayed",true);
            Assert.assertTrue("Login Button is not clickable or not displayed",false);
        }

    }
}
