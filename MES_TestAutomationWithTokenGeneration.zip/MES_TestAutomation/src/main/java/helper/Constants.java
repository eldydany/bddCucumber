package helper;

public interface Constants {

    static final String REPORTS_LOCATION="Reports";
    static final String SCREENSHOTS_LOCATION="Screenshots";
    public static final int LOW_WAIT_TIME=100;
    public static final int MEDIUM_WAIT_TIME=300;
    public static final int HIGH_WAIT_TIME=1500;
    public static final int NORMAL_WAIT_TIME=1000;
    public static final int SYS_WAIT_TIME=4000;
    public static final int LOW_LOADING_WAIT_TIME=2000;
    public static final int MEDIUM_LOADING_WAIT_TIME=3000;
    public static final int HIGH_LOADING_WAIT_TIME=5000;
}
