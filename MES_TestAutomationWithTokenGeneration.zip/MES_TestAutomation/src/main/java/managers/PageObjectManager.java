package managers;

import pageObjects.*;
import org.openqa.selenium.WebDriver;
import utils.CommonUtils;

public class PageObjectManager {

    private WebDriver driver1;
    private LoginPage loginPage;
    private HomePage homePage;
    private DispatchAndTrackInPage dispatchAndTrackInPage;
    private TrackOutAndMoveNextPage trackOutAndMoveNextPage;
    private CommonUtils commonUtils;
    private DataCreationPage dataCreationPage;

    public PageObjectManager(WebDriver driver) {
        this.driver1 = driver;
    }

    public LoginPage getLoginPage(){
        return (loginPage==null)?loginPage=new LoginPage(driver1):loginPage;
    }

    public HomePage getHomePage(){
        return (homePage==null)?homePage=new HomePage(driver1):homePage;
    }

    public DispatchAndTrackInPage getDispatchAndTrackInPage(){
        return (dispatchAndTrackInPage==null)?dispatchAndTrackInPage=new DispatchAndTrackInPage(driver1):dispatchAndTrackInPage;
    }

    public TrackOutAndMoveNextPage getTrackOutAndMoveNextPage(){
        return (trackOutAndMoveNextPage==null)?trackOutAndMoveNextPage=new TrackOutAndMoveNextPage(driver1):trackOutAndMoveNextPage;
    }

    public DataCreationPage getDataCreationPage(){
        return (dataCreationPage==null)?dataCreationPage=new DataCreationPage(driver1):dataCreationPage;
    }

    public CommonUtils getCommonUtils(){
        return (commonUtils==null)?commonUtils=new CommonUtils(driver1):commonUtils;
    }



}
