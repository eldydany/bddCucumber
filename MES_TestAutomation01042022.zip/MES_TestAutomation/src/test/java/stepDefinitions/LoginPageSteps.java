package stepDefinitions;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import cucumber.TestContext;
//import cucumber.api.java.en.Given;
//import cucumber.api.java.en.Then;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import managers.ExtentTestManager;
import managers.PageObjectManager;
import managers.WebDriverManager;
import pageObjects.LoginPage;

public class LoginPageSteps {

    TestContext testContext;
    LoginPage loginPage;

    public LoginPageSteps(TestContext context){
        testContext=context;
        loginPage=testContext.getPageObjectManager().getLoginPage();
    }

//    @When("to launch the URL")
//    public void to_launch_the_url() throws Exception {
//        loginPage.launchURL();
//        ExtentTestManager.getTest().log(Status.INFO,"URL Launched");
//    }

    @Given("^to launch the url$")
    public void to_launch_the_url() throws Throwable {
        loginPage.launchURL();
    }

//    @Then("to login into the application")
//    public void toLoginIntoTheApplication() throws Exception {
//        ExtentTestManager.startTest("Login Into Application");
//        loginPage.typeUserName();
//        loginPage.clickOnNextButton();
//        loginPage.typePassWord();
//        loginPage.clickOnLoginButton();
//        ExtentTestManager.getTest().log(Status.INFO,"Login Successfull");
////        ExtentTestManager.getTest().log(Status.PASS,"Login Test Passed", MediaEntityBuilder.createScreenCaptureFromBase64String());
//
//    }

    @Then("^to login into the application$")
    public void to_login_into_the_application() throws Throwable {

        loginPage.typeUserName();
        loginPage.clickOnNextButton();
        loginPage.typePassWord();
        loginPage.clickOnLoginButton();

    }

}
