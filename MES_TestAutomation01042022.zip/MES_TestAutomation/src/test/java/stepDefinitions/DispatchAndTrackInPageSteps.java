package stepDefinitions;

import cucumber.TestContext;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
//import cucumber.api.java.en.Then;
import pageObjects.DispatchAndTrackInPage;
import pageObjects.HomePage;

public class DispatchAndTrackInPageSteps {

    TestContext testContext;
    DispatchAndTrackInPage dispatchAndTrackInPage;

    public DispatchAndTrackInPageSteps(TestContext context){
        testContext=context;
        dispatchAndTrackInPage=testContext.getPageObjectManager().getDispatchAndTrackInPage();
    }

//    @Then("^to click on dispatch and track in wizard$")
//    public void toClickOnDispatchAndTrackIn() throws Exception {
//        dispatchAndTrackInPage.toClickOnDispatchAndTrackInWizard();
//        dispatchAndTrackInPage.toChooseAvailableResource();
//        dispatchAndTrackInPage.toCompleteDocumentsStep();
//        dispatchAndTrackInPage.toCompleteBomInformationStep();
//        dispatchAndTrackInPage.toCompleteDataCollectionStep("false");
//        dispatchAndTrackInPage.toCompleteCheckListStep();
//    }


    @And("to choose one of the available resource")
    public void toChooseOneOfTheAvailableResource() throws Exception {
        dispatchAndTrackInPage.toChooseAvailableResource();
    }

    @And("to dispatch and track in into the step")
    public void toDispatchAndTrackInIntoTheStep()  {
        dispatchAndTrackInPage.toClickOnDispatchAndTrackInWizard();
    }

    @And("to complete bom information step")
    public void toCompleteBomInformationStep() {
        dispatchAndTrackInPage.toCompleteBomInformationStep();
    }

    @And("to complete document step")
    public void toCompleteDocumentStep() throws Exception {
        dispatchAndTrackInPage.toCompleteDocumentsStep();
    }

    @And("to complete checklist step")
    public void toCompleteChecklistStep() throws Exception {
        dispatchAndTrackInPage.toCompleteCheckListStep();
    }

    @And("to complete data collection step with {string}")
    public void toCompleteDataCollectionStepWith(String arg0) throws Exception {
        dispatchAndTrackInPage.toCompleteDataCollectionStep();
    }

    @Then("to verify if assemble is working fine")
    public void toVerifyIfAssembleIsWorkingFine() throws Exception {
        dispatchAndTrackInPage.toDoAssembleBeforeTrackingOut();
    }
}
