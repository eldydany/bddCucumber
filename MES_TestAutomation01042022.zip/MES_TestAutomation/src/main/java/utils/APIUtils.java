package utils;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class APIUtils {

    public static void main(String[] args) throws IOException {
        APIUtils apiUtils=new APIUtils();
        apiUtils.toGetAPIResponse();
    }

    public void toGetAPIResponse() throws IOException {
        String userName="NGL\\administrator";
        String password ="qaz123WSX";
        String sessionID="12454577688767";
        String grantType="password";
        String input = "{\"$id\":null,\"$type\":\"Cmf.Foundation.BusinessOrchestration.SecurityManagement.InputObjects.LoginUserInput,Cmf.Foundation.BusinessOrchestration\",\"Domain\":\"NGL\",\"Username\":\"" + userName + "\",\"Password\":\"" + password + "\"}";
        String content = "grant_type=password&username=" + userName + "&password=" + password + "&input=" + input;
        URL obj = new URL("https://nextgenlab.ngl.local/api/token");
        HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
        postConnection.setRequestMethod("POST");
        postConnection.setRequestProperty("username", userName);
        postConnection.setRequestProperty("password",password);
        postConnection.setRequestProperty("grant_type",grantType);
        postConnection.setRequestProperty("input",input);
        System.out.println("The user name is "+userName);
        System.out.println("The pass word is "+password);
        postConnection.setRequestProperty("Cmf_SessionId", sessionID);
        postConnection.setRequestProperty("Cmf_CurrentCulture","en-US");
        postConnection.setRequestProperty("X-Override_TypeConverters","true");
        postConnection.setRequestProperty("Cmf_ClientTenantName", "CriticalManufacturing");
        postConnection.setRequestProperty("Content-Type", "application//json");
        postConnection.setDoOutput(true);
        postConnection.connect();
        int code=postConnection.getResponseCode();
//        postConnection.setRequestProperty("Username", Username);
//        postConnection.setRequestProperty("UserId", UserId);
//        postConnection.setRequestProperty("Content-Type", "application/json");
//        postConnection.setDoOutput(true);
        OutputStream os = postConnection.getOutputStream();
//        os.write(postInputData.getBytes());
        os.flush();
        os.close();
        int responseCode = postConnection.getResponseCode();
        System.out.println("GET Response Code : " + code);
        System.out.println("GET Response Message : " + postConnection.getResponseMessage());

    }

}
