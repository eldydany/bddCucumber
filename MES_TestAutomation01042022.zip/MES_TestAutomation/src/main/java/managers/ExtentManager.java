package managers;



import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentManager {

    private static ExtentReports extent;
    private static String reportFileName = "Test-Automaton-Report"+".html";
    private static String fileSeperator = System.getProperty("file.separator");
    static String baseFolderPath=".//TestReport/";
    static Date date =new Date();
    static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss") ;
    static String fileName=dateFormat.format(date).replace(" ","_")+"/";
    public static String reportFilepath = baseFolderPath + "Report_"+fileName;
    private static String reportFileLocation =  reportFilepath + reportFileName;


    public static ExtentReports getInstance() {
        if (extent == null)
            createInstance();
        return extent;
    }

    //Create an extent report instance
    public static ExtentReports createInstance()  {
        String fileName = getReportPath(reportFilepath);

        ExtentSparkReporter sparkReporter=new ExtentSparkReporter(fileName);


        sparkReporter.config().setCss("img{height:115%;width:150%;}");
//        sparkReporter.config().thumbnailForBase64().toString();
//        htmlReporter.config().setChartVisibilityOnOpen(true);
//        htmlReporter.config().setDocumentTitle(reportFileName);
//        htmlReporter.config().setEncoding("UTF-8");
//        htmlReporter.config().setReportName(reportFileName);
//        htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");

        extent = new ExtentReports();
        try {
            sparkReporter.loadXMLConfig(new File(FileReaderManager.getInstance().getConfigReader().getReportConfigPath()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        extent.attachReporter(sparkReporter);
        //Set environment details
        extent.setSystemInfo("OS", "Windows");
        extent.setSystemInfo("AUT", "QA");


        return extent;
    }

    //Create the report path
    public static String getReportPath (String path) {
        File testDirectory = new File(path);
        if (!testDirectory.exists()) {
            if (testDirectory.mkdir()) {
                System.out.println("Directory: " + path + " is created!" );
                return reportFileLocation;
            } else {
                System.out.println("Failed to create directory: " + path);
                return System.getProperty("user.dir");
            }
        } else {
            System.out.println("Directory already exists: " + path);
        }
        return reportFileLocation;
    }
}
