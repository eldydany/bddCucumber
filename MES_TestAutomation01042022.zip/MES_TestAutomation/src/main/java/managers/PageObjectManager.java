package managers;

import pageObjects.DispatchAndTrackInPage;
import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.TrackOutAndMoveNextPage;
import org.openqa.selenium.WebDriver;
import utils.CommonUtils;

public class PageObjectManager {

    private WebDriver driver1;
    private LoginPage loginPage;
    private HomePage homePage;
    private DispatchAndTrackInPage dispatchAndTrackInPage;
    private TrackOutAndMoveNextPage trackOutAndMoveNextPage;
    private CommonUtils commonUtils;

    public PageObjectManager(WebDriver driver) {
        this.driver1 = driver;
    }

    public LoginPage getLoginPage(){
        return (loginPage==null)?loginPage=new LoginPage(driver1):loginPage;
    }

    public HomePage getHomePage(){
        return (homePage==null)?homePage=new HomePage(driver1):homePage;
    }

    public DispatchAndTrackInPage getDispatchAndTrackInPage(){
        return (dispatchAndTrackInPage==null)?dispatchAndTrackInPage=new DispatchAndTrackInPage(driver1):dispatchAndTrackInPage;
    }

    public TrackOutAndMoveNextPage getTrackOutAndMoveNextPage(){
        return (trackOutAndMoveNextPage==null)?trackOutAndMoveNextPage=new TrackOutAndMoveNextPage(driver1):trackOutAndMoveNextPage;
    }

    public CommonUtils getCommonUtils(){
        return (commonUtils==null)?commonUtils=new CommonUtils(driver1):commonUtils;
    }



}
