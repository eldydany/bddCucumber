package org.jabil.driverFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import utils.CommonUtils;

import java.util.concurrent.TimeUnit;

public class DriverFactory {

    public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();

    /**
     * This method is used to initialize the threadlocal driver on the basis of given
     * browser
     *
     * @param browser
     * @return this will return tldriver.
     */
    public WebDriver init_driver(String browser) {
        System.out.println("browser value is: " + browser);
        if (browser.equals("Chrome")) {
            String strDriverPath = CommonUtils.getProperty("src/test/resources/jabil.properties","driverPath");
            System.setProperty("webdriver.chrome.driver", strDriverPath);
            /* ChromeOptions options = new ChromeOptions();
            options.addArguments("--headless");
            options.addArguments("window-size=1366,768");
            WebDriver driver=new ChromeDriver(options);*/
            ChromeOptions options = new ChromeOptions();
            //options.addArguments("--incognito");
            DesiredCapabilities capabilities = DesiredCapabilities.chrome();
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);
            WebDriver driver = new ChromeDriver(options);
            driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
            tlDriver.set(driver);
        } else if (browser.equals("Firefox")) {
            tlDriver.set(new FirefoxDriver());
        } else if (browser.equals("Safari")) {
            tlDriver.set(new SafariDriver());
        } else if (browser.equals("Edge")) {
            //Edge driver initialization
        } else {
            System.out.println("Please pass the correct browser value: " + browser);
        }
            getDriver().manage().deleteAllCookies();
            getDriver().manage().window().maximize();
            return getDriver();

    }

    public static synchronized WebDriver getDriver() {
        return tlDriver.get();
    }
}
