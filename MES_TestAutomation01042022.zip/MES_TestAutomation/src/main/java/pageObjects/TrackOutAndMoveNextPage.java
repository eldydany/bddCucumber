package pageObjects;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import helper.Constants;
import managers.ExtentTestManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.CommonUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * To store all the web elements involved in Track-out and Move-next
 * To track-out from a step and move-next into next step
 * @author  Vijay Y
 * @version 1.0
 * @since   2021-11-01
 */

public class TrackOutAndMoveNextPage {

    WebDriver driver1;
    CommonUtils commonUtils;
    public boolean isResourceStateStepPresent;
    public boolean isRecordLossBonusStepPresent;
    public boolean isDataCollectionStepPresentInTrackOut;
    public boolean isBomInformationStepPresentInTrackOut;
    public boolean isCheckListStepPresentInTrackOut;
    public boolean isNextStepPresentInTrackOutSteps;
    public boolean isThisTrackOutWizard;
    public boolean isTrackOutButtonSeperate;
    public boolean isResourceAvailable;
    public String isLastStepInTrackOut="";
    public HashMap<String,String> map=new HashMap<String,String>();
    public String flowName;
    public String currentStepName;
    public String strSystemState;


    public TrackOutAndMoveNextPage(WebDriver driver){
        this.driver1=driver;
        PageFactory.initElements(driver,this);
        commonUtils=new CommonUtils(driver);
    }



    @FindBy(xpath = "//./cmf-core-controls-actionbutton/div[@title='Track-Out']")
    WebElement trackOutButtonInActionBar;

    @FindBy(xpath = "//./cmf-core-controls-actionbutton/div[@title='Track-Out and Move-Next']")
    WebElement trackOutAndMoveNextButtonInActionBar;

    @FindBy(xpath = "//./cmf-core-controls-actionbuttongroup//div[@title='Move-Next']")
    WebElement moveNextButtonInActionBar;

    @FindBy(xpath = "//div[@class='cmf-label' and @title='Move-Next']")
    WebElement moveNextButtonInDropDown;

    @FindBy(xpath = "//button[@data-action='finish' and text()='Move-Next']")
    WebElement moveNextButtonAtBottom;

    @FindBy(xpath = "//button[@data-action='finish' and text()='Track-Out and Move-Next']")
    WebElement trackOutMoveNextButtonAtBottom;

    @FindBy(xpath = "//div[contains(@class,'p-relative alert alert')]")
    WebElement alertMessageForMoveNext;

    @FindBy(xpath = "//button[@data-action='close']")
    WebElement closeButtonAtBottom;

    @FindBy(xpath = "//button[@data-action='next']")
    WebElement nextButton;

    @FindBy(xpath = "//button[text()='Track-Out']")
    WebElement trackOutButton;

//    @FindBy(xpath = "//div[@class='leaf-title-container']/span[text()='Loss Reasons  Details']")
    @FindBy(xpath = "//div[@class='record-loss-main']//div[@class='header-left']/div[@class='columnView-header-title']")
    WebElement lossReasonDetailsLabel;

    @FindBy(xpath="(//./cmf-core-business-controls-propertyviewer[@data-label='Name'])[1]")
    WebElement resourceNameLabel;

    @FindBys(@FindBy(xpath="//*/cmf-core-controls-horizontal-step-list/ul/li/div[2]/div/div[text()]"))
    List<WebElement> noOfStepsInTrackOutWizard;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[1]//cmf-core-controls-columnviewrow//span[2][@class='name-text']"))
    List<WebElement> parametersInColumnOneOfDC;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[2]//cmf-core-controls-columnviewrow//span[@class='name-text']"))
    List<WebElement> parametersInColumnTwoOfDC;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[3]//cmf-core-controls-columnviewrow//span[@class='name-text']"))
    List<WebElement> parametersInColumnThreeOfDC;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Flow']/div/div[2]//child::a/div[2]/div[@title]")
    WebElement flowLink;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Step']/div/div[2]//child::a/div[2]/div[@title]")
    WebElement stepLink;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='System State']/div/div[2]/div[@data-original-value]")
    WebElement systemStateLabel;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Resource']/div/div[2]/div/cmf-core-business-controls-navigation")
    WebElement resourceLink;

    @FindBys(@FindBy(xpath="//cmf-core-controls-treeviewnode//child::div[@class='leaf']"))
    List<WebElement> noOfStepsInFlowTree;

    @FindBy(xpath="//div[@title='Transaction']/parent::div/child::div[1]//cmf-core-controls-actionbutton[not(contains(@style,'display: none'))]")
    WebElement typeOfWizard;

    @FindBy(xpath = "//div[@class='cmf-loading-center']")
    public WebElement loaderSpinner;

    @FindBy(xpath="//cmf-core-controls-wizard-step[@maintitle='Results']//div[@class='p-relative alert alert-danger']")
    WebElement dangerAlertDuringTrackOut;

    public boolean isResourcePresent(){
        boolean bool=false;
        commonUtils.waitForElementToBeDisplayed(resourceLink,Constants.MEDIUM_LOADING_WAIT_TIME);
        String isResourceAvailable=resourceLink.getAttribute("data-id");
        if(isResourceAvailable.isEmpty()){
            bool=false;
        }else if(!isResourceAvailable.isEmpty()){
            bool=true;
        }
        return bool;
    }

    public void toTrackOutFromTheStep() throws Exception {

        if(isResourcePresent()){
            isResourceAvailable=true;
        }
        if (flowLink.isDisplayed()) {
            flowName = flowLink.getAttribute("title");
            currentStepName = stepLink.getAttribute("title");
        }

        String strTypeOfWizard=typeOfWizard.getAttribute("button-id");
        String[] buttonID=strTypeOfWizard.split("[.]");
        String strButtonID=buttonID[1];

        switch (strButtonID){
            case "TrackOut":
                toClickOnTrackOutWizardInActionBar();
                break;
            case "TrackOutMoveNext":
                toClickOnTrackOutAndMoveNextWizard();
                break;
            default:
                System.out.println("In switch case, default case has only executed");
        }

    }

    public void toClickOnTrackOutWizardInActionBar(){
        try{
        commonUtils.waitForPageLoad();
        toHandleLoaderSpinner();
        commonUtils.waitForElementToBeDisplayed(trackOutButtonInActionBar, Constants.HIGH_LOADING_WAIT_TIME);
        if(trackOutButtonInActionBar.isDisplayed()){
            commonUtils.clickOnObject(trackOutButtonInActionBar,"trackOutButtonInActionBar");
            toHandleLoaderSpinner();
            commonUtils.waitForPageLoad();
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            ExtentTestManager.getTest().log(Status.INFO,"Tracking out from this step "+currentStepName+"", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
            isThisTrackOutWizard=true;
            isTrackOutButtonSeperate=true;
        }}
        catch(Exception e){
            System.out.println("Seperate track out button in action bar was not displayed");
            try {
                Thread.sleep(5000);
            }
            catch(Exception e1){

            }
        }
    }

    public void toClickOnTrackOutAndMoveNextWizard() throws Exception {
        try {
//            wait.until(ExpectedConditions.visibilityOf(trackOutAndMoveNextButtonInActionBar));
            commonUtils.waitForPageLoad();
            toHandleLoaderSpinner();
            ExtentTestManager.getTest().log(Status.INFO,"Tracking out from this step "+currentStepName+"", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
            commonUtils.waitForElementToBeDisplayed(trackOutAndMoveNextButtonInActionBar,Constants.HIGH_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(trackOutAndMoveNextButtonInActionBar,"trackOutAndMoveNextButtonInActionBar");
//            trackOutAndMoveNextButtonInActionBar.click();
            toHandleLoaderSpinner();
            isThisTrackOutWizard=true;
//            Thread.sleep(9000);
        }catch(Exception e){
            toClickOnMoveNextWizard();
        }
    }


    public void toFindTheNoOfStepsPresentInTrackOutWizard(){
        if(isThisTrackOutWizard) {
            String str = "";
            toHandleLoaderSpinner();
            commonUtils.waitForElementToBeDisplayed(resourceNameLabel,Constants.MEDIUM_LOADING_WAIT_TIME);
            commonUtils.waitForElementToBeDisplayed(noOfStepsInTrackOutWizard.get(0),Constants.LOW_LOADING_WAIT_TIME);
            try {
                Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (resourceNameLabel.isDisplayed()) {
                int size=noOfStepsInTrackOutWizard.size();
                isLastStepInTrackOut=noOfStepsInTrackOutWizard.get(size-1).getText();
                try {
                    Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                for (WebElement element : noOfStepsInTrackOutWizard) {
                    str = element.getText();
                    System.out.println("No of steps present in this wizard is " + noOfStepsInTrackOutWizard.size());
                    if (str.equalsIgnoreCase("Resource State")) {
                        isResourceStateStepPresent = true;
                        System.out.println("Resource step is part of this wizard");
                    } else if (str.equalsIgnoreCase("Record Loss/Bonus")) {
                        isRecordLossBonusStepPresent = true;
                        System.out.println("Documents step is part of this wizard");
                    } else if (str.equalsIgnoreCase("Data Collection")) {
                        isDataCollectionStepPresentInTrackOut = true;
                        System.out.println("Data Collection step is part of this wizard");
                    } else if (str.equalsIgnoreCase("BOM")) {
                        isBomInformationStepPresentInTrackOut = true;
                        System.out.println("BOM info step is part of this wizard");
                    } else if (str.equalsIgnoreCase("Checklist")) {
                        isCheckListStepPresentInTrackOut = true;
                        System.out.println("Checklist step is part of this wizard");
                    } else if (str.equalsIgnoreCase("Next Step")) {
                        isNextStepPresentInTrackOutSteps = true;
                        System.out.println("Checklist step is part of this wizard");
                    }
                }
            }
        }
    }

    public void toClickOnTrackOutButton(){
        try {
            commonUtils.clickOnObject(trackOutButton,"trackOutButton");
            toHandleLoaderSpinner();

            try{
            if(dangerAlertDuringTrackOut.isDisplayed()){
                ExtentTestManager.getTest().fail("One of the Data Collections was not completed.", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
                Assert.assertTrue("One of the Data Collections was not completed.",false);

            }}catch(Exception e){

            }

            ExtentTestManager.getTest().log(Status.PASS,"Tracked out from this step "+currentStepName+" and moving to next step", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
            try{
                strSystemState=systemStateLabel.getText();
                map.put(currentStepName,strSystemState);
            }catch(Exception e){
                System.out.println("System state is not yet loaded");
            }
        } catch (Exception e) {
            System.out.println("TrackIn Button is not displayed");
            e.printStackTrace();
        }
    }

    public void toClickOnNextButton(){
        try {
//            nextButton.click();
            commonUtils.clickOnObject(nextButton,"nextButton");
            toHandleLoaderSpinner();
            commonUtils.waitForPageLoad();
            ExtentTestManager.getTest().log(Status.PASS,"Clicked on next to move to next section at track out from this step "+currentStepName+"", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
//            Thread.sleep(4000);
        } catch (Exception e) {
            System.out.println("Next Button was not displayed, hence clicking on Track-In Button");
            toClickOnTrackOutButton();
        }

    }

    public void toCompleteResourceStateStep(){
        if(isResourceStateStepPresent && isThisTrackOutWizard){
            if(isResourceAvailable) {
                if (resourceNameLabel.isDisplayed()) {
                    toHandleLoaderSpinner();
                    ExtentTestManager.getTest().log(Status.PASS,"Resource state at track out for this step "+currentStepName+" has been completed", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
                    if(isLastStepInTrackOut.equalsIgnoreCase("Resource State")){
                        toClickOnTrackOutButton();
                    }else{
                        toClickOnNextButton();
                    }
//                    toClickOnNextButton();
                }
            }

            isResourceStateStepPresent=false;
        }
    }

    public void toCompleteRecordLossBonusStep(){
        if(isRecordLossBonusStepPresent && isThisTrackOutWizard) {
//            commonUtils.waitForElementToBeDisplayed(lossReasonDetailsLabel,Constants.MEDIUM_LOADING_WAIT_TIME);
//            WebDriverWait wait=new WebDriverWait(driver1,10);
//            wait.until(ExpectedConditions.visibilityOf(lossReasonDetailsLabel));
//            try {
//                Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            if (lossReasonDetailsLabel.isDisplayed()) {
                if(isLastStepInTrackOut.equalsIgnoreCase("Record Loss/Bonus")){
                    toClickOnTrackOutButton();
                }else{
                    toClickOnNextButton();
                }
//            }
            ExtentTestManager.getTest().log(Status.PASS,"Record Loss/Bonus at track out for this step "+currentStepName+" has been completed", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
            isRecordLossBonusStepPresent=false;
        }
    }

    public void toCompleteDataCollectionStepInTrackOut() throws Exception {

        if(isDataCollectionStepPresentInTrackOut && isThisTrackOutWizard){
            DispatchAndTrackInPage dispatchAndTrackInPage=new DispatchAndTrackInPage(driver1);
            for (WebElement element : parametersInColumnOneOfDC) {
                commonUtils.clickOnObject(element,"parametersInColumnOneOfDC");
                Thread.sleep(Constants.NORMAL_WAIT_TIME);
                for(WebElement element1:parametersInColumnTwoOfDC){
                    commonUtils.clickOnObject(element1,"parametersInColumnTwoOfDC");
                    Thread.sleep(Constants.NORMAL_WAIT_TIME);
                    for(WebElement element2:parametersInColumnThreeOfDC){
                        commonUtils.clickOnObject(element2,"parametersInColumnThreeOfDC");
                        Thread.sleep(Constants.NORMAL_WAIT_TIME);
                        dispatchAndTrackInPage.toEnterValueInInputTextBoxOfDC();
                    }
                }
            }
            ExtentTestManager.getTest().log(Status.PASS,"Data collection at track out for this step "+currentStepName+" has been completed", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
            if(isLastStepInTrackOut.equalsIgnoreCase("Data Collection")){
                toClickOnTrackOutButton();
            }else{
                toClickOnNextButton();
            }
//            toClickOnNextButton();
            isDataCollectionStepPresentInTrackOut =false;
        }
    }


    public void toCompleteCheckListStep() throws Exception {
        if(isCheckListStepPresentInTrackOut && isThisTrackOutWizard) {
            DispatchAndTrackInPage dispatch=new DispatchAndTrackInPage(driver1);
            for (int i = 0; i <= dispatch.checkListButtons.size() - 1; i++) {
                dispatch.checkListButtons.get(i).click();
                String str = dispatch.typeOfActionInCheckList.get(i).getAttribute("title");
                if (str.contains("parameters")) {
                    dispatch.parametersTabInChecklist.click();
                    dispatch.parameterTextBox.sendKeys("Pass");
                    dispatch.parameterTextBox.sendKeys(Keys.ENTER);
                    dispatch.checkListButtons.get(i).click();
                } else if (str.contains("Signature")) {
                    String strUserName=CommonUtils.getProperty("src/test/resources/jabil.properties","checkListUserName");
                    String strPassword=CommonUtils.getProperty("src/test/resources/jabil.properties","checkListPassword");
                    dispatch.authUserName.sendKeys(strUserName);
                    dispatch.authPassword.sendKeys(strPassword);
                    dispatch.authSignInButton.click();
                }
            }
            toHandleLoaderSpinner();
            ExtentTestManager.getTest().log(Status.PASS,"Check List at track out for this step "+currentStepName+" has been completed", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
            Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
            if(isLastStepInTrackOut.equalsIgnoreCase("Checklist")){
                toClickOnTrackOutButton();
            }else{
                toClickOnNextButton();
            }
//            toClickOnTrackOutButton();
            isCheckListStepPresentInTrackOut=false;
        }
    }

    public boolean endOfTheFlow=false;

    public void toClickOnMoveNextWizard() throws Exception {

        if(isNextStepPresentInTrackOutSteps){
//            wait.until(ExpectedConditions.elementToBeClickable(trackOutMoveNextButtonAtBottom));
            commonUtils.waitForElementToBeDisplayed(trackOutMoveNextButtonAtBottom,Constants.HIGH_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(trackOutMoveNextButtonAtBottom,"trackOutMoveNextButtonAtBottom");
            commonUtils.waitForPageLoad();
            toHandleLoaderSpinner();
            ExtentTestManager.getTest().log(Status.PASS,"Tracked out from this "+currentStepName+" and moving to next step", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
            isNextStepPresentInTrackOutSteps=false;

        }else {
//            wait.until(ExpectedConditions.elementToBeClickable(moveNextButtonInActionBar));
            toHandleLoaderSpinner();
            try{
                strSystemState=systemStateLabel.getText();
                map.put(currentStepName,strSystemState);
            }catch(Exception e){
                System.out.println("System state is not yet loaded");
            }
            commonUtils.waitForElementToBeDisplayed(moveNextButtonInActionBar,Constants.HIGH_LOADING_WAIT_TIME);
            if (moveNextButtonInActionBar.isDisplayed()) {
//                moveNextButtonInActionBar.click();
                commonUtils.clickOnObject(moveNextButtonInActionBar,"moveNextButtonInActionBar");
                Thread.sleep(Constants.NORMAL_WAIT_TIME);
                try {
//                    moveNextButtonInDropDown.click();
                    commonUtils.clickOnObject(moveNextButtonInDropDown,"moveNextButtonInDropDown");
                    toHandleLoaderSpinner();
                    commonUtils.waitForElementToBeDisplayed(noOfStepsInTrackOutWizard.get(0),Constants.LOW_LOADING_WAIT_TIME);
//                    wait.until(ExpectedConditions.visibilityOf(noOfStepsInTrackOutWizard.get(0)));
                    if (noOfStepsInTrackOutWizard.get(0).getText().equalsIgnoreCase("Next Step")) {
//                        moveNextButtonAtBottom.click();
                        commonUtils.clickOnObject(moveNextButtonAtBottom,"moveNextButtonAtBottom");
                        toHandleLoaderSpinner();
//                        Thread.sleep(5000);
                    }
                }catch(Exception e){

                }
            }
        }
        toHandleLoaderSpinner();
        commonUtils.waitForElementToBeDisplayed(noOfStepsInTrackOutWizard.get(0),Constants.MEDIUM_LOADING_WAIT_TIME);
        if (noOfStepsInTrackOutWizard.get(0).getText().equalsIgnoreCase("Results")) {
            if(alertMessageForMoveNext.isDisplayed()){
                String alertMessage=alertMessageForMoveNext.getText();
                if(alertMessage.equalsIgnoreCase("Material(s) was/were moved to next Step successfully.")){
//                    closeButtonAtBottom.click();
                    commonUtils.clickOnObject(closeButtonAtBottom,"closeButtonAtBottom");
                    toHandleLoaderSpinner();
                    try{
//                        strSystemState=systemStateLabel.getText();
                        strSystemState="Processed";
                        ExtentTestManager.getTest().log(Status.PASS,"System state of this step "+currentStepName+" is "+strSystemState);
                        map.put(currentStepName,strSystemState);
                    }catch(Exception e){
                        System.out.println("System state is not yet loaded");
                    }
//                    js.executeScript("arguments[0].click();", closeButtonAtBottom);
//                    Thread.sleep(3000);
                }else if(alertMessage.equalsIgnoreCase("Material(s) was/were tracked out and moved to next step successfully.")){
//                    closeButtonAtBottom.click();
                    commonUtils.clickOnObject(closeButtonAtBottom,"closeButtonAtBottom");
                    toHandleLoaderSpinner();
                    try{
//                        strSystemState=systemStateLabel.getText();
                        strSystemState="Processed";
                        ExtentTestManager.getTest().log(Status.PASS,"System state of this step "+currentStepName+" is "+strSystemState);
                        map.put(currentStepName,strSystemState);
                    }catch(Exception e){
                        System.out.println("System state is not yet loaded");
                    }

                }else if(alertMessage.equalsIgnoreCase("There are no next Steps available in order to perform the move next")){
                    endOfTheFlow=true;
                    commonUtils.toLogIntoExtentReport(Status.PASS,"Reached the end of the flow, no further steps are present to process");
                    commonUtils.clickOnObject(closeButtonAtBottom,"closeButtonAtBottom");
                    toHandleLoaderSpinner();
                    try{
                        strSystemState=systemStateLabel.getText();
                        ExtentTestManager.getTest().log(Status.PASS,"System state of this step "+currentStepName+" is "+strSystemState);
                        map.put(currentStepName,strSystemState);
                    }catch(Exception e){
                        System.out.println("System state is not yet loaded");
                    }

                }else{

                    commonUtils.clickOnObject(closeButtonAtBottom,"closeButtonAtBottom");
                    toHandleLoaderSpinner();
                    try{
                        strSystemState=systemStateLabel.getText();
                        ExtentTestManager.getTest().log(Status.PASS,"System state of this step "+currentStepName+" is "+strSystemState);
                        map.put(currentStepName,strSystemState);
                    }catch(Exception e){
                        System.out.println("System state is not yet loaded");
                    }

                }

            }
        }
    }

    public int iterationCount=0;


    public int toFindTheNumberOfStepsIntheWorkFlow() throws Exception {
        int actualNoOfSteps = 0;

        if (!endOfTheFlow && iterationCount==0){
            String flowName = "";
            String currentStepName = "";
            String noOfIterationsRequired = "";

            int size1 = 0;
            int size2 = 0;
            if (flowLink.isDisplayed()) {
                flowName = flowLink.getAttribute("title");
                currentStepName = stepLink.getAttribute("title");
//                flowLink.click();
                commonUtils.clickOnObject(flowLink,"flowLink");
                Thread.sleep(Constants.HIGH_LOADING_WAIT_TIME);
                WebElement pageNavigation=driver1.findElement(By.xpath("//div[@class='cmf-tab-item']/child::div[@title='"+flowName+"']/preceding::div[@class='tab-navigation']"));
                if(pageNavigation.isDisplayed()) {
                     size2 = noOfStepsInFlowTree.size();
                    for (int i = 0; i < noOfStepsInFlowTree.size(); i++) {
                        String leafName = noOfStepsInFlowTree.get(i).getAttribute("leaf-title");
                        if (leafName.equalsIgnoreCase(currentStepName)) {
                            size1 = i;
                            break;
                        }
                    }
                }
                actualNoOfSteps = size2 - size1;
//                pageNavigation.click();
                commonUtils.clickOnObject(pageNavigation,"pageNavigation");
//                toHandleLoaderSpinner();
                Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                iterationCount=actualNoOfSteps;
            }
        }
        return actualNoOfSteps;
    }

    public void toHandleLoaderSpinner() {
        try{
            for(int i=0;i<=30;i++){
                boolean bool=loaderSpinner.getAttribute("innerHTML").contains("cmf-loading-cmf-logo");
                if(bool){
                    System.out.println("The spinner loader has disappeared");
                    break;
                }else{
                    Thread.sleep(Constants.HIGH_WAIT_TIME);
                }
            }
        }catch(InterruptedException e){

        }

    }

    public void toValidateAllStepsAreProcessed(){
            if(endOfTheFlow){
                ExtentTestManager.getTest().log(Status.PASS,MarkupHelper.createUnorderedList(map).getMarkup());
                // Displaying the HashMap
                System.out.println("Initial Mappings are: " + map);
                // Using values() to get the set view of values
                System.out.println("The collection is: " + map.values());
                for (Map.Entry<String, String> entry : map.entrySet()) {
                    System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
                    String strValSystemState=entry.getValue();
                    if(!strValSystemState.equalsIgnoreCase("Processed")){
                        Assert.assertTrue(false);
                        System.out.println("One of the steps are not processed");
                    }
                }
                ExtentTestManager.getTest().log(Status.PASS, MarkupHelper.createLabel("***** Successfully processed all the steps of the flow ******", ExtentColor.GREEN));
                System.out.println("Validation Successful, all the steps were processed successfully");
            }
    }



}
