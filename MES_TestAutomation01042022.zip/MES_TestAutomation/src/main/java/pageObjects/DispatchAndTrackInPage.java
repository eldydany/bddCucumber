package pageObjects;


import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import helper.Constants;
import managers.ExtentTestManager;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import utils.CommonUtils;

import java.util.List;

/**
 * To store all the web elements involved in Dispatch and TrackIn
 * To dispatch and track-in into a step
 * @author  Vijay Y
 * @version 1.0
 * @since   2021-11-01
 */

public class DispatchAndTrackInPage {

    private WebDriver driver1;
    CommonUtils commonUtils;
    public String isLastStep="";


    public DispatchAndTrackInPage(WebDriver driver){
        this.driver1=driver;
        PageFactory.initElements(driver,this);
        commonUtils=new CommonUtils(driver);
    }

    @FindBy(xpath = "//./cmf-core-controls-actionbutton/div[@title='Dispatch and Track-In']")
    WebElement dispatchAndTrackInWizardButton;

    @FindBy(xpath = "//./cmf-core-controls-actionbutton/div[@title='Dispatch']")
    WebElement dispatchAloneButton;

    @FindBy(xpath = "//./cmf-core-controls-actionbutton/div[@title='Track-In']")
    WebElement trackInAloneButton;

    @FindBy(xpath = "//./cmf-core-controls-actionbuttongroup//div[@title='Assemble']")
    WebElement assembleWizardInHeader;

    @FindBy(xpath = "//./cmf-core-controls-actionbuttongroupbutton//div[@title='Assemble']")
    WebElement assembleOptionInDropDown;

    @FindBy(xpath = "//div[text()='Assembly Details']")
    WebElement assemblyDetailsLabel;

    @FindBy(xpath = "//div[@class='spinner-input']/input[@type='text']")
    WebElement quantityToAssemble;

    @FindBy(xpath = "//cmf-core-business-controls-propertyviewer[@data-propertyname='RemainingQuantity']//div[@class='text symbolAvailable']")
    WebElement remainingQuantityLabel;

    @FindBy(xpath = "//div[@data-action='add']")
    WebElement addMaterialButton;

    @FindBy(xpath = ".//cmf-core-business-controls-findentity[@entity-type='Material']//div[@title='Search']")
    WebElement searchMaterialButton;

    @FindBy(xpath = "//div[@style='height: auto;']/ul[@role='listbox']/li[@data-offset-index='0']")
    WebElement firstOptionInSearchMaterialDropdown;

    @FindBy(xpath="(//./cmf-core-business-controls-propertyviewer[@data-label='Name'])[1]")
    WebElement resourceNameLabel;

    @FindBys(@FindBy(xpath="//cmf-core-controls-columnviewcolumn[@class='selected']//cmf-core-controls-columnviewrow"))
    List<WebElement> emptyProduct;

    @FindBy(xpath="//cmf-core-controls-columnviewcolumn[@class='selected']//cmf-core-controls-columnviewrow[@hasvalue='false']//div[@data-action='remove']")
    WebElement deleteButtonOfEmptyProduct;

    @FindBy(xpath = "//button[text()='Dispatch']")
    WebElement dispatchButton;

    @FindBy(xpath = "(//./cmf-core-controls-list-view//div[@class='entity-row'])[1]")
    WebElement firstAvailableResourceButton;

    @FindBy(xpath = "//cmf-mes-material-wizard-dispatch-step-dispatch")
    WebElement resourceAvailability;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Flow']/div/div[2]//child::a/div[2]/div[@title]")
    WebElement flowLink;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Step']/div/div[2]//child::a/div[2]/div[@title]")
    WebElement stepLink;

    @FindBy(xpath="//div[@title='Views']")
    WebElement viewsDropDown;

    @FindBy(xpath="//div[@title='Contexts']")
    WebElement contextsOptionInViewsDropdown;

    @FindBy(xpath="//li[@title='BOM Context']")
    WebElement bomContextLinkInContextsPage;

    @FindBy(xpath="//td[@data-field='BOM']//cmf-core-business-controls-navigation")
    WebElement bomNameInContextTable;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[@class='first-visible']//cmf-core-controls-columnviewrow[@hasvalue='true']"))
    List<WebElement> noOfProductsToBeAssembled;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn//cmf-core-controls-columnviewrow[@hasvalue='true']//div[@title='0']"))
    List<WebElement> noOfProductsAssembled;

    @FindBy(xpath = "//button[@data-action='finish' and text()='Assemble']")
    WebElement assembleButton;

    @FindBys(@FindBy(xpath="//div[@style='height: auto;']/ul[@role='listbox']/li"))
    List<WebElement> noOfMaterialsInSearchMaterialDropdown;

    @FindBy(xpath = "//button[@data-action='next']")
    WebElement nextButton;

    @FindBys(@FindBy(xpath="//*/cmf-core-controls-horizontal-step-list/ul/li/div[2]/div/div[text()]"))
    List<WebElement> noOfStepsInTheWizard;

    @FindBy(xpath="//div[@title='Transaction']/parent::div/child::div[1]//cmf-core-controls-actionbutton[not(contains(@style,'display: none'))]")
    WebElement typeOfWizard;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn//div[@class='name']"))
    List<WebElement> noOfDocuments;

    @FindBy(xpath = "//div[@class='dataGridContainer full-size']//span[text()='BOM']")
    WebElement bomInformationLabel;

    @FindBy(xpath = "//div[@class='bom-header']/div[@class='property-wraper']//a")
    WebElement bomNameLink;

    @FindBy(xpath = "//cmf-core-controls-label[@class='label-right']")
    WebElement bomType;

    @FindBys(@FindBy(xpath="//tbody[@role='rowgroup']/tr"))
    List<WebElement> noOfRowsInBomInfoSection;

//    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[1]//cmf-core-controls-columnviewrow//span[@class='name-text']"))
//    List<WebElement> parametersInColumnOneOfDC;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[1]//cmf-core-controls-columnviewrow//span[@class='name-text']"))
    List<WebElement> parametersInColumnOneOfDC;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[2]//cmf-core-controls-columnviewrow//span[@class='name-text']"))
    List<WebElement> parametersInColumnTwoOfDC;

    @FindBys(@FindBy(xpath="//./cmf-core-controls-columnviewcolumn[3]//cmf-core-controls-columnviewrow//span[@class='name-text']"))
    List<WebElement> parametersInColumnThreeOfDC;

    @FindBy(xpath = "(//input[@type='text'])[2]")
    WebElement inputTextBoxInDC;

    @FindBy(xpath = "//div[@class='group-content']//div[@title='Has parameters']")
    WebElement checkListWithParameter;

    @FindBy(xpath = "//div[@class='icon-core-st-sm-error']")
    WebElement errorNotificationForParameters;

    @FindBys(@FindBy(xpath="//div[@class='execution-state-button icon-core-st-sm-accept not-started']"))
    List<WebElement> checkListButtons;

    @FindBys(@FindBy(xpath="//./leaf-content//div[@class='cmf-core-controls-baseWidget']/child::div[2][@class='body']//child::div[@class='limit-value']//div"))
    List<WebElement> typesOfDC;

//    @FindBy(xpath = "//div[@class='leaf-div leaf-container leaf']")
    @FindBy(xpath = "//div[@class='data-collection-header']//following::div[@class='leaf-div leaf-container leaf']")
    WebElement parentTagOfDataCollection;

    @FindBy(xpath = "//div[@class='cmf-core-controls-select-expanded']//child::li[@data-name='Pass']")
    WebElement optionTrueInTrueOrFalseSelection;

    @FindBy(xpath = "//button[@data-action='ok']")
    WebElement okButtonInTrueOrFalseSelection;

    @FindBys(@FindBy(xpath="//div[@class='execution-state-button icon-core-st-sm-accept not-started']/following-sibling::div/div[2]/div[1]"))
    List<WebElement> typeOfActionInCheckList;

    @FindBy(xpath = "//li[@data-custom='PARAMETERS']")
    WebElement parametersTabInChecklist;

    @FindBy(xpath = "(//./cmf-core-controls-combobox//input[contains(@class,'k-input')])[2]")
    WebElement parameterTextBox;

    @FindBy(xpath = "//cmf-mes-datacollection-parameterlimitviewer//div[@class='dc-box-text-left-align']")
    WebElement valueRangeInLeftOfDC;

    @FindBy(xpath = "//cmf-mes-datacollection-parameterlimitviewer//div[@class='dc-box-text-right-align']")
    WebElement valueRangeInRightOfDC;

    @FindBy(xpath = "//./cmf-core-controls-auth//input[@formcontrolname='username']")
    WebElement authUserName;

    @FindBy(xpath = "//./cmf-core-controls-auth//input[@formcontrolname='password']")
    WebElement authPassword;

    @FindBy(xpath = "//./cmf-core-controls-auth//button[@id='sign']")
    WebElement authSignInButton;

    @FindBy(xpath = "//button[text()='Track-In']")
    WebElement trackInButton;

    @FindBy(xpath = "//div[@class='cmf-loading-center']")
    public WebElement loaderSpinner;

    @FindBy(xpath = "//div[@class='cmf-loading-cmf-logo']")
    WebElement logoAfterSpinner;

    @FindBy(xpath = "//button[text()='Track-Out']")
    WebElement trackOutButton;

    @FindBy(xpath="//cmf-core-business-controls-propertyviewer[@data-label='Resource']/div/div[2]/div/cmf-core-business-controls-navigation")
    WebElement resourceLink;

    @FindBy(xpath="//cmf-core-controls-wizard-step[@maintitle='Results']//div[@class='p-relative alert alert-danger']")
    WebElement dangerAlertDuringTrackIn;

    public boolean isDispatchAndTrackInWizardButtonPresent;
    public boolean isDispatchButtonPresent;
    public boolean isThisTrackIn;
    public boolean isResourceStepPresent;
    public boolean isDocumentStepPresent;
    public boolean isDataCollectionStepPresent;
    public boolean isBomInformationStepPresent;
    public boolean isCheckListStepPresent;
    public boolean isRecordLossBonusStepPresent;
    public boolean isResourceAvailable;
    public String flowName;
    public String currentStepName;
    public String strBOMName;
    public boolean resourceBool;
    public boolean isAssembleRequired;


    /**
     * The below method is to click on dispatch and track-in button in top menu
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnDispatchTrackIn(){
        try {
            commonUtils.waitForElementToBeDisplayed(dispatchAndTrackInWizardButton,Constants.MEDIUM_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(dispatchAndTrackInWizardButton,"dispatchAndTrackInWizardButton");
            commonUtils.waitForPageLoad();
            isDispatchAndTrackInWizardButtonPresent=true;
            isThisTrackIn=true;
            commonUtils.toLogIntoExtentReport(Status.INFO,"Tracked In into this step now  "+currentStepName+"");
        } catch (Exception e) {
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Dispatch and TrackIn Button was not available, Please check for the same",true);
            Assert.assertTrue("Dispatch and TrackIn Button was not available, Please check for the same",false);
        }
    }

    /**
     * The below method will find if dispatch and track-in
     * are merged together or not and makes call respectively.
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnDispatchAndTrackInWizard()  {
        try{
            if (flowLink.isDisplayed()) {
                flowName = flowLink.getAttribute("title");
                System.out.println("The name of the flow is "+flowName);
                commonUtils.toLogIntoExtentReport(Status.INFO,"The name of the flow is "+flowName+"");
                currentStepName = stepLink.getAttribute("title");
                System.out.println("The name of the current step is "+currentStepName);
                commonUtils.toLogIntoExtentReport(Status.INFO,"The name of the current step is "+currentStepName+"");
            }
        }catch(Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"The flow link or step link was not displayed, Please check the same",true);
            Assert.assertTrue("The flow link or step link was not displayed, Please check the same",false);
        }

        String strButtonID="";
        try{
            if(typeOfWizard.isDisplayed()){
                commonUtils.waitForElementToBeDisplayed(typeOfWizard, Constants.HIGH_LOADING_WAIT_TIME);
                String strTypeOfWizard=typeOfWizard.getAttribute("button-id");
                String[] buttonID=strTypeOfWizard.split("[.]");
                 strButtonID=buttonID[1];
            }
        }catch (Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Please do move-next and then try to track in",true);
            Assert.assertTrue("Please do move-next and then try to track in into the step",false);
        }

        switch (strButtonID){
            case "Dispatch":
                toClickOnDispatchAloneButton();
                break;
            case "DispatchTrackIn":
                toClickOnDispatchTrackIn();
                break;
            default:
                commonUtils.toLogIntoExtentReport(Status.FAIL,"Please do move-next and then try to track in");
                Assert.assertTrue("Please do move-next and then try to track in",false);
                break;
        }
    }

    /**
     * The below method is to click on dispatch first and then to click on track-in
     * in the next step.
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnDispatchAloneButton()  {
        try {
            commonUtils.waitForElementToBeDisplayed(dispatchAloneButton,Constants.LOW_LOADING_WAIT_TIME);
            commonUtils.clickOnObject(dispatchAloneButton,"dispatchAloneButton");
            commonUtils.waitForElementToBeDisplayed(resourceAvailability,Constants.LOW_LOADING_WAIT_TIME);
            String strResourceDetails="";
            strResourceDetails=resourceAvailability.getAttribute("innerHTML");
            resourceBool=strResourceDetails.contains("cmf-mes-material-resource-details");
            if (resourceBool) {
                commonUtils.clickOnObject(dispatchButton,"dispatchButton");
                toHandleLoaderSpinner();
                isResourceAvailable=true;
                System.out.println("Is the resource available "+isResourceAvailable);
                isDispatchButtonPresent=true;
            }else{
                commonUtils.waitForElementToBeDisplayed(firstAvailableResourceButton, Constants.LOW_LOADING_WAIT_TIME);
                commonUtils.clickOnObject(firstAvailableResourceButton, "firstAvailableResourceButton");
                commonUtils.waitForPageLoad();
                commonUtils.toLogIntoExtentReport(Status.PASS,"Chosen the first available resource in the list of resources");
               //added on 12/22/2021
                commonUtils.clickOnObject(dispatchButton,"dispatchButton");
                toHandleLoaderSpinner();
                isResourceAvailable=true;

            }
            if(resourceBool||isResourceAvailable){
                commonUtils.clickOnObject(trackInAloneButton,"trackInAloneButton");
                commonUtils.waitForPageLoad();
                isThisTrackIn=true;
                commonUtils.toLogIntoExtentReport(Status.INFO,"Tracked In into this step now  "+currentStepName+"");
            }

        }catch(Exception e){
            commonUtils.toLogIntoExtentReport(Status.FAIL,"Track-In into this step "+currentStepName+" was not successful");
            Assert.assertTrue("Track-In into this step "+currentStepName+" was not successful",false);
        }
    }

    /**
     * The below method is to choose available resource
     * and if the resource is already present, it will click on next
     * in the next step.
     * @return Nothing.
     * @author Vijay Y
     */
    public void toChooseAvailableResource() {
        if(isThisTrackIn) {
            try{
                String strResourceDetails=resourceAvailability.getAttribute("innerHTML");
                resourceBool=strResourceDetails.contains("cmf-mes-material-resource-details");
                if(!resourceBool) {
                    try {
                        commonUtils.waitForElementToBeDisplayed(firstAvailableResourceButton, Constants.LOW_LOADING_WAIT_TIME);
                        commonUtils.clickOnObject(firstAvailableResourceButton, "firstAvailableResourceButton");
                        toHandleLoaderSpinner();
                        commonUtils.waitForPageLoad();
                        commonUtils.toLogIntoExtentReport(Status.PASS,"Chose the first available resource at this step "+currentStepName);
                    } catch (Exception e) {
                        System.out.println("Resource dropdown is not available");
                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Unable to choose the first available resource at this step "+currentStepName);
                        Assert.assertTrue("Unable to choose the first available resource at this step "+currentStepName,false);
                    }
                }else{
                    toHandleLoaderSpinner();
                    commonUtils.toLogIntoExtentReport(Status.PASS,"Resource has been chosen already and is available for further actions at this step "+currentStepName);
                }
                commonUtils.waitForElementToBeDisplayed(noOfStepsInTheWizard.get(0),Constants.MEDIUM_LOADING_WAIT_TIME);
                toFindTheNoOfStepsPresentInThisWizard();
                if (isResourceStepPresent) {
                    if(isLastStep.equalsIgnoreCase("Resource")){
                        toClickOnTrackInButton();
                    }else{
                        toClickOnNextButton();
                    }
                    isResourceStepPresent = false;
                } else if (toCheckIfResourceNameIsPresent()) {
                    if(isLastStep.equalsIgnoreCase("Resource")){
                        toClickOnTrackInButton();
                    }else{
                        toClickOnNextButton();
                    }
                    isResourceStepPresent = false;
                }
            }catch(Exception e){
                commonUtils.toLogIntoExtentReport(Status.FAIL,"There has been a problem while choosing the available resource at this step "+currentStepName);
                Assert.assertTrue("There has been a problem while choosing the available resource at this step "+currentStepName,false);
            }
        }
    }

    /**
     * This method will check if the resource is already present,
     * and if resource is already present, it will return true
     * @return boolean.
     * @author Vijay Y
     */
    public boolean toCheckIfResourceNameIsPresent(){
        boolean bool=false;
        try {
            Thread.sleep(2000);
            bool=resourceNameLabel.isDisplayed();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Resource name label is not displayed");
        }
        return bool;
    }

    /**
     * The below method is to find the number of sections present in a step of the Flow
     * @return Nothing.
     * @author Vijay Y
     */
    public void toFindTheNoOfStepsPresentInThisWizard(){
        String str="";
        if(resourceNameLabel.isDisplayed()){
            int size=noOfStepsInTheWizard.size();
            isLastStep=noOfStepsInTheWizard.get(size-1).getText();
            for (WebElement element : noOfStepsInTheWizard) {
                str=element.getText();
                System.out.println("No of steps present in this wizard is "+ noOfStepsInTheWizard.size());
                if(str.equalsIgnoreCase("Resource")){
                    isResourceStepPresent = true;
                    System.out.println("Resource step is part of this wizard");
                }else if(str.equalsIgnoreCase("Documents")){
                    isDocumentStepPresent=true;
                    System.out.println("Documents step is part of this wizard");
                }else if(str.equalsIgnoreCase("Data Collection")){
                    isDataCollectionStepPresent=true;
                    System.out.println("Data Collection step is part of this wizard");
                }else if(str.equalsIgnoreCase("BOM")){
                    isBomInformationStepPresent=true;
                    System.out.println("BOM info step is part of this wizard");
                }else if(str.equalsIgnoreCase("Checklist")){
                    isCheckListStepPresent=true;
                    System.out.println("Checklist step is part of this wizard");
                }else if(str.equalsIgnoreCase("Record Loss/Bonus")){
                    isRecordLossBonusStepPresent=true;
                    System.out.println("Record Loss Bonus Step is part of this wizard");
                }
            }
        }
    }

    /**
     * The below method is to click on next button in the current sections(step)
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnNextButton(){
        try {
            nextButton.click();
            Thread.sleep(Constants.SYS_WAIT_TIME);
        } catch (Exception e) {
           System.out.println("Next Button was not displayed, hence clicking on Track-In Button");
           toClickOnTrackInButton();
        }

    }

    /**
     * The below method is to complete document section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteDocumentsStep() throws Exception {
        if(isDocumentStepPresent && isThisTrackIn) {
            for (WebElement element : noOfDocuments) {
                commonUtils.clickOnObject(element,"element");
            }
            commonUtils.toLogIntoExtentReport(Status.PASS,"Viewing the documents and moving to next step");
            if(isLastStep.equalsIgnoreCase("Documents")){
                toClickOnTrackInButton();
            }else{
                toClickOnNextButton();
            }
        }
        isDocumentStepPresent=false;

    }

    /**
     * The below method is to complete BOM Information section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteBomInformationStep(){
        if(isBomInformationStepPresent && isThisTrackIn) {
            try{
                if (bomInformationLabel.isDisplayed()) {
                    commonUtils.toLogIntoExtentReport(Status.PASS,"Now in BOM Info section and moving to next step");
                    try{
                        int noOfProductsInBOM=noOfRowsInBomInfoSection.size();
                        strBOMName=bomNameLink.getAttribute("alt");
                        String strBomType=bomType.getAttribute("innerHTML");
                        if(noOfProductsInBOM>0 && strBomType.contains("Explicit") ){
                             isAssembleRequired = true;
                        }
                    }catch(Exception e){
                        System.out.println("There are no product requirement in BOM");
                    }


                    if(isLastStep.equalsIgnoreCase("BOM")||isLastStep.contains("BOM")){
                        toClickOnTrackInButton();
                    }else{
                        toClickOnNextButton();
                    }
                }
            }catch(Exception e){
                Assert.fail("BOM Information step is not displayed");
            }

        }
        isBomInformationStepPresent=false;
    }

    /**
     * The below method is to complete data collection section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteDataCollectionStep() throws Exception {
        if(isDataCollectionStepPresent && isThisTrackIn){
            commonUtils.toLogIntoExtentReport(Status.INFO,"Now in data collection section");
            for (WebElement element : parametersInColumnOneOfDC) {
                commonUtils.clickOnObject(element,"ParameterInColumnOneOfDC");
                for(WebElement element1:parametersInColumnTwoOfDC){
                    commonUtils.clickOnObject(element1,"parametersInColumnTwoOfDC");
                    for(WebElement element2:parametersInColumnThreeOfDC){
                        commonUtils.clickOnObject(element2,"parametersInColumnThreeOfDC");
                        toEnterValueInInputTextBoxOfDC();
                    }
                }
            }
            commonUtils.toLogIntoExtentReport(Status.PASS,"Data Collection has been completed for this step "+currentStepName+"");
            if(isLastStep.equalsIgnoreCase("Data Collection")){
                toClickOnTrackInButton();
            }else{
                toClickOnNextButton();
            }
            isDataCollectionStepPresent=false;
        }

    }


    /**
     * The below method is to enter a value in input text box in Data Collection
     * @return Nothing.
     * @author Vijay Y
     */
    public void toEnterValueInInputTextBoxOfDC() {
            int temp = 0;
            String strPassFail = "cmf-core-business-controls-lookupselectexpanded";
            String strTextBoxAlone = "cmf-core-controls-input";
            String strLimitRange = "cmf-mes-datacollection-parameterlimitviewer";
            String strInnerHTMLofDC = parentTagOfDataCollection.getAttribute("innerHTML");
            if (strInnerHTMLofDC.contains(strLimitRange)) {
                toCompleteDCofTypeLimitRange();
            } else if (strInnerHTMLofDC.contains(strTextBoxAlone)) {
                toCompleteDCofTypeInputTextBox(20);
            } else if (strInnerHTMLofDC.contains(strPassFail)) {
                toCompleteDCofTypeTrueOrFalse();
            } else {
                toCompleteDCofTypeInputTextBox(10);
            }

    }


    /**
     * The below method is to enter a value in input text box in Data Collection with Limit
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteDCofTypeLimitRange(){
        int temp=0;
        boolean boolValueForLeft=false;
        boolean boolValueForRight=false;

        try{
            boolValueForLeft  =valueRangeInLeftOfDC.isDisplayed();
        }catch(Exception e){
            System.out.println("Limit Range value in left is not displayed");
        }

        try{
            boolValueForRight  =valueRangeInRightOfDC.isDisplayed();
        }catch(Exception e){
            System.out.println("Limit Range value in right is not displayed");

        }


        if(temp==0) {
            try{
                if (boolValueForLeft && boolValueForRight) {
                    int intValueInLeft;
                    int intValueInRight;
                    String strValueInLeft=valueRangeInLeftOfDC.getText();
                    String strValueInRight=valueRangeInRightOfDC.getText();
                    if(strValueInLeft.contains(".")){
                        String[] arrValInLeft=strValueInLeft.split("[.]");
                        String valueInLeft=arrValInLeft[0];
                        intValueInLeft=Integer.parseInt(valueInLeft);
                    }else{
                        intValueInLeft=Integer.parseInt(strValueInLeft);
                    }
                    if(strValueInRight.contains(".")){
                        String[] arrValInRight=strValueInRight.split("[.]");
                        String valueInRight=arrValInRight[0];
                        intValueInRight=Integer.parseInt(valueInRight);
                    }else{
                        intValueInRight=Integer.parseInt(strValueInRight);
                    }

                    String strValueInTextBox="";

                    strValueInTextBox=toGenerateRandomNumberInGivenRange(intValueInLeft,intValueInRight);


                    if (inputTextBoxInDC.isDisplayed()) {
                        inputTextBoxInDC.clear();
                        inputTextBoxInDC.sendKeys(strValueInTextBox);
                        temp=1;
                    }
                }else if(valueRangeInLeftOfDC.isDisplayed()){
                    int intValueInLeft;
                    String strValueInLeft=valueRangeInLeftOfDC.getText();
                    if(strValueInLeft.contains(".")){
                        String[] arrValInLeft=strValueInLeft.split("[.]");
                        String valueInLeft=arrValInLeft[0];
                        intValueInLeft=Integer.parseInt(valueInLeft);
                    }else{
                        intValueInLeft=Integer.parseInt(strValueInLeft);
                    }
                    String strValueInTextBox=toGenerateRandomNumberAboveThisNumber(intValueInLeft);
                    if (inputTextBoxInDC.isDisplayed()) {
                        inputTextBoxInDC.clear();
                        inputTextBoxInDC.sendKeys(strValueInTextBox);
                        temp=1;
                    }
                }

            } catch(Exception e){

            }
        }
    }

    /**
     * The below method is to enter a value in input text box in Data Collection
     * @return Nothing.
     * @author Vijay Y
     * @param arg1
     */
    public void toCompleteDCofTypeInputTextBox(int arg1){
        int temp=0;
        if(temp==0) {
            try {
                if (inputTextBoxInDC.isDisplayed()) {
                    String str = toGenerateRandomNumberUptoThisRange(arg1);
                    System.out.println("The value generated was " + str);
                    inputTextBoxInDC.clear();
                    inputTextBoxInDC.sendKeys(str);
                    temp=1;
                }
            } catch (Exception e) {
                System.out.println("DC model is not a normal text box");
            }
        }
    }

    /**
     * The below method is to enter a value in input text box in Data Collection with True or False
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteDCofTypeTrueOrFalse(){
        int temp=0;
        JavascriptExecutor js= (JavascriptExecutor) driver1;
        if(temp==0) {
            try{
                if (optionTrueInTrueOrFalseSelection.isDisplayed()) {
                    js.executeScript("arguments[0].click();", optionTrueInTrueOrFalseSelection);
                    js.executeScript("arguments[0].click();", okButtonInTrueOrFalseSelection);
                    temp=1;
                }
            }
            catch(Exception e){
                System.out.println("DC model is not a true or false option");
            }
        }
    }

    /**
     * The below method is to generate random number in given range
     * @return String.
     * @author Vijay Y
     * @args min,max
     */
    public String toGenerateRandomNumberInGivenRange(int min, int max){
        int a = (int)(Math.random()*(max-min+1)+min);
        System.out.println("The generated random number is "+a);
        String str=Integer.toString(a);
        return str;
    }

    /**
     * The below method is to generate a random number within this number
     * @return String.
     * @author Vijay Y
     * @args max
     */
    public String toGenerateRandomNumberUptoThisRange(int max){
        int min=1;
        int a = (int)(Math.random()*(max-min+1)+min);
        System.out.println("The generated random number is "+a);
        String str=Integer.toString(a);
        return str;
    }

    /**
     * The below method is to generate a random number above this number
     * @return String.
     * @author Vijay Y
     * @args max
     */
    public String toGenerateRandomNumberAboveThisNumber(int min){
        int max=1000;
        int a = (int)(Math.random()*(max-min+1)+min);
        System.out.println("The generated random number is "+a);
        String str=Integer.toString(a);
        return str;
    }

    /**
     * The below method is to generate a random number from 0 to 1000
     * @return String.
     * @author Vijay Y
     */
    public String toGenerateRandomNumber(){
        int min=1;
        int max=1000;
        int a = (int)(Math.random()*(max-min+1)+min);
        System.out.println("The generated random number is "+a);
        String str=Integer.toString(a);
        return str;
    }

    /**
     * The below method is to complete checklist section and click on next button
     * @return Nothing.
     * @author Vijay Y
     */
    public void toCompleteCheckListStep() throws Exception {
        if(isCheckListStepPresent && isThisTrackIn) {
            for (int i = 0; i <= checkListButtons.size() - 1; i++) {
                checkListButtons.get(i).click();
                String str = typeOfActionInCheckList.get(i).getAttribute("title");
                if (str.contains("parameters")) {
                    parametersTabInChecklist.click();
                    parameterTextBox.sendKeys("Pass");
                    parameterTextBox.sendKeys(Keys.ENTER);
                    checkListButtons.get(i).click();
                } else if (str.contains("Signature")) {
                    authUserName.sendKeys("NGL\\administrator");
                    authPassword.sendKeys("1234");
                    authSignInButton.click();
                }
            }
            Thread.sleep(Constants.SYS_WAIT_TIME);
            commonUtils.toLogIntoExtentReport(Status.PASS,"Check List has been completed for this step "+currentStepName+"");
            if(isLastStep.equalsIgnoreCase("Checklist")){
                toClickOnTrackInButton();
            }else{
                toClickOnNextButton();
            }
            isCheckListStepPresent = false;
        }
        isThisTrackIn=false;
    }

    /**
     * The below method is to click on track-in button inside the section
     * @return Nothing.
     * @author Vijay Y
     */
    public void toClickOnTrackInButton(){
        try {
            commonUtils.clickOnObject(trackInButton,"trackInButton");
            toHandleLoaderSpinner();

            try{
                if(dangerAlertDuringTrackIn.isDisplayed()){
                    ExtentTestManager.getTest().fail("One of the Data Collections was not completed.", MediaEntityBuilder.createScreenCaptureFromPath(commonUtils.getScreenshotPath()).build());
                    Assert.assertTrue("One of the Data Collections was not completed.",false);

                }}catch(Exception e){

            }
            commonUtils.toLogIntoExtentReport(Status.PASS,"Tracked in into the following step "+currentStepName+"");
            isThisTrackIn=false;
        } catch (Exception e) {
            System.out.println("TrackIn Button is not displayed. Hence, looking for trackout button");
        }
    }

    public void toHandleLoaderSpinner() {

        try{
            for(int i=0;i<=30;i++){
                boolean bool=loaderSpinner.getAttribute("innerHTML").contains("cmf-loading-cmf-logo");
                if(bool){
                    System.out.println("The spinner loader has disappeared");
                    break;
                }else{
                    Thread.sleep(Constants.HIGH_WAIT_TIME);
                }
            }
        }catch(Exception e){

        }
    }


    public void toDoAssembleBeforeTrackingOut() throws Exception {
        if(isAssembleRequired){
            int intQuantityToAssemble=1;

            if(stepLink.isDisplayed()){
                commonUtils.clickOnObject(stepLink,"stepLink");
                toHandleLoaderSpinner();
                Thread.sleep(Constants.NORMAL_WAIT_TIME);
                WebElement pageNavigation=driver1.findElement(By.xpath("//div[@class='cmf-tab-item']/child::div[@title='"+currentStepName+"']/preceding::div[@class='tab-navigation']"));
                if(pageNavigation.isDisplayed()) {
                    commonUtils.clickOnObject(viewsDropDown,"viewsDropDown");
                    commonUtils.clickOnObject(contextsOptionInViewsDropdown,"contextsOptionInViewsDropdwon");
                    Thread.sleep(Constants.NORMAL_WAIT_TIME);
                    commonUtils.clickOnObject(bomContextLinkInContextsPage,"bomContextLinkInContextsPage");
                    Thread.sleep(Constants.NORMAL_WAIT_TIME);
                    commonUtils.toLogIntoExtentReport(Status.INFO,"Bom Information Section in Contexts View");
                    String strBomNameInContextsTable=bomNameInContextTable.getAttribute("title");
                    if(strBOMName.equalsIgnoreCase(strBomNameInContextsTable)){
                        commonUtils.toLogIntoExtentReport(Status.PASS,"Bom Name in Bom Info step and the Bom Name in Contexts table are matching");
                    }else{
                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Bom Name in Bom Info step and the Bom Name in Contexts table are matching",true);
                    }
                    Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                    commonUtils.clickOnObject(pageNavigation,"pageNavigation");
                    commonUtils.toLogIntoExtentReport(Status.PASS,"Navigating from contexts view");
                    commonUtils.clickOnObject(pageNavigation,"pageNavigation");
                    toHandleLoaderSpinner();
                    Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                }
            }
//        if(isAssembleRequired){
            commonUtils.clickOnObject(assembleWizardInHeader,"assembleWizardInHeader");
            commonUtils.clickOnObject(assembleOptionInDropDown,"assembleOptionInDropDown");
            commonUtils.waitForPageLoad();
            try{
                if(assemblyDetailsLabel.isDisplayed()){
                    String strRemainingQuantity=remainingQuantityLabel.getText();
                    int intRemainingQuantity=Integer.parseInt(strRemainingQuantity);
                    if(intRemainingQuantity>=intQuantityToAssemble){
                        commonUtils.setObjectValue(quantityToAssemble,"quantityToAssemble","1");
                        commonUtils.toLogIntoExtentReport(Status.PASS,"Quantity of the product has been passed");
                    }else{
                        System.out.println("Cannot do assemble, Remaining Quantity is equal to or less than zero");
                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Cannot do assemble, Remaining Quantity is equal to or less than zero",true);
                    }
                    commonUtils.clickOnObject(nextButton,"nextButton");
                    Thread.sleep(Constants.LOW_LOADING_WAIT_TIME);
                    try{
                        if(addMaterialButton.isDisplayed()){
                            for(int i=0;i<=noOfProductsToBeAssembled.size()-1;i++){
                                WebElement productInLeftPane=noOfProductsToBeAssembled.get(i);
                                commonUtils.clickOnObject(productInLeftPane,"productsInLeftPane");
                                while(productInLeftPane.getAttribute("innerHTML").contains("negativeRemainingQuantities")){
                                    commonUtils.clickOnObject(addMaterialButton,"addMaterialButton");
                                    commonUtils.scrollIntoViewPage(searchMaterialButton);
                                    commonUtils.clickOnObject(searchMaterialButton,"searchMaterialButton");
                                    Thread.sleep(Constants.NORMAL_WAIT_TIME);
                                    try {
                                        if(firstOptionInSearchMaterialDropdown.isDisplayed()){
                                            Thread.sleep(Constants.NORMAL_WAIT_TIME);
                                            commonUtils.clickOnObject(firstOptionInSearchMaterialDropdown,"firstOptionInSearchMaterialDropdown");
                                        }
                                    } catch (Exception e) {
                                        commonUtils.toLogIntoExtentReport(Status.FAIL,"First Option was not available",true);
                                        Assert.fail("First Option was not available");
                                        System.out.println("First Option was not available");
                                    }
                                    try {
                                        String strEmptyProduct1=emptyProduct.get(0).getAttribute("innerHTML");
                                        if(strEmptyProduct1.contains("data-error")){
                                            for(int j=0;j<=emptyProduct.size()-1;j++){
                                                String strEmptyProduct=emptyProduct.get(j).getAttribute("innerHTML");
                                                emptyProduct.get(j).click();
                                                if(strEmptyProduct.contains("data-error")){
                                                    commonUtils.clickOnObject(deleteButtonOfEmptyProduct,"deleteButtonOfEmptyProduct");
                                                }
                                            }
                                        }
                                    } catch (Exception e) {
                                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Empty product was not available to be removed",true);
                                        Assert.fail("Empty product was not available to be removed");
                                        System.out.println("Empty product was not available to be removed");
                                    }
                                }
                            }
                            commonUtils.toLogIntoExtentReport(Status.PASS,"Material search was successful for each of the products");
                            for (WebElement element: noOfProductsAssembled) {
                                String str=element.getAttribute("title");
                                if(str.equalsIgnoreCase("0")){
                                    continue;
                                }else
                                {
                                    commonUtils.toLogIntoExtentReport(Status.FAIL,"Material procurement was not successful, please check",true);
                                }
                            }
                            if(assembleButton.isDisplayed()){
                                commonUtils.clickOnObject(assembleButton,"assembleButton");
                                toHandleLoaderSpinner();
                                commonUtils.toLogIntoExtentReport(Status.PASS,"Assemble was successfull");
                                isAssembleRequired=false;
                            }
                        }
                    }catch(Exception e){
                        commonUtils.toLogIntoExtentReport(Status.FAIL,"Navigation to BOM step in Assemble was not successful",true);
                        Assert.fail("Navigation to BOM step in Assemble was not successful");
                    }

                }
            }catch(Exception e){
                System.out.println("Assemble Material Page is not Loaded properly");
                commonUtils.toLogIntoExtentReport(Status.FAIL,"Assemble Material Page is not Loaded properly",true);
                Assert.fail("Assemble Material Page is not Loaded properly");
            }

        }
    }
}
