package managers;

public final class ExtentLogger {

        private ExtentLogger(){

        }

        public static void pass(String message){
            ExtentTestManager.getTest().pass(message);
        }

        public static void fail(String message){
            ExtentTestManager.getTest().pass(message);
        }

        public static void skip(String message){
            ExtentTestManager.getTest().skip(message);
        }
}
