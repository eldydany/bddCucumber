package stepDefinitions;

import com.aventstack.extentreports.Status;
import cucumber.TestContext;
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Then;
//import cucumber.api.java.en.Then;
import io.cucumber.java.en.Then;
import managers.ExtentTestManager;
import managers.FileReaderManager;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import pageObjects.HomePage;
import pageObjects.LoginPage;
import utils.ExcelReader;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class HomePageSteps {

    TestContext testContext;
    HomePage homePage;

    public HomePageSteps(TestContext context){
        testContext=context;
        homePage=testContext.getPageObjectManager().getHomePage();
    }

//    @And("to click on business data menu in the left side bar")
//    public void toClickOnBusinessDataMenuInTheLeftSideBar() {
//        homePage.toClickOnBusinessData();
//        ExtentTestManager.getTest().log(Status.INFO,"Clicked on Business Data Menu");
//    }

    @Then("^to click on business data menu in the left side bar$")
    public void to_click_on_business_data_menu_in_the_left_side_bar() throws Throwable {
        homePage.toClickOnBusinessData();
    }

//    @Then("search for material menu {string} and search for a material {string}")
//    public void searchForMaterialMenuAndSearchForAMaterial(String arg0, String arg1) throws IOException {
//        homePage.toSearchForMaterialMenu(arg0);
//        homePage.toSearchForMaterialAndClickOnIt(arg1);
//    }

    @Then("^search for material menu \"([^\"]*)\" and search for a material \"([^\"]*)\"$")
    public void search_for_material_menu_and_search_for_a_material(String arg1, String arg2) throws Throwable {
        homePage.toSearchForMaterialMenu(arg1);
        homePage.toSearchForMaterialAndClickOnIt(arg2);
    }

    @Then("search for this material from this sheet {string} and from this row number {int}")
    public void searchForThisMaterialFromThisSheetAndFromThisRowNumber(String sheetName,int rowNumber) throws IOException, InvalidFormatException {
        ExcelReader reader=new ExcelReader();
        String filepath=FileReaderManager.getInstance().getConfigReader().getInputFilePath();
        List<Map<String, String>> testData= reader.getData(filepath,sheetName);

        String menuName=testData.get(rowNumber).get("MenuItemName");
        String materialName=testData.get(rowNumber).get("MaterialName");
        homePage.toSearchForMaterialMenu(menuName);
        homePage.toSearchForMaterialAndClickOnIt(materialName);
    }
}
