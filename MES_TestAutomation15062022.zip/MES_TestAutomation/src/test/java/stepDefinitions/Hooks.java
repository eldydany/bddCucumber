package stepDefinitions;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.google.common.io.Files;
import cucumber.TestContext;

//import io.cucumber.java.After;
//import io.cucumber.java.Before;
//import cucumber.api.Scenario;
//import cucumber.api.java.After;
//import cucumber.api.java.Before;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import managers.ExtentManager;
import managers.ExtentTestManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utils.CommonUtils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class Hooks {

    TestContext testContext;
    ExtentReports extentReports;
    public String timeStamp;
    public static String scenarioName;


    public Hooks(TestContext context) {
        testContext = context;
        extentReports=ExtentManager.getInstance();
    }

    @Before(order=0)
    public void beforeScenario(Scenario scenario) {

    }

    @Before(order=1)
     public void beforeTest(Scenario scenario) {
         scenarioName = scenario.getName().replaceAll(" ", "_");
         ExtentTestManager.startTest(scenarioName);
         ExtentTestManager.getTest().log(Status.INFO, MarkupHelper.createLabel("****** Test Execution has been started ********", ExtentColor.BLUE));
    }

    @AfterStep
    public void afterScenario(Scenario scenario) throws IOException {

        CommonUtils commonUtils=new CommonUtils(testContext.getWebDriverManager().getDriver());
        String str=CommonUtils.getProperty("src/test/resources/jabil.properties","takeScreenShotAfterEachStep");
        commonUtils.waitForPageLoad();
        if(str.equalsIgnoreCase("true")) {
//            String screenshotName = scenario.getName().replaceAll(" ", "_");
            timeStamp = new SimpleDateFormat("MM_dd_yyyy HH_mm_ss").format(Calendar.getInstance().getTime());
            File screenshot = ((TakesScreenshot) testContext.getWebDriverManager().getDriver()).getScreenshotAs(OutputType.FILE);
            byte[] fileContent = FileUtils.readFileToByteArray(screenshot);
            scenario.log("<b>Test time : </b><FONT COLOR='blue'>" + timeStamp + "</FONT>");
            scenario.attach(fileContent, "image/png", "");
        }
    }

    @After(order = 0)
    public void afterSteps() throws IOException {
        testContext.getWebDriverManager().closeDriver();
        ExtentTestManager.getTest().log(Status.INFO, MarkupHelper.createLabel("****** Test Execution has been ended ********", ExtentColor.BLUE));
        ExtentTestManager.endTest();
//        String fileName=ExtentManager.getReportPath(ExtentManager.reportFilepath);
//        Desktop.getDesktop().browse(new File(fileName).toURI());
    }

}
