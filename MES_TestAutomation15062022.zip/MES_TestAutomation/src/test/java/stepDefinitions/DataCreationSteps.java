package stepDefinitions;

import cucumber.TestContext;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pageObjects.DataCreationPage;

public class DataCreationSteps {

    TestContext testContext;
    DataCreationPage dataCreationPage;

    public DataCreationSteps(TestContext context){
        testContext=context;
        dataCreationPage=testContext.getPageObjectManager().getDataCreationPage();
    }

    @Given("to read the products from this input data sheet {string}")
    public void toReadTheProductsFromThisInputDataSheet(String sheetName) throws Exception {
        dataCreationPage.toReadTheDataFromTheInputSheet(sheetName);
    }

    @And("to create materials for those products through API")
    public void toCreateMaterialsForThoseProductsThroughAPI() throws Exception {
        dataCreationPage.toCreateMaterialsThroughAPI();
    }

    @Then("to store those materials in the input data sheet {string}")
    public void toStoreThoseMaterialsInTheInputDataSheet(String sheetName) throws Exception {
        dataCreationPage.toWriteTheMaterialNamesIntoTheInputSheet(sheetName);
    }
}
